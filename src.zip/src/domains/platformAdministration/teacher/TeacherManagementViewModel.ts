import { useEffect, useState } from "react";

import {
  SchoolRecord,
  SchoolProfileLimits,
  SchoolSubscriptionDetails,
  getSchools,
  createSchool,
  updateSchool,
  deactivateSchool,
  activateSchool,
  deleteSchool
} from "./TeacherManagementRepository";

import {
  saveSchoolFeatures
} from "../../../data/schoolFeatureAccessRepository";
import { saveStudentOnboardingConfiguration } from "../../../data/studentOnboardingConfigurationRepository";

export default function useTeacherManagementViewModel() {

  const [schools, setSchools] =
    useState<SchoolRecord[]>([]);

  const [loading, setLoading] =
    useState(false);

  async function loadSchools() {

    setLoading(true);

    try {

      const schoolRows = await getSchools();
      setSchools(schoolRows);

    }

    finally {

      setLoading(false);

    }

  }

  async function addSchool(

    name: string,

    board: string,

    city: string,

    limits: SchoolProfileLimits,

    subscription: SchoolSubscriptionDetails,

    studentFeatures: string[],

    teacherFeatures: string[],

    studentParentOtpEnabled: boolean = true,

    studentQuestionnaireEnabled: boolean = true

  ) {

    const uuid = await createSchool(

      name,

      board,

      city,

      limits,

      subscription

    );

    if (!uuid) {

      return false;

    }

    const ok = await saveSchoolFeatures(

      uuid,

      studentFeatures,

      teacherFeatures

    );

    if (!ok) {
      return false;
    }

    const onboardingOk =
      await saveStudentOnboardingConfiguration(
        uuid,
        {
          parentOtpEnabled: studentParentOtpEnabled,
          questionnaireEnabled: studentQuestionnaireEnabled
        }
      );

    if (!onboardingOk) {
      console.warn(
        "Student onboarding configuration could not be saved; existing school creation remains successful."
      );
    }

    await loadSchools();
    return true;

  }

 async function editSchool(

    uuid: string,

    name: string,

    board: string,

    city: string,

    limits: SchoolProfileLimits,

    subscription: SchoolSubscriptionDetails,

    studentFeatures: string[],

    teacherFeatures: string[],

    studentParentOtpEnabled: boolean = true,

    studentQuestionnaireEnabled: boolean = true

) {

    const ok =

        await updateSchool(

            uuid,

            name,

            board,

            city,

            limits,

            subscription

        );

    if (!ok) {

        return false;

    }

    const featuresOk =

        await saveSchoolFeatures(

            uuid,

            studentFeatures,

            teacherFeatures

        );

    if (!featuresOk) {
      return false;
    }

    const onboardingOk =
      await saveStudentOnboardingConfiguration(
        uuid,
        {
          parentOtpEnabled: studentParentOtpEnabled,
          questionnaireEnabled: studentQuestionnaireEnabled
        }
      );

    if (!onboardingOk) {
      console.warn(
        "Student onboarding configuration could not be saved; existing school edit remains successful."
      );
    }

    await loadSchools();
    return true;

}

  async function removeSchool(
    uuid: string
  ) {

    const ok =
      await deactivateSchool(
        uuid
      );

    if (ok) {
      await loadSchools();
    }

    return ok;

  }

  async function activateExistingSchool(uuid:string) {
    const ok = await activateSchool(uuid);
    if (ok) await loadSchools();
    return ok;
  }

  async function deleteExistingSchool(uuid:string) {
    const ok = await deleteSchool(uuid);
    if (ok) await loadSchools();
    return ok;
  }

  useEffect(() => {

    void loadSchools();

  }, []);

  return {

    schools,

    loading,


    loadSchools,

    addSchool,

    editSchool,

    removeSchool,
    activateExistingSchool,
    deleteExistingSchool

  };

}