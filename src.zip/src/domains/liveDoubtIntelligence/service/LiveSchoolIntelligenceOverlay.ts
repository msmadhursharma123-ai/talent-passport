import type { SchoolIntelligenceRawData } from "../../schoolIntelligence/repository/SchoolIntelligenceRepository";
import type { SchoolIntelligenceSnapshot } from "../../schoolIntelligence/types/SchoolIntelligenceModels";
import { buildSchoolIntelligenceSnapshot } from "../../schoolIntelligence/analytics/SchoolIntelligenceEngine";
import {
  getSchoolIntelligenceLiveRows,
  mergeFeedbackUnderstandingLevels,
  mergePendingDoubtsWithLiveLedger,
} from "../repository/LiveDoubtReconciliationRepository";

export async function applyLiveSchoolIntelligenceOverlay(
  raw: SchoolIntelligenceRawData,
  baseSnapshot: SchoolIntelligenceSnapshot,
  startDate?: string,
  endDateInclusive?: string
): Promise<SchoolIntelligenceSnapshot> {
  try {
    const liveRows = await getSchoolIntelligenceLiveRows(
      raw.schoolUuid,
      startDate,
      endDateInclusive
    );

    if (!liveRows.length) return baseSnapshot;

    // The Live ledger is the canonical first-loop state for the selected
    // historical window. Do NOT require last_reconciled_at here:
    // all 429 currently-unresolved rows in the production audit have
    // last_reconciled_at = NULL, and that timestamp is not an unresolved
    // eligibility gate. Resolution/reconciliation timestamps also must never
    // move an old doubt into today's analytics; the shared Live date filter
    // uses the original doubt date precedence.
    const overlayRaw: SchoolIntelligenceRawData = {
      ...raw,
      feedback: mergeFeedbackUnderstandingLevels(
        raw.feedback,
        liveRows
      ),
      doubts: mergePendingDoubtsWithLiveLedger(
        raw.doubts,
        liveRows,
        { includeUnmatchedLive: true }
      ),
    };

    const liveSnapshot = buildSchoolIntelligenceSnapshot(overlayRaw);

    // The Live layer is additive for live learning signals, but it must not
    // redefine the School Overview doubt-closure cohort. Track Record's
    // canonical closure metric is calculated from the raw pending_teacher_doubts
    // ledger, while this overlay may reconcile matched rows or append live-only
    // rows. Reconciliation state can legitimately differ from the Loop-2
    // pending ledger (including delayed/stale live status), so retain the
    // ledger-derived closure counts/rates from the base snapshot.
    const baseClassroomByAssignment = new Map(
      (baseSnapshot.classrooms ?? []).map((row) => [
        String(row.assignmentUuid ?? ""), row,
      ]),
    );
    const classrooms = (liveSnapshot.classrooms ?? []).map((row) => {
      const ledgerRow = baseClassroomByAssignment.get(
        String(row.assignmentUuid ?? ""),
      );
      return ledgerRow
        ? {
            ...row,
            doubtsAsked: ledgerRow.doubtsAsked,
            doubtsResolved: ledgerRow.doubtsResolved,
            doubtClosureRate: ledgerRow.doubtClosureRate,
          }
        : row;
    });

    const baseTeacherById = new Map(
      (baseSnapshot.teachers ?? []).map((row) => [
        String(row.teacherUuid ?? ""), row,
      ]),
    );
    const teachers = (liveSnapshot.teachers ?? []).map((row) => {
      const ledgerRow = baseTeacherById.get(String(row.teacherUuid ?? ""));
      return ledgerRow
        ? {
            ...row,
            doubtsAsked: ledgerRow.doubtsAsked,
            doubtsResolved: ledgerRow.doubtsResolved,
            doubtClosureRate: ledgerRow.doubtClosureRate,
          }
        : row;
    });

    return {
      ...liveSnapshot,
      stats: {
        ...liveSnapshot.stats,
        doubtsAsked: baseSnapshot.stats.doubtsAsked,
        resolvedDoubts: baseSnapshot.stats.resolvedDoubts,
        doubtResolutionRate: baseSnapshot.stats.doubtResolutionRate,
      },
      classrooms,
      teachers,
    };
  } catch (error) {
    console.error(
      "LIVE SCHOOL INTELLIGENCE OVERLAY FAILED — ORIGINAL SNAPSHOT PRESERVED",
      error
    );
    return baseSnapshot;
  }
}
