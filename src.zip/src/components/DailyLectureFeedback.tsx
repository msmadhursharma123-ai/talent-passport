import jsPDF from "jspdf";
import { Capacitor } from "@capacitor/core";
import { useEffect, useRef, useState } from "react";
import { downloadOrSharePdfBlob } from "../services/platform/nativeDocumentService";

import {
  getStudentDailyLectureLogs,
  getTodaysLectureLogs,
  getStudentSubjects,
  getStudentFeedbackStatementData,
  getStudentMultiCrossQuestions,
  getStudentMultiCrossQuestionAttempts,
} from "../data/studentGrowthPlanRepository";

import {
  UNDERSTANDING_OPTIONS,
  ABSENT_FEEDBACK_OPTION,
} from "../data/studentUnderstandingOptions";

import {
  submitStudentDailyFeedback,
  getStudentFeedbackForLectures,
  getStudentFeedbackHistory,
  getStudentLoop2FeedbackHistory,
  getStudentFeedbackCreditStartDate,
} from "../data/studentDailyFeedbackRepository";

import {
  getStudentLoop1FeedbackDraft,
  saveStudentLoop1FeedbackDraft,
  deleteStudentLoop1FeedbackDraft,
} from "../data/studentLoop1FeedbackDraftRepository";

import {
  getPendingDoubtsByStudent,
  submitStudentPendingDoubtResponse,
} from "../domains/teacherIntelligence/repository/PendingTeacherDoubtRepository";

import {
  getLoop2MultiCrossCapability,
  getLoop2MultiCrossQuestions,
  getLoop2MultiCrossQuestionAttempts,
  recordLoop2MultiCrossQuestionAttempt,
  type Loop2MultiCrossQuestion,
  type Loop2MultiCrossQuestionAttempt,
  type Loop2MultiCrossCapability,
} from "../domains/teacherIntelligence/repository/Loop2MultiCrossQuestionRepository";

import {
  requireIdentity,
} from "../services/identityService";
import { getSupabaseClient } from "../supabaseClient";

import {
  hasLoop1VerificationQuestion,
} from "./loop1Feedback/Loop1FeedbackVerification";
import Loop1FeedbackVerificationDialog from "./loop1Feedback/Loop1FeedbackVerificationDialog";
import Loop1FeedbackVerificationQuestion from "./loop1Feedback/Loop1FeedbackVerificationQuestion";
import MultiCrossQuestionFlow, { type MultiCrossQuestion, type MultiCrossQuestionAttempt } from "./MultiCrossQuestionFlow";
import Loop2MultiCrossQuestionFlow from "./Loop2MultiCrossQuestionFlow";

import {
  calculateDailyFeedbackCreditSummaryFromLogs,
  isStudentLoop2Response,
} from "../data/creditEngine";

interface FeedbackStatementRow {
  id: string;
  loop: "Loop 1" | "Loop 2";
  subjectName: string;
  date: string;
  topic: string;
  chapter: string | null;
  subtopics: string[];
  response: string | null;
  difficultConcepts: string[];
  creditChange: number;
  creditLabel: string;
  balance: number;
}

const ALL_SUBJECTS_VALUE = "__ALL_SUBJECTS__";
const ALL_SUBJECTS_LABEL = "All Subjects";
const LOOP2_MULTICROSS_ROLLOUT_DATE = "2026-11-23";

// Loop-1 feedback drafts are deliberately client-local draft state only. The
// authoritative Cross Question history remains the existing database ledger;
// this draft layer only restores the same in-progress feedback choices when
// the student leaves the page and later returns before a successful submit.
const LOOP1_FEEDBACK_DRAFT_STORAGE_KEY = "tp_loop1_feedback_draft_v53";

type Loop1FeedbackDraft = {
  understandingLevel: string;
  conceptsNotUnderstood: string[];
  somethingElse: boolean;
  somethingElseText: string;
  additionalNote: string;
  verificationStage: "idle" | "question" | "verification" | "corrected" | "wrong" | "no";
  verificationLogId: string | null;
  verificationAnswer: number | null;
  verificationCorrect: boolean | null;
  verificationSecondSelection: string | null;
  verificationNoLock: boolean;
  wrongStartedFromComplete: boolean;
};

type Loop1FeedbackDraftEnvelope = {
  draft: Loop1FeedbackDraft;
  revision: number;
  clientId: string;
  updatedAt: string;
};

let loop1FeedbackDraftClientId: string | null = null;
const loop1FeedbackDraftRevisionFallback = new Map<string, number>();

function getLoop1FeedbackDraftClientId(): string {
  if (loop1FeedbackDraftClientId) return loop1FeedbackDraftClientId;
  loop1FeedbackDraftClientId = typeof crypto !== "undefined" && typeof crypto.randomUUID === "function"
    ? crypto.randomUUID()
    : `tp-${Date.now()}-${Math.random().toString(36).slice(2)}`;
  return loop1FeedbackDraftClientId;
}

function normalizeLoop1FeedbackDraft(draft: any): Loop1FeedbackDraft | null {
  if (!draft || typeof draft !== "object") return null;
  return {
    understandingLevel: typeof draft.understandingLevel === "string" ? draft.understandingLevel : "",
    conceptsNotUnderstood: Array.isArray(draft.conceptsNotUnderstood)
      ? draft.conceptsNotUnderstood.filter((value: unknown): value is string => typeof value === "string")
      : [],
    somethingElse: draft.somethingElse === true,
    somethingElseText: typeof draft.somethingElseText === "string" ? draft.somethingElseText : "",
    additionalNote: typeof draft.additionalNote === "string" ? draft.additionalNote : "",
    verificationStage: ["idle", "question", "verification", "corrected", "wrong", "no"].includes(draft.verificationStage)
      ? draft.verificationStage
      : "idle",
    verificationLogId: typeof draft.verificationLogId === "string" ? draft.verificationLogId : null,
    verificationAnswer: Number.isInteger(draft.verificationAnswer) ? draft.verificationAnswer : null,
    verificationCorrect: typeof draft.verificationCorrect === "boolean" ? draft.verificationCorrect : null,
    verificationSecondSelection: typeof draft.verificationSecondSelection === "string" ? draft.verificationSecondSelection : null,
    verificationNoLock: draft.verificationNoLock === true,
    wrongStartedFromComplete: draft.wrongStartedFromComplete === true,
  };
}

function getLoop1FeedbackDraftStorageKey(): string | null {
  try {
    const identity = requireIdentity();
    return `${LOOP1_FEEDBACK_DRAFT_STORAGE_KEY}:${String(identity.studentUuid)}`;
  } catch {
    return null;
  }
}

function readLoop1FeedbackDraftEnvelope(logId: string): Loop1FeedbackDraftEnvelope | null {
  const storageKey = getLoop1FeedbackDraftStorageKey();
  if (!storageKey || typeof window === "undefined") return null;
  try {
    const raw = window.localStorage.getItem(storageKey);
    if (!raw) return null;
    const allDrafts = JSON.parse(raw);
    const stored = allDrafts?.[String(logId)];
    const draft = normalizeLoop1FeedbackDraft(stored?.draft ?? stored);
    if (!draft) return null;
    return {
      draft,
      revision: Number.isSafeInteger(stored?.revision) && stored.revision >= 0 ? stored.revision : 0,
      clientId: typeof stored?.clientId === "string" ? stored.clientId : "",
      updatedAt: typeof stored?.updatedAt === "string" ? stored.updatedAt : "",
    };
  } catch {
    return null;
  }
}

// All server-draft writes and deletes for the same Daily Log share one
// serialized chain. A delete must never race an older save and allow a stale
// draft to resurrect after successful submission/cancellation.
// Canonical Loop-1 server-draft writer boundary.
// Every server draft SAVE — event-boundary, hydration reconciliation, or
// recovery — must pass through this same serialized/retried/tracked path.
// The existing V60 Supabase RPC remains the authoritative persistence API.
const loop1FeedbackDraftServerChains = new Map<string, Promise<void>>();
const loop1FeedbackDraftPendingWrites = new Map<string, Promise<boolean>>();
const loop1FeedbackDraftUnsyncedLogs = new Set<string>();

function enqueueLoop1FeedbackDraftServerOperation(
  logId: string,
  operation: () => Promise<void>,
): Promise<void> {
  const previous = loop1FeedbackDraftServerChains.get(logId) ?? Promise.resolve();
  const next = previous
    .catch(() => undefined)
    .then(operation);
  loop1FeedbackDraftServerChains.set(logId, next);

  // Cleanup must not create an unhandled rejected promise when `next` rejects.
  void next.then(
    () => {
      if (loop1FeedbackDraftServerChains.get(logId) === next) {
        loop1FeedbackDraftServerChains.delete(logId);
      }
    },
    () => {
      if (loop1FeedbackDraftServerChains.get(logId) === next) {
        loop1FeedbackDraftServerChains.delete(logId);
      }
    },
  );

  return next;
}

async function saveLoop1FeedbackDraftEnvelopeWithRetry(
  logId: string,
  envelope: Loop1FeedbackDraftEnvelope,
): Promise<void> {
  const payload = {
    ...envelope.draft,
    _tp_loop1_draft_meta: {
      revision: envelope.revision,
      clientId: envelope.clientId,
      updatedAt: envelope.updatedAt,
    },
  };
  const retryDelays = [0, 100, 250, 500];
  let lastError: unknown = null;

  for (let attempt = 0; attempt < retryDelays.length; attempt += 1) {
    if (retryDelays[attempt] > 0) {
      await new Promise((resolve) => window.setTimeout(resolve, retryDelays[attempt]));
    }

    try {
      const saved = await saveStudentLoop1FeedbackDraft(
        logId,
        payload,
        envelope.clientId,
        envelope.revision,
        envelope.updatedAt,
      );
      if (saved) return;

      // A false result can mean the server already contains a newer writer's
      // envelope. Confirm that before treating it as a persistence failure.
      const serverDraft = await getStudentLoop1FeedbackDraft(logId);
      if (serverDraft) {
        const serverMeta = (serverDraft.payload as any)?._tp_loop1_draft_meta;
        const serverVersion = {
          updatedAt: typeof serverDraft.client_updated_at === "string" && serverDraft.client_updated_at
            ? serverDraft.client_updated_at
            : (typeof serverMeta?.updatedAt === "string" ? serverMeta.updatedAt : ""),
          revision: Number.isSafeInteger(serverDraft.client_revision) && serverDraft.client_revision >= 0
            ? serverDraft.client_revision
            : (Number.isSafeInteger(serverMeta?.revision) && serverMeta.revision >= 0 ? serverMeta.revision : 0),
          clientId: typeof serverDraft.client_id === "string" && serverDraft.client_id
            ? serverDraft.client_id
            : (typeof serverMeta?.clientId === "string" ? serverMeta.clientId : ""),
        };
        const compare = (
          left: { updatedAt: string; revision: number; clientId: string },
          right: { updatedAt: string; revision: number; clientId: string },
        ) => {
          if (left.updatedAt !== right.updatedAt) return left.updatedAt > right.updatedAt ? 1 : -1;
          if (left.revision !== right.revision) return left.revision > right.revision ? 1 : -1;
          if (left.clientId !== right.clientId) return left.clientId > right.clientId ? 1 : -1;
          return 0;
        };
        const intendedVersion = {
          updatedAt: envelope.updatedAt,
          revision: envelope.revision,
          clientId: envelope.clientId,
        };
        if (compare(serverVersion, intendedVersion) >= 0) return;
      }

      lastError = new Error("Loop-1 server draft save was not confirmed.");
    } catch (error) {
      lastError = error;
    }
  }

  throw lastError ?? new Error("Loop-1 server draft save was not confirmed.");
}

function queueLoop1FeedbackDraftServerEnvelope(
  logId: string,
  envelope: Loop1FeedbackDraftEnvelope,
): Promise<boolean> {
  const operation = enqueueLoop1FeedbackDraftServerOperation(
    logId,
    () => saveLoop1FeedbackDraftEnvelopeWithRetry(logId, envelope),
  );
  const tracked = operation
    .then(() => {
      loop1FeedbackDraftUnsyncedLogs.delete(logId);
      return true;
    })
    .catch((error) => {
      loop1FeedbackDraftUnsyncedLogs.add(logId);
      console.error("LOOP1 SERVER DRAFT SYNC FAILED", error);
      return false;
    });
  loop1FeedbackDraftPendingWrites.set(logId, tracked);
  void tracked.then(
    () => {
      if (loop1FeedbackDraftPendingWrites.get(logId) === tracked) {
        loop1FeedbackDraftPendingWrites.delete(logId);
      }
    },
    () => {
      if (loop1FeedbackDraftPendingWrites.get(logId) === tracked) {
        loop1FeedbackDraftPendingWrites.delete(logId);
      }
    },
  );
  return tracked;
}

function writeLoop1FeedbackDraft(logId: string, draft: Loop1FeedbackDraft, syncServer = false): Promise<boolean> {
  const storageKey = getLoop1FeedbackDraftStorageKey();
  const clientId = getLoop1FeedbackDraftClientId();
  let revision = 0;
  let updatedAt = new Date().toISOString();

  if (storageKey && typeof window !== "undefined") {
    try {
      const raw = window.localStorage.getItem(storageKey);
      const allDrafts = raw ? JSON.parse(raw) : {};
      const previous = allDrafts?.[String(logId)];
      revision = Number.isSafeInteger(previous?.revision) && previous.revision >= 0 ? previous.revision + 1 : 1;
      const envelope: Loop1FeedbackDraftEnvelope = { draft, revision, clientId, updatedAt };
      allDrafts[String(logId)] = envelope;
      window.localStorage.setItem(storageKey, JSON.stringify(allDrafts));
    } catch {
      const previousRevision = loop1FeedbackDraftRevisionFallback.get(logId) ?? 0;
      revision = Math.max(Date.now(), previousRevision + 1);
      loop1FeedbackDraftRevisionFallback.set(logId, revision);
    }
  } else {
    const previousRevision = loop1FeedbackDraftRevisionFallback.get(logId) ?? 0;
    revision = Math.max(Date.now(), previousRevision + 1);
    loop1FeedbackDraftRevisionFallback.set(logId, revision);
  }

  if (!syncServer) return Promise.resolve(true);

  return queueLoop1FeedbackDraftServerEnvelope(logId, {
    draft,
    revision,
    clientId,
    updatedAt,
  });
}

async function flushLoop1FeedbackDraft(logId: string): Promise<boolean> {
  const pending = loop1FeedbackDraftPendingWrites.get(logId);
  if (pending) return pending;
  if (loop1FeedbackDraftUnsyncedLogs.has(logId)) return false;
  const chain = loop1FeedbackDraftServerChains.get(logId);
  if (chain) {
    try {
      await chain;
      return true;
    } catch (error) {
      console.error("LOOP1 SERVER DRAFT FLUSH FAILED", error);
      return false;
    }
  }
  return true;
}

function writeLoop1FeedbackDraftEnvelope(logId: string, envelope: Loop1FeedbackDraftEnvelope) {
  const storageKey = getLoop1FeedbackDraftStorageKey();
  if (!storageKey || typeof window === "undefined") return;
  try {
    const raw = window.localStorage.getItem(storageKey);
    const allDrafts = raw ? JSON.parse(raw) : {};
    allDrafts[String(logId)] = envelope;
    window.localStorage.setItem(storageKey, JSON.stringify(allDrafts));
  } catch {
    // Recovery remains server-backed.
  }
}

async function clearLoop1FeedbackDraft(logId: string): Promise<boolean> {
  const storageKey = getLoop1FeedbackDraftStorageKey();

  // Queue the delete behind every earlier server save for this log. The
  // successful-feedback acknowledgement must never race a pending draft save.
  try {
    await enqueueLoop1FeedbackDraftServerOperation(logId, async () => {
      const retryDelays = [0, 100, 250, 500];
      let lastError: unknown = null;
      for (let attempt = 0; attempt < retryDelays.length; attempt += 1) {
        if (retryDelays[attempt] > 0) {
          await new Promise((resolve) => window.setTimeout(resolve, retryDelays[attempt]));
        }
        try {
          const deleted = await deleteStudentLoop1FeedbackDraft(logId);
          if (deleted) return;
          lastError = new Error("Loop-1 server draft delete was not confirmed.");
        } catch (error) {
          lastError = error;
        }
      }
      throw lastError ?? new Error("Loop-1 server draft delete was not confirmed.");
    });

    // Only remove the local cache after the server-side draft deletion has been
    // confirmed. If the server is temporarily unavailable, retaining the local
    // snapshot preserves the recovery fallback instead of destroying the only
    // immediately available copy.
    loop1FeedbackDraftUnsyncedLogs.delete(logId);

    if (storageKey && typeof window !== "undefined") {
      try {
        const raw = window.localStorage.getItem(storageKey);
        if (raw) {
          const allDrafts = JSON.parse(raw);
          if (allDrafts && typeof allDrafts === "object") {
            delete allDrafts[String(logId)];
            window.localStorage.setItem(storageKey, JSON.stringify(allDrafts));
          }
        }
      } catch {
        // The authoritative server draft is already cleared. A local-cache
        // cleanup failure must not block the completed acknowledgement path.
      }
    }
    return true;
  } catch (error) {
    console.error("LOOP1 SERVER DRAFT DELETE FAILED", error);
    return false;
  }
}

async function downloadPdfBlobOnWeb(blob: Blob, fileName: string) {
  const pdfUrl = URL.createObjectURL(blob);
  const anchor = document.createElement("a");

  anchor.href = pdfUrl;
  anchor.download = fileName;
  anchor.rel = "noopener";
  anchor.style.display = "none";

  document.body.appendChild(anchor);
  anchor.click();
  anchor.remove();

  // Do not revoke immediately. Mobile/tablet browsers can start the
  // download asynchronously after the synthetic anchor click. Keeping the
  // Blob URL alive gives those browsers time to begin the file transfer.
  window.setTimeout(() => {
    URL.revokeObjectURL(pdfUrl);
  }, 60_000);
}

function getIndiaTodayKey() {
  const parts = new Intl.DateTimeFormat("en-CA", {
    timeZone: "Asia/Kolkata",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  }).formatToParts(new Date());

  const year = parts.find((part) => part.type === "year")?.value ?? "";
  const month = parts.find((part) => part.type === "month")?.value ?? "";
  const day = parts.find((part) => part.type === "day")?.value ?? "";

  return `${year}-${month}-${day}`;
}

function toDateKey(value: unknown) {
  if (value === null || value === undefined) return "";

  const raw = String(value).trim();
  if (!raw) return "";

  if (/^\d{4}-\d{2}-\d{2}$/.test(raw)) {
    return raw;
  }

  const parsed = new Date(raw);
  if (Number.isNaN(parsed.getTime())) {
    return raw.slice(0, 10);
  }

  const parts = new Intl.DateTimeFormat("en-CA", {
    timeZone: "Asia/Kolkata",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  }).formatToParts(parsed);

  const year = parts.find((part) => part.type === "year")?.value ?? "";
  const month = parts.find((part) => part.type === "month")?.value ?? "";
  const day = parts.find((part) => part.type === "day")?.value ?? "";

  return `${year}-${month}-${day}`;
}

function formatStatementDate(value: string) {
  if (!value) return "—";

  const parts = value.split("-");
  if (parts.length !== 3) return value;

  return `${parts[2]}/${parts[1]}/${parts[0]}`;
}

function getResponseLabel(value: string | null | undefined) {
  if (!value) return "Pending";

  if (value === "I completely understood.") {
    return "I completely understood";
  }

  if (value === "I partially understood.") {
    return "I partially understood";
  }

  if (value === "I didn't understand.") {
    return "I didn't understand";
  }

  if (value === ABSENT_FEEDBACK_OPTION) {
    return "I was absent";
  }

  return value.replace(/\.$/, "");
}

export default function DailyLectureFeedback() {
  const [lectureLogs, setLectureLogs] = useState<any[]>([]);
  const [isLoadingLogs, setIsLoadingLogs] = useState(true);

  const [expandedCard, setExpandedCard] = useState<string | null>(null);

  const [understandingLevel, setUnderstandingLevel] = useState("");
  // V68: keep the synchronous resume context keyed to the exact Daily Log.
  // A single global fallback value can leak the previous card's understanding
  // into a newly opened card during the render/hydration boundary. The keyed
  // context makes the fallback valid only for the log that actually supplied it.
  const loop1UnderstandingResumeRef = useRef<{ logId: string | null; value: string }>({
    logId: null,
    value: "",
  });

  function setLoop1UnderstandingLevelForLog(logId: string, value: string) {
    loop1UnderstandingResumeRef.current = { logId, value };
    setUnderstandingLevel(value);
  }

  function clearLoop1UnderstandingResume(logId?: string | null) {
    if (logId == null || loop1UnderstandingResumeRef.current.logId === logId) {
      loop1UnderstandingResumeRef.current = { logId: null, value: "" };
    }
  }

  function prepareLoop1UnderstandingResume(logId: string) {
    loop1UnderstandingResumeRef.current = { logId, value: "" };
  }

  // V70: one explicit card-transition boundary. Every path that opens a
  // Loop-1 feedback card first resets ALL transient feedback/verification UI
  // state synchronously, then binds the resume context to the target Daily
  // Log. The previous card's durable draft and server question ledger are not
  // deleted or mutated; they remain available for target-specific hydration.
  // This makes card ownership explicit instead of relying on the current
  // verificationLogId being non-null.
  function resetLoop1TransientFeedbackState() {
    loop1VerificationIntentRef.current += 1;
    loop1VerificationAnswerLockRef.current.clear();
    loop1VerificationNoLockLogIdRef.current = null;
    loop1VerificationActivationLogIdRef.current = null;
    setLoop1VerificationStage("idle");
    setLoop1VerificationLogId(null);
    setLoop1VerificationAnswer(null);
    setLoop1VerificationCorrect(null);
    setLoop1VerificationSecondSelection(null);
    setUnderstandingLevel("");
    setConceptsNotUnderstood([]);
    setSomethingElse(false);
    setSomethingElseText("");
    setAdditionalNote("");
  }

  function openLoop1FeedbackCard(logId: string) {
    // V76: opening a card starts a fresh ownership boundary. If this is the
    // card that was just closed, release its temporary write suppression now
    // so normal event/effect persistence can resume.
    if (loop1FeedbackDraftClosingLogIdRef.current === logId) {
      loop1FeedbackDraftClosingLogIdRef.current = null;
    }
    resetLoop1TransientFeedbackState();
    loop1FeedbackDraftUserTouchedLogIdsRef.current.delete(logId);
    setLoop1FeedbackDraftHydratedLogId(null);
    prepareLoop1UnderstandingResume(logId);
    setExpandedCard(logId);
    setFeedbackSubmitError(null);
  }
  const [conceptsNotUnderstood, setConceptsNotUnderstood] = useState<string[]>([]);
  const [somethingElse, setSomethingElse] = useState(false);
  const [somethingElseText, setSomethingElseText] = useState("");
  const [additionalNote, setAdditionalNote] = useState("");

  const [pendingDoubts, setPendingDoubts] = useState<any[]>([]);
  const [historicalLectureLogs, setHistoricalLectureLogs] = useState<any[]>([]);
  const [loop2QuestionDoubtId, setLoop2QuestionDoubtId] = useState<string | null>(null);
  // Synchronous ownership guard for the currently open guided Cross Question.
  const activeLoop2QuestionDoubtRef = useRef<string | null>(null);
  const [loop2QuestionAnswers, setLoop2QuestionAnswers] = useState<Record<string, number>>({});
  const [loop2QuestionBusyId, setLoop2QuestionBusyId] = useState<string | null>(null);
  const [pendingDoubtAutoSubmittingId, setPendingDoubtAutoSubmittingId] = useState<string | null>(null);
  // Synchronous guard prevents same-tick double submissions before React rerenders.
  const pendingDoubtAutoSubmitLockRef = useRef<Set<string>>(new Set());
  const [loop2QuestionImageFailedIds, setLoop2QuestionImageFailedIds] = useState<Record<string, boolean>>({});
  const [loop2QuestionImageLoadedIds, setLoop2QuestionImageLoadedIds] = useState<Record<string, boolean>>({});
  const [loop2QuestionMessage, setLoop2QuestionMessage] = useState<{ doubtId: string; correct: boolean; text: string } | null>(null);
  // Additive Loop-2 terminal acknowledgement. This is UI-only: it is shown
  // only after the existing authoritative response has been recorded, and
  // the existing guided queue is allowed to continue only after the 850ms
  // acknowledgement lifecycle completes or the student explicitly closes it.
  const [loop1FeedbackSuccessPopup, setLoop1FeedbackSuccessPopup] = useState(false);
  const loop1FeedbackSuccessPopupCloseRef = useRef<(() => void) | null>(null);
  const [loop2ResolutionPopup, setLoop2ResolutionPopup] = useState<{
    doubtId: string;
    kind: "DISCUSSED" | "NOT DISCUSSED";
    text: string;
  } | null>(null);
  const loop2ResolutionPopupCloseRef = useRef<(() => void) | null>(null);
  const [loop2MultiQuestionsByDoubt, setLoop2MultiQuestionsByDoubt] = useState<Record<string, Loop2MultiCrossQuestion[]>>({});
  const [loop2MultiAttemptsByDoubt, setLoop2MultiAttemptsByDoubt] = useState<Record<string, Record<string, Loop2MultiCrossQuestionAttempt>>>({});
  const [loop2MultiLoadingDoubtId, setLoop2MultiLoadingDoubtId] = useState<string | null>(null);
  const [selectedResponse, setSelectedResponse] = useState<Record<string, string>>({});
  const [submittedFeedback, setSubmittedFeedback] = useState<Record<string, any>>({});
  const [crossQuestionAnswers, setCrossQuestionAnswers] = useState<Record<string, number>>({});
  const [crossQuestionResults, setCrossQuestionResults] = useState<Record<string, boolean>>({});
  const [multiCrossQuestionsByLog, setMultiCrossQuestionsByLog] = useState<Record<string, MultiCrossQuestion[]>>({});
  const [multiCrossAttemptsByLog, setMultiCrossAttemptsByLog] = useState<Record<string, Record<string, MultiCrossQuestionAttempt>>>({});

  // Additive top-up state. Existing Loop-1 Cross Question state and handlers remain untouched.
  const loop1VerificationIntentRef = useRef(0);
  const loop1VerificationAnswerLockRef = useRef<Set<string>>(new Set());
  const loop1VerificationAttemptHistoryReadyRef = useRef(false);
  const loop1VerificationNoLockLogIdRef = useRef<string | null>(null);
  // Synchronous marker used by the understanding radio's own onChange handler.
  // React state is not updated until after the event, so the capture handler
  // needs a same-event guard to prevent the legacy Partial/Didn't scroll target
  // from overwriting the verification-question target.
  const loop1VerificationActivationLogIdRef = useRef<string | null>(null);
  // Remembers whether a multi-question terminal wrong answer originated from
  // the Complete selection. In that path Partial/Didn't remain switchable;
  // when the student originally chose Partial/Didn't, the understanding
  // choices are hidden after the wrong answer and concepts are shown directly.
  const multiWrongStartedFromCompleteRef = useRef<Set<string>>(new Set());
  const [loop1VerificationStage, setLoop1VerificationStage] = useState<"idle" | "question" | "verification" | "corrected" | "wrong" | "no">("idle");
  const [loop1VerificationLogId, setLoop1VerificationLogId] = useState<string | null>(null);
  const [loop1VerificationAnswer, setLoop1VerificationAnswer] = useState<number | null>(null);
  const [loop1VerificationCorrect, setLoop1VerificationCorrect] = useState<boolean | null>(null);
  const [loop1VerificationSecondSelection, setLoop1VerificationSecondSelection] = useState<string | null>(null);
  const [crossQuestionImageViewerUrl, setCrossQuestionImageViewerUrl] = useState<string | null>(null);
  const [guidedScrollTarget, setGuidedScrollTarget] = useState<{ logId: string; section: "understanding" | "concepts" | "question" | "credits" | "doubt" | "loop2question" } | null>(null);
  const [guidedDoubtHighlightId, setGuidedDoubtHighlightId] = useState<string | null>(null);

  const [isSubmittingFeedbackId, setIsSubmittingFeedbackId] = useState<string | null>(null);
  const [feedbackSubmitError, setFeedbackSubmitError] = useState<string | null>(null);
  // Prevent a newly opened card from overwriting its stored draft with the
  // previous card's React state before the draft has been rehydrated.
  const [loop1FeedbackDraftHydratedLogId, setLoop1FeedbackDraftHydratedLogId] = useState<string | null>(null);
  // If the student interacts with a newly opened card before its question map
  // finishes loading, that live interaction must win over an older saved draft.
  // This prevents late hydration from unexpectedly reverting a fresh choice.
  const loop1FeedbackDraftUserTouchedLogIdsRef = useRef<Set<string>>(new Set());

  // V76: a closing card owns a short-lived write-suppression boundary. Once
  // CANCEL or an in-app card switch begins, the newest draft has already been
  // flushed (or is being flushed) and the transient React reset must never be
  // allowed to generate a second, empty draft write for that closing Daily Log.
  // This is deliberately scoped to the exact log being closed.
  const loop1FeedbackDraftClosingLogIdRef = useRef<string | null>(null);

  // Event-boundary persistence helper: state/effect persistence is retained for
  // normal updates, but any user action that can change an unfinished draft also
  // snapshots the resulting value synchronously before navigation/unmount can win.
  function persistLoop1FeedbackDraftSnapshot(
    logId: string,
    overrides: Partial<Loop1FeedbackDraft> = {},
  ) {
    // V76: once this Daily Log has entered its close boundary, no later UI
    // event is allowed to enqueue another draft write. The close path first
    // flushes the newest durable snapshot and only then resets transient state.
    if (loop1FeedbackDraftClosingLogIdRef.current === logId) return;

    const effectiveUnderstandingLevel =
      overrides.understandingLevel ?? getEffectiveLoop1UnderstandingLevel(logId);
    const isVerificationForLog = loop1VerificationLogId === logId;
    writeLoop1FeedbackDraft(logId, {
      understandingLevel: effectiveUnderstandingLevel,
      conceptsNotUnderstood,
      somethingElse,
      somethingElseText,
      additionalNote,
      verificationStage: isVerificationForLog ? loop1VerificationStage : "idle",
      verificationLogId: isVerificationForLog ? loop1VerificationLogId : null,
      verificationAnswer: isVerificationForLog ? loop1VerificationAnswer : null,
      verificationCorrect: isVerificationForLog ? loop1VerificationCorrect : null,
      verificationSecondSelection: isVerificationForLog ? loop1VerificationSecondSelection : null,
      verificationNoLock: loop1VerificationNoLockLogIdRef.current === logId,
      wrongStartedFromComplete: multiWrongStartedFromCompleteRef.current.has(logId),
      ...overrides,
    }, true);
  }

  const [dailyFeedbackEarnedCredits, setDailyFeedbackEarnedCredits] = useState(0);
  const [dailyFeedbackLostCredits, setDailyFeedbackLostCredits] = useState(0);
  const [dailyFeedbackTotalCredits, setDailyFeedbackTotalCredits] = useState(0);
  const [isLoadingCreditSummary, setIsLoadingCreditSummary] = useState(true);

  const [subjectOptions, setSubjectOptions] = useState<string[]>([]);
  const [statementSubject, setStatementSubject] = useState("");
  const [statementStartDate, setStatementStartDate] = useState("");
  const [statementEndDate, setStatementEndDate] = useState("");
  const [statementRows, setStatementRows] = useState<FeedbackStatementRow[]>([]);
  const [hasFetchedStatement, setHasFetchedStatement] = useState(false);
  const [isFetchingStatement, setIsFetchingStatement] = useState(false);
  const [statementError, setStatementError] = useState<string | null>(null);
  const [isGeneratingStatementPdf, setIsGeneratingStatementPdf] = useState(false);

  useEffect(() => {
    if (!crossQuestionImageViewerUrl) return;
    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key === "Escape") setCrossQuestionImageViewerUrl(null);
    };
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [crossQuestionImageViewerUrl]);

  useEffect(() => {
    void loadPageData();
    void loadDailyFeedbackCreditSummary();
  }, []);

  useEffect(() => {
    if (!loop1VerificationLogId || loop1VerificationLogId === expandedCard) return;
    clearLoop1Verification(loop1VerificationLogId);
  }, [expandedCard, loop1VerificationLogId]);

  // Rehydrate only an unfinished Loop-1 Multi-Cross feedback card. The
  // question ledger in the database remains authoritative for Q1/Q2/Q3...;
  // this session draft restores only the surrounding feedback selections.
  // Importantly, hydration waits until the Multi-Cross question map is loaded
  // so legacy/non-Multi-Cross feedback is never altered by this feature.
  useEffect(() => {
    if (!expandedCard || submittedFeedback[expandedCard]) return;
    if ((multiCrossQuestionsByLog[expandedCard] ?? []).length < 2) return;
    if (!loop1VerificationAttemptHistoryReadyRef.current) return;
    if (loop1FeedbackDraftHydratedLogId === expandedCard) return;

    let cancelled = false;
    const hydrate = async () => {
      const wasTouchedBeforeHydration = loop1FeedbackDraftUserTouchedLogIdsRef.current.has(expandedCard);
      const localEnvelope = wasTouchedBeforeHydration ? null : readLoop1FeedbackDraftEnvelope(expandedCard);
      const serverDraft = !wasTouchedBeforeHydration ? await getStudentLoop1FeedbackDraft(expandedCard) : null;
      let draft = localEnvelope?.draft ?? null;

      if (!cancelled && !loop1FeedbackDraftUserTouchedLogIdsRef.current.has(expandedCard)) {
        const serverPayload = serverDraft?.payload as any;
        const serverMeta = serverPayload?._tp_loop1_draft_meta;
        const serverRevision = Number.isSafeInteger(serverDraft?.client_revision) && serverDraft.client_revision >= 0
          ? serverDraft.client_revision
          : (Number.isSafeInteger(serverMeta?.revision) && serverMeta.revision >= 0 ? serverMeta.revision : 0);
        const localRevision = localEnvelope?.revision ?? 0;
        const localClientId = localEnvelope?.clientId ?? "";
        const serverClientId = typeof serverDraft?.client_id === "string" && serverDraft.client_id
          ? serverDraft.client_id
          : (typeof serverMeta?.clientId === "string" ? serverMeta.clientId : "");
        const localUpdatedAt = localEnvelope?.updatedAt ?? "";
        const serverUpdatedAt = typeof serverDraft?.client_updated_at === "string" && serverDraft.client_updated_at
          ? serverDraft.client_updated_at
          : (typeof serverMeta?.updatedAt === "string" ? serverMeta.updatedAt : "");
        const localVersion = {
          updatedAt: localUpdatedAt,
          revision: localRevision,
          clientId: localClientId,
        };
        const serverVersion = {
          updatedAt: serverUpdatedAt,
          revision: serverRevision,
          clientId: serverClientId,
        };
        const compareDraftVersions = (left: typeof localVersion, right: typeof serverVersion) => {
          if (left.updatedAt !== right.updatedAt) return left.updatedAt > right.updatedAt ? 1 : -1;
          if (left.revision !== right.revision) return left.revision > right.revision ? 1 : -1;
          if (left.clientId !== right.clientId) return left.clientId > right.clientId ? 1 : -1;
          return 0;
        };
        const versionComparison = compareDraftVersions(localVersion, serverVersion);
        const serverWins = !!serverPayload && versionComparison < 0;
        const localWins = !!localEnvelope && versionComparison >= 0;

        if (serverWins) {
          const serverNormalized = normalizeLoop1FeedbackDraft(serverPayload);
          if (serverNormalized) {
            draft = serverNormalized;
            writeLoop1FeedbackDraftEnvelope(expandedCard, {
              draft: serverNormalized,
              revision: serverRevision,
              clientId: typeof serverDraft?.client_id === "string" && serverDraft.client_id
                ? serverDraft.client_id
                : (typeof serverMeta?.clientId === "string" ? serverMeta.clientId : getLoop1FeedbackDraftClientId()),
              updatedAt: serverUpdatedAt || (typeof serverDraft?.updated_at === "string" && serverDraft.updated_at
                ? serverDraft.updated_at
                : new Date().toISOString()),
            });
          }
        } else if (localWins && localEnvelope) {
          draft = localEnvelope.draft;
          const localMeta = {
            ...localEnvelope.draft,
            _tp_loop1_draft_meta: {
              revision: localEnvelope.revision,
              clientId: localEnvelope.clientId || getLoop1FeedbackDraftClientId(),
              updatedAt: localEnvelope.updatedAt || new Date().toISOString(),
            },
          };
          const reconciliationSaved = await queueLoop1FeedbackDraftServerEnvelope(expandedCard, {
            draft: localEnvelope.draft,
            revision: localMeta._tp_loop1_draft_meta.revision,
            clientId: localMeta._tp_loop1_draft_meta.clientId,
            updatedAt: localMeta._tp_loop1_draft_meta.updatedAt,
          });
          if (!reconciliationSaved) {
            // The local snapshot remains the visible recovery source, but the
            // log is explicitly marked unsynced. Any in-app navigation must
            // therefore stop until a later canonical save succeeds.
            loop1FeedbackDraftUnsyncedLogs.add(expandedCard);
          }
        } else if (!localEnvelope && serverPayload) {
          const serverNormalized = normalizeLoop1FeedbackDraft(serverPayload);
          if (serverNormalized) {
            draft = serverNormalized;
            writeLoop1FeedbackDraftEnvelope(expandedCard, {
              draft: serverNormalized,
              revision: serverRevision,
              clientId: typeof serverDraft?.client_id === "string" && serverDraft.client_id
                ? serverDraft.client_id
                : (typeof serverMeta?.clientId === "string" ? serverMeta.clientId : getLoop1FeedbackDraftClientId()),
              updatedAt: serverUpdatedAt || (typeof serverDraft?.updated_at === "string" && serverDraft.updated_at
                ? serverDraft.updated_at
                : new Date().toISOString()),
            });
          }
        }
      }

      if (cancelled || loop1FeedbackDraftUserTouchedLogIdsRef.current.has(expandedCard)) return;
      if (draft) {
      // V68: if a persisted wrong-terminal draft predates the explicit origin
      // marker, derive that marker from the persisted Complete selection.
      if (draft.verificationStage === "wrong" && draft.understandingLevel === "I completely understood.") {
        draft = { ...draft, wrongStartedFromComplete: true };
      }
      // Reconcile the surrounding verification state against the authoritative
      // Loop-1 Multi-Cross attempt ledger before restoring the draft. This is
      // recovery-only: it never submits feedback on mount. If the last answer
      // committed but the browser disappeared before the local transition
      // handler ran, the server ledger still determines whether the unfinished
      // flow is wrong-terminal or ready for the verification decision.
      const hydratedMultiQuestions = multiCrossQuestionsByLog[expandedCard] ?? [];
      const hydratedMultiAttempts = multiCrossAttemptsByLog[expandedCard] ?? {};
      const hydratedMultiWrong = hydratedMultiQuestions.some(
        (question) => hydratedMultiAttempts[question.id]?.is_correct === false,
      );
      const hydratedMultiAllCorrect = hydratedMultiQuestions.length >= 2 && hydratedMultiQuestions.every(
        (question) => hydratedMultiAttempts[question.id]?.is_correct === true,
      );
      if (hydratedMultiWrong) {
        draft = {
          ...draft,
          verificationLogId: expandedCard,
          verificationStage: "wrong",
          verificationNoLock: false,
        };
      } else if (hydratedMultiAllCorrect) {
        draft = {
          ...draft,
          verificationLogId: expandedCard,
          // Complete keeps the completed question ledger visible without
          // opening the verification dialog; Partial/Didn't must resume at
          // the existing verification decision. Neither branch submits here.
          verificationStage:
            draft.understandingLevel === "I completely understood."
              ? "question"
              : "verification",
          verificationNoLock: false,
        };
      }
      // If the student left while the legacy verification RPC was still in
      // flight, the local/server draft can contain the selected answer while
      // verificationCorrect is still null. The existing server attempt ledger
      // is authoritative, so refresh that one legacy attempt before deciding
      // what state to restore. This closes the exact:
      // answer -> immediate leave -> RPC commits -> reopen race.
      let ledgerAnswer = crossQuestionAnswers[expandedCard];
      let ledgerResult = crossQuestionResults[expandedCard];
      const needsLegacyLedgerRecovery =
        draft.verificationLogId === expandedCard &&
        draft.verificationAnswer !== null &&
        draft.verificationCorrect === null &&
        !(ledgerAnswer === draft.verificationAnswer && typeof ledgerResult === "boolean");

      if (needsLegacyLedgerRecovery) {
        try {
          const supabase = getSupabaseClient();
          if (supabase) {
            // Recover through the SAME existing authoritative RPC first.
            // The RPC is idempotent for an exact replay, so if the original
            // answer transaction is still in flight, this recovery call is
            // serialized by the database and returns the authoritative
            // attempt once it exists. This avoids relying on an arbitrary
            // client-side timeout window. No result is invented.
            const recoveryAttempts = [0, 100, 250];
            for (let recoveryIndex = 0; recoveryIndex < recoveryAttempts.length; recoveryIndex += 1) {
              if (recoveryAttempts[recoveryIndex] > 0) {
                await new Promise((resolve) => window.setTimeout(resolve, recoveryAttempts[recoveryIndex]));
              }
              if (cancelled || loop1FeedbackDraftUserTouchedLogIdsRef.current.has(expandedCard)) break;

              try {
                const { data: replayData, error: replayError } = await (supabase as any).rpc(
                  "tp_record_daily_cross_question_attempt",
                  {
                    p_daily_log_uuid: expandedCard,
                    p_selected_index: draft.verificationAnswer,
                  },
                );
                if (!replayError) {
                  const replayAttempt = Array.isArray(replayData) ? replayData[0] : replayData;
                  if (replayAttempt && typeof replayAttempt.is_correct === "boolean") {
                    ledgerAnswer = Number(draft.verificationAnswer);
                    ledgerResult = replayAttempt.is_correct === true;
                    setCrossQuestionAnswers((previous) => ({ ...previous, [expandedCard]: ledgerAnswer as number }));
                    setCrossQuestionResults((previous) => ({ ...previous, [expandedCard]: ledgerResult as boolean }));
                    break;
                  }
                }
              } catch (replayRecoveryError) {
                console.warn("LOOP1 VERIFICATION RPC RECOVERY RETRY FAILED", replayRecoveryError);
              }

              // If the replay RPC cannot currently return the authoritative
              // attempt, read the same legacy ledger as a secondary recovery
              // path. It is only accepted when the server exposes the exact
              // selected answer and its boolean result.
              try {
                const { data: ledgerAttempt, error: ledgerError } = await (supabase as any)
                  .from("student_daily_cross_question_attempts")
                  .select("selected_index,is_correct")
                  .eq("daily_log_uuid", expandedCard)
                  .maybeSingle();
                if (!ledgerError && ledgerAttempt && Number(ledgerAttempt.selected_index) === Number(draft.verificationAnswer) && typeof ledgerAttempt.is_correct === "boolean") {
                  ledgerAnswer = Number(ledgerAttempt.selected_index);
                  ledgerResult = ledgerAttempt.is_correct === true;
                  setCrossQuestionAnswers((previous) => ({ ...previous, [expandedCard]: ledgerAnswer as number }));
                  setCrossQuestionResults((previous) => ({ ...previous, [expandedCard]: ledgerResult as boolean }));
                  break;
                }
              } catch (ledgerRecoveryError) {
                console.warn("LOOP1 VERIFICATION LEDGER RECOVERY FAILED", ledgerRecoveryError);
              }
            }
          }
        } catch (ledgerRecoveryError) {
          console.warn("LOOP1 VERIFICATION LEDGER RECOVERY FAILED", ledgerRecoveryError);
        }
      }

      const hasLedgerVerification =
        draft.verificationLogId === expandedCard &&
        draft.verificationAnswer !== null &&
        ledgerAnswer === draft.verificationAnswer &&
        typeof ledgerResult === "boolean";
      const recoveredVerificationCorrect = hasLedgerVerification
        ? ledgerResult
        : draft.verificationCorrect;
      const recoveredVerificationStage = hasLedgerVerification
        ? (ledgerResult ? "verification" : "wrong")
        : draft.verificationStage;
      loop1UnderstandingResumeRef.current = { logId: expandedCard, value: draft.understandingLevel };
      setUnderstandingLevel(draft.understandingLevel);
      setConceptsNotUnderstood(draft.conceptsNotUnderstood);
      setSomethingElse(draft.somethingElse);
      setSomethingElseText(draft.somethingElseText);
      setAdditionalNote(draft.additionalNote);
      setLoop1VerificationStage(recoveredVerificationStage);
      setLoop1VerificationLogId(draft.verificationLogId === expandedCard ? draft.verificationLogId : null);
      setLoop1VerificationAnswer(draft.verificationAnswer);
      setLoop1VerificationCorrect(recoveredVerificationCorrect);
      setLoop1VerificationSecondSelection(draft.verificationSecondSelection);
      if (draft.verificationNoLock && draft.verificationLogId === expandedCard) {
        loop1VerificationNoLockLogIdRef.current = expandedCard;
      } else if (loop1VerificationNoLockLogIdRef.current === expandedCard) {
        loop1VerificationNoLockLogIdRef.current = null;
      }
      if (draft.wrongStartedFromComplete && draft.verificationLogId === expandedCard) {
        multiWrongStartedFromCompleteRef.current.add(expandedCard);
      } else {
        multiWrongStartedFromCompleteRef.current.delete(expandedCard);
      }
      }

      // Mark hydration through React state so the save effect cannot run with
      // stale state from the previous card in the same effect cycle.
      setLoop1FeedbackDraftHydratedLogId(expandedCard);
    };

    void hydrate();
    return () => {
      cancelled = true;
    };
  }, [expandedCard, submittedFeedback, multiCrossQuestionsByLog, multiCrossAttemptsByLog, loop1FeedbackDraftHydratedLogId, crossQuestionAnswers, crossQuestionResults]);

  // Save an unfinished feedback draft as soon as the student has actually
  // interacted with the open card. This early write is intentionally allowed
  // before the Multi-Cross question map finishes loading: otherwise a student
  // who selects an option and immediately leaves could lose that selection.
  // The draft is still only rehydrated for confirmed Loop-1 Multi-Cross cards,
  // so legacy/non-Multi-Cross UI behavior is unchanged. After hydration, the
  // normal gate continues to protect against stale-card overwrites.
  useEffect(() => {
    if (!expandedCard || submittedFeedback[expandedCard]) return;
    // V76: the close boundary is stronger than the background save effect.
    // CANCEL/card-switch flushes the newest durable draft first; once closing
    // begins, this effect must not write the transient reset state back over it.
    if (loop1FeedbackDraftClosingLogIdRef.current === expandedCard) return;
    const isConfirmedMultiCross = (multiCrossQuestionsByLog[expandedCard] ?? []).length >= 2;
    const wasTouched = loop1FeedbackDraftUserTouchedLogIdsRef.current.has(expandedCard);
    if (!wasTouched && loop1FeedbackDraftHydratedLogId !== expandedCard) return;
    if (isConfirmedMultiCross === false && !wasTouched) return;

    // V73: the generic draft effect must use the same log-scoped synchronous
    // understanding source as every answer-event boundary. After a terminal
    // wrong answer, React state can still be one render behind while the
    // resume ref already contains the authoritative Partial/Didn't selection.
    // Reading raw `understandingLevel` here could therefore overwrite the
    // correct wrong-terminal draft with an empty understanding value.
    // Never let this background save clobber the V70/V71/V72 resume context.
    const effectiveUnderstandingLevelForSave = getEffectiveLoop1UnderstandingLevel(expandedCard);

    writeLoop1FeedbackDraft(expandedCard, {
      understandingLevel: effectiveUnderstandingLevelForSave,
      conceptsNotUnderstood,
      somethingElse,
      somethingElseText,
      additionalNote,
      verificationStage: loop1VerificationStage,
      verificationLogId: loop1VerificationLogId === expandedCard ? loop1VerificationLogId : null,
      verificationAnswer: loop1VerificationLogId === expandedCard ? loop1VerificationAnswer : null,
      verificationCorrect: loop1VerificationLogId === expandedCard ? loop1VerificationCorrect : null,
      verificationSecondSelection: loop1VerificationLogId === expandedCard ? loop1VerificationSecondSelection : null,
      verificationNoLock: loop1VerificationNoLockLogIdRef.current === expandedCard,
      wrongStartedFromComplete: multiWrongStartedFromCompleteRef.current.has(expandedCard),
    }, isConfirmedMultiCross);
  }, [
    expandedCard,
    submittedFeedback,
    multiCrossQuestionsByLog,
    loop1FeedbackDraftHydratedLogId,
    understandingLevel,
    conceptsNotUnderstood,
    somethingElse,
    somethingElseText,
    additionalNote,
    loop1VerificationStage,
    loop1VerificationLogId,
    loop1VerificationAnswer,
    loop1VerificationCorrect,
    loop1VerificationSecondSelection,
  ]);

  useEffect(() => {
    if (!guidedScrollTarget) return;
    const targetId = guidedScrollTarget.section === "understanding"
      ? `dlf-understanding-${guidedScrollTarget.logId}`
      : guidedScrollTarget.section === "concepts"
        ? `dlf-concepts-${guidedScrollTarget.logId}`
        : guidedScrollTarget.section === "question"
          ? `dlf-question-${guidedScrollTarget.logId}`
          : guidedScrollTarget.section === "doubt"
            ? `dlf-pending-doubt-${guidedScrollTarget.logId}`
            : guidedScrollTarget.section === "loop2question"
              ? `dlf-loop2-question-${guidedScrollTarget.logId}`
              : "dlf-credit-section";
    const frame = window.requestAnimationFrame(() => {
      document.getElementById(targetId)?.scrollIntoView({
        behavior: "smooth",
        block: "center",
      });
      setGuidedScrollTarget(null);
    });
    return () => window.cancelAnimationFrame(frame);
  }, [guidedScrollTarget, understandingLevel, conceptsNotUnderstood, somethingElse, pendingDoubts, lectureLogs, submittedFeedback]);

  async function loadPageData() {
    loop1VerificationAttemptHistoryReadyRef.current = false;
    setIsLoadingLogs(true);

    try {
      // Critical path: fetch ONLY today's logs. The old page downloaded
      // the complete lecture history before it could render today's cards.
      const todaysLogs = await getTodaysLectureLogs();

      setLectureLogs(todaysLogs ?? []);
      setIsLoadingLogs(false);

      // V11 additive multi-question read path. Legacy scalar attempts remain
      // loaded exactly as before for historical/Loop-2 compatibility.
      if ((todaysLogs ?? []).length > 0) {
        try {
          const ids = (todaysLogs ?? []).map((log: any) => String(log.id ?? "")).filter(Boolean);
          const [questions, attempts] = await Promise.all([
            getStudentMultiCrossQuestions(ids),
            getStudentMultiCrossQuestionAttempts(ids),
          ]);
          const questionMap: Record<string, MultiCrossQuestion[]> = {};
          for (const row of questions as MultiCrossQuestion[]) {
            const key = String(row.daily_log_uuid);
            (questionMap[key] ??= []).push(row);
          }
          Object.values(questionMap).forEach((rows) => rows.sort((a, b) => a.question_order - b.question_order));
          const attemptMap: Record<string, Record<string, MultiCrossQuestionAttempt>> = {};
          for (const row of attempts as MultiCrossQuestionAttempt[]) {
            const logKey = String(row.daily_log_uuid);
            (attemptMap[logKey] ??= {})[String(row.question_uuid)] = row;
          }
          setMultiCrossQuestionsByLog(questionMap);
          setMultiCrossAttemptsByLog(attemptMap);
          loop1VerificationAttemptHistoryReadyRef.current = true;
        } catch (multiError) {
          // The new layer is isolated from the existing daily-log feed. A
          // failure here must not break legacy logs or Loop-2.
          console.error("MULTI CROSS QUESTION LOAD FAILED", multiError);
          setMultiCrossQuestionsByLog({});
          setMultiCrossAttemptsByLog({});
        }
      } else {
        setMultiCrossQuestionsByLog({});
        setMultiCrossAttemptsByLog({});
      }

      // Restore the one-attempt lock after a refresh. The table's SELECT RLS
      // exposes only the signed-in student's own attempt rows.
      if ((todaysLogs ?? []).length > 0) {
        try {
          const supabase = getSupabaseClient();
          const ids = (todaysLogs ?? []).map((log: any) => log.id).filter(Boolean);
          if (supabase && ids.length) {
            const { data: attempts, error: attemptsError } = await (supabase as any)
              .from("student_daily_cross_question_attempts")
              .select("daily_log_uuid,selected_index,is_correct")
              .in("daily_log_uuid", ids);
            if (attemptsError) throw attemptsError;
            const answerMap: Record<string, number> = {};
            const resultMap: Record<string, boolean> = {};
            for (const attempt of attempts ?? []) {
              answerMap[String(attempt.daily_log_uuid)] = Number(attempt.selected_index);
              resultMap[String(attempt.daily_log_uuid)] = attempt.is_correct === true;
            }
            setCrossQuestionAnswers(answerMap);
            setCrossQuestionResults(resultMap);
            loop1VerificationAttemptHistoryReadyRef.current = true;
          }
        } catch (attemptLoadError) {
          console.warn("CROSS QUESTION ATTEMPT HISTORY LOAD FAILED", attemptLoadError);
        }
      } else {
        loop1VerificationAttemptHistoryReadyRef.current = true;
      }

      // These are secondary data loads and run together. None of them blocks
      // the initial daily-log render above.
      const feedbackPromise = (todaysLogs ?? []).length > 0
        ? getStudentFeedbackForLectures(
            (todaysLogs ?? []).map((log: any) => log.id).filter(Boolean)
          )
        : Promise.resolve([]);

      // Secondary loads must not be allowed to erase an otherwise healthy
      // daily feed. A failure in doubts, subjects, or feedback status is
      // isolated to that feature instead of triggering the page-level catch.
      const [doubtsResult, subjectsResult, feedbackResult, historicalLogsResult] =
        await Promise.allSettled([
          loadPendingDoubtsData(),
          getStudentSubjects(),
          feedbackPromise,
          getStudentDailyLectureLogs(),
        ]);

      if (doubtsResult.status === "fulfilled") {
        setPendingDoubts(doubtsResult.value ?? []);
      } else {
        console.error("PENDING DOUBTS INITIAL LOAD FAILED", doubtsResult.reason);
        setPendingDoubts([]);
      }

      if (subjectsResult.status === "fulfilled") {
        setSubjectOptions(subjectsResult.value ?? []);
      } else {
        console.error("STUDENT SUBJECT OPTIONS LOAD FAILED", subjectsResult.reason);
        setSubjectOptions([]);
      }

      if (historicalLogsResult.status === "fulfilled") {
        setHistoricalLectureLogs(historicalLogsResult.value ?? []);
      } else {
        console.error("HISTORICAL LECTURE LOG LOAD FAILED", historicalLogsResult.reason);
        setHistoricalLectureLogs([]);
      }

      if (feedbackResult.status === "fulfilled") {
        const feedbackMap: Record<string, any> = {};

        for (const feedback of feedbackResult.value ?? []) {
          if (feedback?.daily_log_uuid) {
            feedbackMap[feedback.daily_log_uuid] = feedback;
          }
        }

        for (const submittedLogId of Object.keys(feedbackMap)) {
          clearLoop1FeedbackDraft(String(submittedLogId));
        }
        setSubmittedFeedback(feedbackMap);
      } else {
        console.error("TODAY FEEDBACK STATUS LOAD FAILED", feedbackResult.reason);
        setSubmittedFeedback({});
      }
    } catch (error) {
      console.error("DAILY LECTURE FEEDBACK PAGE LOAD FAILED", error);
      setLectureLogs([]);
      setPendingDoubts([]);
      setHistoricalLectureLogs([]);
      setSubjectOptions([]);
    } finally {
      setIsLoadingLogs(false);
    }
  }

  async function loadPendingDoubtsData() {
    const identity = requireIdentity();
    return await getPendingDoubtsByStudent(identity.studentUuid);
  }

  async function loadDailyFeedbackCreditSummary() {
    setIsLoadingCreditSummary(true);

    try {
      const [
        logsResult,
        feedbackResult,
        loop2Result,
        creditStartResult,
      ] = await Promise.allSettled([
        getStudentDailyLectureLogs(),
        getStudentFeedbackHistory(),
        getStudentLoop2FeedbackHistory(),
        getStudentFeedbackCreditStartDate(),
      ]);

      if (logsResult.status === "rejected") {
        throw logsResult.reason;
      }

      if (feedbackResult.status === "rejected") {
        throw feedbackResult.reason;
      }

      if (creditStartResult.status === "rejected") {
        throw creditStartResult.reason;
      }

      const allLectureLogs = logsResult.value ?? [];
      const feedbackHistory = feedbackResult.value ?? [];
      const loop2History =
        loop2Result.status === "fulfilled" ? loop2Result.value ?? [] : [];

      if (loop2Result.status === "rejected") {
        console.error(
          "LOOP-2 CREDIT HISTORY LOAD FAILED — LOOP-1 CREDIT PRESERVED",
          loop2Result.reason
        );
      }

      const today = getIndiaTodayKey();

      const summary = calculateDailyFeedbackCreditSummaryFromLogs(
        allLectureLogs,
        feedbackHistory,
        today,
        {
          studentCreatedAt: creditStartResult.value,
          loop2History,
        }
      );

      setDailyFeedbackEarnedCredits(summary.earnedCredits);
      setDailyFeedbackLostCredits(summary.lostCredits);
      setDailyFeedbackTotalCredits(summary.totalCredits);
    } catch (error) {
      console.error("DAILY FEEDBACK CREDIT SUMMARY LOAD FAILED", error);
      setDailyFeedbackEarnedCredits(0);
      setDailyFeedbackLostCredits(0);
      setDailyFeedbackTotalCredits(0);
    } finally {
      setIsLoadingCreditSummary(false);
    }
  }

  async function loadPendingDoubts(): Promise<any[] | null> {
    try {
      const doubts = await loadPendingDoubtsData();
      const nextDoubts = doubts ?? [];
      setPendingDoubts(nextDoubts);
      return nextDoubts;
    } catch (error) {
      console.error("PENDING DOUBTS LOAD FAILED", error);
      setPendingDoubts([]);
      return null;
    }
  }

  function resetFeedbackForm() {
    if (expandedCard) {
      loop1FeedbackDraftUserTouchedLogIdsRef.current.delete(expandedCard);
      multiWrongStartedFromCompleteRef.current.delete(expandedCard);
    }
    resetLoop1TransientFeedbackState();
    setLoop1FeedbackDraftHydratedLogId(null);
    clearLoop1UnderstandingResume(expandedCard);
    setExpandedCard(null);
    setFeedbackSubmitError(null);
  }

  function clearLoop1Verification(logId: string) {
    loop1VerificationIntentRef.current += 1;
    loop1VerificationAnswerLockRef.current.delete(logId);
    if (loop1VerificationNoLockLogIdRef.current === logId) {
      loop1VerificationNoLockLogIdRef.current = null;
    }
    if (loop1VerificationActivationLogIdRef.current === logId) {
      loop1VerificationActivationLogIdRef.current = null;
    }
    multiWrongStartedFromCompleteRef.current.delete(logId);
    setLoop1VerificationStage("idle");
    setLoop1VerificationLogId(null);
    setLoop1VerificationAnswer(null);
    setLoop1VerificationCorrect(null);
    setLoop1VerificationSecondSelection(null);
  }

  function getMultiQuestionsForLog(logId: string): MultiCrossQuestion[] {
    return multiCrossQuestionsByLog[logId] ?? [];
  }

  function hasMultiQuestions(logId: string): boolean {
    return getMultiQuestionsForLog(logId).length >= 2;
  }

  function getMultiAttemptsForLog(logId: string): Record<string, MultiCrossQuestionAttempt> {
    return multiCrossAttemptsByLog[logId] ?? {};
  }

  // V68: a resumed Multi-Cross answer must use the persisted understanding
  // context even if its callback was created during the hydration boundary.
  // The ref is populated only from the same durable/user-selected value.
  function getEffectiveLoop1UnderstandingLevel(logId: string): string {
    // Only the currently open Daily Log may consume the transient feedback
    // state. A render/callback for another log must never inherit the prior
    // card's React state.
    if (expandedCard !== logId) return "";
    const resume = loop1UnderstandingResumeRef.current;
    if (understandingLevel === "" && resume.logId === logId && resume.value) {
      return resume.value;
    }
    return understandingLevel;
  }

  // V34 corrected: the understanding choice becomes immutable only after the
  // first Multi Cross Question has actually been answered correctly. Before
  // that point the student may move freely between Complete / Partial /
  // Didn't / Absent. This is derived from the persisted attempt ledger so a
  // refresh cannot accidentally reopen the choice after Q1 is correct.
  function isMultiFirstQuestionAnsweredCorrectly(logId: string): boolean {
    const questions = getMultiQuestionsForLog(logId);
    if (questions.length < 2) return false;
    const firstQuestion = [...questions].sort((a, b) => a.question_order - b.question_order)[0];
    return getMultiAttemptsForLog(logId)[firstQuestion.id]?.is_correct === true;
  }

  function hasAnyMultiAttempt(logId: string): boolean {
    return Object.keys(getMultiAttemptsForLog(logId)).length > 0;
  }

  function startLoop1Verification(log: any, level: string): boolean {
    if (!loop1VerificationAttemptHistoryReadyRef.current) return false;

    if (hasMultiQuestions(log.id)) {
      const questions = getMultiQuestionsForLog(log.id);
      const attempts = getMultiAttemptsForLog(log.id);
      const wrong = questions.some((question) => attempts[question.id]?.is_correct === false);
      const complete = questions.every((question) => attempts[question.id]?.is_correct === true);
      loop1VerificationIntentRef.current += 1;
      loop1VerificationActivationLogIdRef.current = log.id;
      setLoop1UnderstandingLevelForLog(log.id, level);
      setFeedbackSubmitError(null);
      setLoop1VerificationLogId(log.id);
      setLoop1VerificationAnswer(null);
      setLoop1VerificationCorrect(null);
      setLoop1VerificationSecondSelection(null);
      const nextVerificationStage: Loop1FeedbackDraft["verificationStage"] = complete
        ? "verification"
        : wrong
          ? "wrong"
          : "question";

      // Event-boundary durability: do not rely on the post-state effect for
      // activation. The student can leave immediately after this radio event.
      // Persist the complete resulting verification transition synchronously.
      persistLoop1FeedbackDraftSnapshot(log.id, {
        understandingLevel: level,
        verificationLogId: log.id,
        verificationAnswer: null,
        verificationCorrect: null,
        verificationSecondSelection: null,
        verificationStage: nextVerificationStage,
        verificationNoLock: false,
        wrongStartedFromComplete: wrong && level === "I completely understood.",
      });

      if (complete) {
        setLoop1VerificationStage("verification");
        setGuidedScrollTarget({ logId: log.id, section: "question" });
      } else if (wrong) {
        setLoop1VerificationStage("wrong");
        setGuidedScrollTarget({ logId: log.id, section: "concepts" });
      } else {
        setLoop1VerificationStage("question");
        setGuidedScrollTarget({ logId: log.id, section: "question" });
      }
      return true;
    }

    if (log.id in crossQuestionAnswers) return false;
    if (!hasLoop1VerificationQuestion(log)) return false;
    loop1VerificationIntentRef.current += 1;
    if (loop1VerificationNoLockLogIdRef.current === log.id) {
      loop1VerificationNoLockLogIdRef.current = null;
    }
    loop1VerificationActivationLogIdRef.current = log.id;
    setLoop1UnderstandingLevelForLog(log.id, level);
    setFeedbackSubmitError(null);
    setLoop1VerificationLogId(log.id);
    setLoop1VerificationAnswer(null);
    setLoop1VerificationCorrect(null);
    setLoop1VerificationSecondSelection(null);
    setLoop1VerificationStage("question");
    // Event-boundary durability for the legacy single-question verification
    // path as well. This is harmless for the server draft layer (which remains
    // enabled only for confirmed Loop-1 Multi-Cross logs) and protects the
    // local draft snapshot from an immediate leave before the effect runs.
    persistLoop1FeedbackDraftSnapshot(log.id, {
      understandingLevel: level,
      verificationLogId: log.id,
      verificationAnswer: null,
      verificationCorrect: null,
      verificationSecondSelection: null,
      verificationStage: "question",
      verificationNoLock: false,
      wrongStartedFromComplete: false,
    });
    setGuidedScrollTarget({ logId: log.id, section: "question" });
    return true;
  }

  function handleLoop1UnderstandingCapture(log: any, event: React.SyntheticEvent) {
    const target = event.target as HTMLInputElement | null;
    if (!target || target.type !== "radio") return;
    const option = target.value;

    if (loop1VerificationNoLockLogIdRef.current === log.id) {
      event.stopPropagation();
      return;
    }

    // V75: this understanding radio handler owns the event because its
    // onChangeCapture stops propagation. Mark the Daily Log as user-touched
    // at the same boundary so hydration cannot later treat this fresh choice
    // as an untouched card and overwrite it with an older empty draft.
    loop1FeedbackDraftUserTouchedLogIdsRef.current.add(log.id);

    if (loop1VerificationLogId === log.id && loop1VerificationStage === "corrected") {
      event.stopPropagation();
      if (option === ABSENT_FEEDBACK_OPTION) return;
      setLoop1VerificationSecondSelection(option);
      setLoop1UnderstandingLevelForLog(log.id, option);
      setFeedbackSubmitError(null);
      // The understanding radio grid stops propagation, so the outer form
      // capture writer cannot be relied on for this second selection. Persist
      // the event-boundary value synchronously before any leave/unmount can win.
      persistLoop1FeedbackDraftSnapshot(log.id, {
        understandingLevel: option,
        verificationLogId: log.id,
        verificationStage: "corrected",
        verificationSecondSelection: option,
      });
      if (option === "I completely understood.") {
        const selected = loop1VerificationAnswer;
        const correct = loop1VerificationCorrect;
        void submitFeedback(
          log,
          option,
          selected,
          correct,
          { allowCorrectedSecondSelection: true }
        );
        return;
      }
      if (option === "I partially understood." || option === "I didn't understand.") {
        // Keep the verification-completed stage active after the fresh second
        // selection. This permanently suppresses the Cross Question for the
        // remainder of the corrected flow, even if the student switches
        // between Partial and Didn't understand before choosing concepts.
        // The verification state is cleared only after the final feedback
        // submission/reset or when the student explicitly chooses NO.
        setGuidedScrollTarget({ logId: log.id, section: "concepts" });
      }
      return;
    }

    if (loop1VerificationLogId === log.id && loop1VerificationStage === "wrong") {
      // A multi-question wrong answer is terminal for Cross Questions, but the
      // student must immediately continue through the existing understanding →
      // difficult-concept flow. Partial/Didn't-understand are allowed here;
      // Complete/Absent remain rejected by the feedback gate.
      if (option === "I partially understood." || option === "I didn't understand.") {
        setLoop1UnderstandingLevelForLog(log.id, option);
        setFeedbackSubmitError(null);
        // The understanding grid stops propagation, so persist this terminal
        // wrong-stage selection at the same event boundary as the state update.
        // This is the durable source that hydration can restore after cancel,
        // tab switch, navigation, or component unmount.
        persistLoop1FeedbackDraftSnapshot(log.id, {
          understandingLevel: option,
          verificationLogId: log.id,
          verificationStage: "wrong",
          wrongStartedFromComplete: multiWrongStartedFromCompleteRef.current.has(log.id),
        });
        setGuidedScrollTarget({ logId: log.id, section: "concepts" });
      }
      event.stopPropagation();
      return;
    }

    // V34 corrected: while Q1 has not been answered, the student may change
    // the understanding choice without restarting the Cross Question flow.
    // Absent temporarily removes the question; choosing Complete/Partial/
    // Didn't brings the same Q1 flow back. Once Q1 is answered correctly,
    // this branch no longer applies and the selection becomes locked.
    if (
      hasMultiQuestions(log.id) &&
      loop1VerificationLogId === log.id &&
      loop1VerificationStage === "question" &&
      !hasAnyMultiAttempt(log.id)
    ) {
      loop1VerificationActivationLogIdRef.current = null;
      setFeedbackSubmitError(null);
      if (option === ABSENT_FEEDBACK_OPTION) {
        // Persist the full cancellation result synchronously. The capture
        // handler has already recorded the radio value, but the subsequent
        // state clearing must also survive an immediate leave.
        persistLoop1FeedbackDraftSnapshot(log.id, {
          understandingLevel: ABSENT_FEEDBACK_OPTION,
          conceptsNotUnderstood: [],
          somethingElse: false,
          somethingElseText: "",
          additionalNote: "",
          verificationStage: "idle",
          verificationLogId: null,
          verificationAnswer: null,
          verificationCorrect: null,
          verificationSecondSelection: null,
          verificationNoLock: false,
          wrongStartedFromComplete: false,
        });
        setLoop1UnderstandingLevelForLog(log.id, ABSENT_FEEDBACK_OPTION);
        setConceptsNotUnderstood([]);
        setSomethingElse(false);
        setSomethingElseText("");
        setAdditionalNote("");
        clearLoop1Verification(log.id);
        setGuidedScrollTarget({ logId: log.id, section: "understanding" });
      } else if (
        option === "I completely understood." ||
        option === "I partially understood." ||
        option === "I didn't understand."
      ) {
        setLoop1UnderstandingLevelForLog(log.id, option);
        // The understanding grid stops propagation, so the outer form
        // onChangeCapture cannot provide the immediate durability boundary.
        // Persist the selected value now; the existing effect remains only the
        // normal backup writer.
        persistLoop1FeedbackDraftSnapshot(log.id, {
          understandingLevel: option,
          verificationLogId: log.id,
          verificationStage: "question",
        });
        setGuidedScrollTarget({ logId: log.id, section: "question" });
      }
      event.stopPropagation();
      return;
    }

    // V34 corrected: after Q1 is answered correctly, no understanding change
    // is allowed during the remaining Cross Question sequence. The terminal
    // wrong branch above remains the deliberate V33 exception.
    if (
      hasMultiQuestions(log.id) &&
      isMultiFirstQuestionAnsweredCorrectly(log.id) &&
      !(loop1VerificationLogId === log.id && loop1VerificationStage === "corrected")
    ) {
      event.stopPropagation();
      return;
    }

    if (loop1VerificationLogId === log.id && loop1VerificationStage !== "idle") {
      event.stopPropagation();
      return;
    }

    if (
      (option === "I partially understood." || option === "I didn't understand.") &&
      !(log.id in crossQuestionAnswers)
    ) {
      if (startLoop1Verification(log, option)) {
        event.stopPropagation();
      }
    }
  }

  async function handleLoop1VerificationAnswer(log: any, selected: number) {
    if (loop1VerificationLogId !== log.id || loop1VerificationStage !== "question") return;
    if (loop1VerificationAnswerLockRef.current.has(log.id)) return;

    const supabase = getSupabaseClient();
    if (!supabase) {
      setFeedbackSubmitError("Your session is unavailable. Please sign in again.");
      return;
    }

    const intent = loop1VerificationIntentRef.current;
    loop1VerificationAnswerLockRef.current.add(log.id);
    persistLoop1FeedbackDraftSnapshot(log.id, {
      verificationStage: "question",
      verificationAnswer: selected,
      verificationCorrect: null,
    });

    try {
      const { data, error } = await (supabase as any).rpc("tp_record_daily_cross_question_attempt", {
        p_daily_log_uuid: log.id,
        p_selected_index: selected,
      });
      if (error) throw error;

      if (intent !== loop1VerificationIntentRef.current || loop1VerificationLogId !== log.id) return;

      const attempt = Array.isArray(data) ? data[0] : data;
      const correct = attempt?.is_correct === true;
      setLoop1VerificationAnswer(selected);
      setLoop1VerificationCorrect(correct);

      if (correct) {
        setLoop1VerificationStage("verification");
        persistLoop1FeedbackDraftSnapshot(log.id, {
          verificationStage: "verification",
          verificationAnswer: selected,
          verificationCorrect: true,
        });
      } else {
        setLoop1VerificationStage("wrong");
        persistLoop1FeedbackDraftSnapshot(log.id, {
          verificationStage: "wrong",
          verificationAnswer: selected,
          verificationCorrect: false,
        });
        setGuidedScrollTarget({ logId: log.id, section: "concepts" });
      }
    } catch (error: any) {
      if (intent !== loop1VerificationIntentRef.current) return;
      console.error("LOOP-1 VERIFICATION QUESTION ATTEMPT FAILED", error);
      setFeedbackSubmitError(String(error?.message ?? "Your answer could not be recorded. Refresh the page to check whether it was already attempted."));
    } finally {
      loop1VerificationAnswerLockRef.current.delete(log.id);
    }
  }

  function handleLoop1VerificationDecision(log: any, wantsToCorrect: boolean) {
    if (loop1VerificationLogId !== log.id || loop1VerificationStage !== "verification") return;
    if (wantsToCorrect) {
      // Verification YES starts a fresh second understanding selection.
      // The original Partial/Didn't choice must not remain selected or be
      // reusable by the ordinary Submit button.
      // Persist the complete YES -> corrected transition synchronously. This
      // removes the last dependency on a post-render effect for verification
      // state, second-selection state, and cleared learning-gap fields.
      persistLoop1FeedbackDraftSnapshot(log.id, {
        understandingLevel: "",
        conceptsNotUnderstood: [],
        somethingElse: false,
        somethingElseText: "",
        additionalNote: "",
        verificationLogId: log.id,
        verificationAnswer: loop1VerificationAnswer,
        verificationCorrect: loop1VerificationCorrect,
        verificationSecondSelection: null,
        verificationStage: "corrected",
        verificationNoLock: false,
        wrongStartedFromComplete: false,
      });
      setLoop1UnderstandingLevelForLog(log.id, "");
      setLoop1VerificationSecondSelection(null);
      setConceptsNotUnderstood([]);
      setSomethingElse(false);
      setSomethingElseText("");
      setAdditionalNote("");
      setFeedbackSubmitError(null);
      setLoop1VerificationStage("corrected");
      setGuidedScrollTarget({ logId: log.id, section: "understanding" });
      return;
    }
    // Verification NO keeps the original understanding choice locked while
    // the student completes the difficult-concepts step. Changing the
    // understanding radio at this point must never restart the verification
    // question. The state is cleared only by normal form reset/submission.
    loop1VerificationNoLockLogIdRef.current = log.id;
    persistLoop1FeedbackDraftSnapshot(log.id, {
      verificationLogId: log.id,
      verificationAnswer: loop1VerificationAnswer,
      verificationCorrect: loop1VerificationCorrect,
      verificationSecondSelection: null,
      verificationStage: "no",
      verificationNoLock: true,
    });
    setLoop1VerificationSecondSelection(null);
    setLoop1VerificationStage("no");
    setFeedbackSubmitError(null);
    setGuidedScrollTarget({ logId: log.id, section: "concepts" });
  }

  async function recordMultiCrossQuestionAttempt(log: any, question: MultiCrossQuestion, selectedValue: string): Promise<MultiCrossQuestionAttempt> {
    const supabase = getSupabaseClient();
    if (!supabase) throw new Error("Your session is unavailable. Please sign in again.");

    const { data, error } = await (supabase as any).rpc("tp_v11_multi_record_cross_question_attempt", {
      p_question_uuid: String(question.id),
      p_selected_value: String(selectedValue),
    });

    if (error) {
      // The RPC is idempotent by (daily_log_uuid, question_uuid, student_uuid).
      // If the network/PostgREST response was lost after the database committed,
      // recover the committed attempt before surfacing an error to the student.
      try {
        const recovered = await getStudentMultiCrossQuestionAttempts([String(log.id)]);
        const existing = (recovered as MultiCrossQuestionAttempt[]).find(
          (row) => String(row.question_uuid) === String(question.id)
        );
        if (existing) {
          const normalizedRecovered: MultiCrossQuestionAttempt = {
            daily_log_uuid: String(existing.daily_log_uuid),
            question_uuid: String(existing.question_uuid),
            selected_value: String(existing.selected_value ?? ""),
            is_correct: existing.is_correct === true,
            attempted_at: existing.attempted_at,
          };
          setMultiCrossAttemptsByLog((previous) => ({
            ...previous,
            [log.id]: { ...(previous[log.id] ?? {}), [question.id]: normalizedRecovered },
          }));
          return normalizedRecovered;
        }
      } catch {
        // Preserve the original RPC error below. The recovery read is best-effort.
      }
      const message = String((error as any)?.message ?? "The Cross Question answer could not be recorded.");
      throw new Error(message);
    }

    const attempt = Array.isArray(data) ? data[0] : data;
    if (!attempt?.question_uuid) throw new Error("The Cross Question answer could not be confirmed.");

    const normalizedAttempt: MultiCrossQuestionAttempt = {
      daily_log_uuid: String(attempt.daily_log_uuid),
      question_uuid: String(attempt.question_uuid),
      selected_value: String(attempt.selected_value ?? ""),
      is_correct: attempt.is_correct === true,
      attempted_at: attempt.attempted_at,
    };

    setMultiCrossAttemptsByLog((previous) => ({
      ...previous,
      [log.id]: { ...(previous[log.id] ?? {}), [question.id]: normalizedAttempt },
    }));

    return normalizedAttempt;
  }

  function handleMultiAllCorrect(log: any, finalAttempt: MultiCrossQuestionAttempt) {
    if (submittedFeedback[log.id]) return;
    const effectiveUnderstandingLevel = getEffectiveLoop1UnderstandingLevel(log.id);
    if (effectiveUnderstandingLevel !== "I completely understood.") {
      // Preserve the V33 Partial/Didn't-understand completion path.
      // This is intentionally local: the question-stage wrapper may call
      // handleMultiAllCorrect() for Complete auto-submit, but non-Complete
      // completion must enter the existing Verification state.
      // The final Multi-Cross attempt is already authoritative on the server.
      // Persist the resulting verification transition synchronously before the
      // UI moves to the verification dialog, so Q3 -> leave cannot lose it.
      persistLoop1FeedbackDraftSnapshot(log.id, {
        verificationLogId: log.id,
        verificationStage: "verification",
        verificationAnswer: null,
        verificationCorrect: null,
        verificationSecondSelection: null,
        verificationNoLock: false,
      });
      setLoop1VerificationStage("verification");
      setGuidedScrollTarget({ logId: log.id, section: "question" });
      return;
    }
    setLoop1UnderstandingLevelForLog(log.id, "I completely understood.");
    setFeedbackSubmitError(null);
    // The final attempt is passed directly because React state updates are
    // asynchronous. This lets the server-side readiness gate see the complete
    // question ledger in the same answer event and submit automatically.
    void submitFeedback(
      log,
      "I completely understood.",
      null,
      true,
      { multiFinalAttempt: finalAttempt }
    );
  }

  function handleMultiVerificationAllCorrect(log: any, finalAttempt: MultiCrossQuestionAttempt) {
    if (submittedFeedback[log.id]) return;
    // Both MultiCrossQuestionFlow render paths use the same completion
    // decision. Complete submits immediately; Partial/Didn't keep the existing
    // Verification dialog.
    handleMultiAllCorrect(log, finalAttempt);
  }

  function handleMultiWrong(log: any) {
    if (submittedFeedback[log.id]) return;

    // V72: the wrong-terminal transition is an answer-event boundary. Do not
    // rely only on the React state closure here because MultiCrossQuestionFlow
    // reports the terminal wrong answer from its own effect after the server
    // attempt commits. The log-scoped resume ref is synchronously updated by
    // every understanding-selection event, so it is the strongest in-session
    // source for the student's Partial/Didn't-understand choice at this exact
    // transition. Fall back to the existing effective resolver when the ref is
    // not populated (for example, a Complete-origin flow).
    const resume = loop1UnderstandingResumeRef.current;
    const effectiveUnderstandingLevel =
      resume.logId === log.id && resume.value
        ? resume.value
        : getEffectiveLoop1UnderstandingLevel(log.id);

    if (effectiveUnderstandingLevel === "I completely understood.") {
      multiWrongStartedFromCompleteRef.current.add(log.id);
    } else {
      multiWrongStartedFromCompleteRef.current.delete(log.id);
    }

    // Preserve the student's current understanding selection DURABLY on the
    // wrong-terminal transition. This explicit override closes the V70/V71
    // edge case where the question ledger correctly restored Q1/Q2 as wrong,
    // but the surrounding understanding value was not guaranteed to survive
    // the leave/reopen boundary. The server draft must therefore carry the
    // same value that was used to choose the wrong-state UI.
    setLoop1VerificationLogId(log.id);
    setLoop1VerificationStage("wrong");
    persistLoop1FeedbackDraftSnapshot(log.id, {
      understandingLevel: effectiveUnderstandingLevel,
      verificationLogId: log.id,
      verificationStage: "wrong",
      wrongStartedFromComplete: multiWrongStartedFromCompleteRef.current.has(log.id),
    });
    setFeedbackSubmitError(null);
    setGuidedScrollTarget({
      logId: log.id,
      section: effectiveUnderstandingLevel === "I completely understood."
        ? "understanding"
        : "concepts",
    });
  }

  async function submitFeedback(
    log: any,
    understandingOverride?: string,
    crossQuestionSelectedIndex?: number | null,
    crossQuestionIsCorrect?: boolean | null,
    options?: {
      allowCorrectedSecondSelection?: boolean;
      multiFinalAttempt?: MultiCrossQuestionAttempt | null;
    }
  ) {
    if (isSubmittingFeedbackId) return;
    const effectiveUnderstandingLevel = understandingOverride ?? understandingLevel;
    const multiQuestions = getMultiQuestionsForLog(log.id);
    const isMultiCrossQuestionLog = multiQuestions.length >= 2;

    // After Verification YES, the student must make a fresh second selection.
    // Do not allow the ordinary Submit button to reuse the cleared/previous
    // Partial or Didn't-understand choice.
    if (
      loop1VerificationLogId === log.id &&
      loop1VerificationStage === "corrected" &&
      loop1VerificationSecondSelection == null &&
      !options?.allowCorrectedSecondSelection
    ) {
      setFeedbackSubmitError("Please choose your understanding level again.");
      return;
    }

    // V11: new multi-question logs use the ordered question-level ledger.
    // Legacy scalar logs continue through the existing gate unchanged.
    if (isMultiCrossQuestionLog) {
      const attempts = {
        ...getMultiAttemptsForLog(log.id),
        ...(options?.multiFinalAttempt?.question_uuid
          ? { [options.multiFinalAttempt.question_uuid]: options.multiFinalAttempt }
          : {}),
      };
      const wrong = multiQuestions.some((question) => attempts[question.id]?.is_correct === false);
      const allCorrect = multiQuestions.every((question) => attempts[question.id]?.is_correct === true);
      if (effectiveUnderstandingLevel === "I completely understood.") {
        if (!allCorrect) {
          setFeedbackSubmitError(wrong
            ? "The Cross Question flow ended on an incorrect answer. Please choose your understanding level and complete the usual feedback."
            : "Please answer all Cross Questions correctly first.");
          return;
        }
        const supabase = getSupabaseClient();
        if (!supabase) {
          setFeedbackSubmitError("Your session is unavailable. Please sign in again.");
          return;
        }
        const { error: readyError } = await (supabase as any).rpc("tp_v11_multi_assert_feedback_ready", {
          p_daily_log_uuid: log.id,
          p_allow_partial_or_wrong: false,
        });
        if (readyError) {
          setFeedbackSubmitError(String(readyError.message ?? "All Cross Questions must be completed correctly."));
          return;
        }
      } else if (effectiveUnderstandingLevel !== ABSENT_FEEDBACK_OPTION) {
        // Fail closed for Partial/Didn't-understand as well. The server accepts
        // this branch only after a terminal wrong answer or after all questions
        // are complete, so a transient multi-question read failure cannot turn
        // into a question-free feedback submission.
        const supabase = getSupabaseClient();
        if (!supabase) {
          setFeedbackSubmitError("Your session is unavailable. Please sign in again.");
          return;
        }
        const { error: readyError } = await (supabase as any).rpc("tp_v11_multi_assert_feedback_ready", {
          p_daily_log_uuid: log.id,
          p_allow_partial_or_wrong: true,
        });
        if (readyError) {
          setFeedbackSubmitError(String(readyError.message ?? "Please complete the Cross Question flow before submitting this feedback."));
          return;
        }
      }
    } else {
      const hasCrossQuestion = Boolean(
        (log.cross_question_text || log.cross_question_image_path) &&
        Array.isArray(log.cross_question_options) &&
        log.cross_question_options.length === 4
      );
      const attemptedCrossQuestion = crossQuestionSelectedIndex != null || log.id in crossQuestionAnswers;
      const effectiveCrossQuestionCorrect = crossQuestionIsCorrect ?? crossQuestionResults[log.id];
      if (hasCrossQuestion && effectiveUnderstandingLevel === "I completely understood." && !attemptedCrossQuestion) {
        setFeedbackSubmitError("Please answer the Cross Question first.");
        return;
      }
      if (hasCrossQuestion && effectiveUnderstandingLevel === "I completely understood." && effectiveCrossQuestionCorrect !== true) {
        setFeedbackSubmitError("The Cross Question was answered incorrectly. Please choose your understanding level and submit the usual feedback.");
        return;
      }
    }

    if (effectiveUnderstandingLevel.length === 0) {
      alert("Please select your understanding level.");
      return;
    }

    if (
      effectiveUnderstandingLevel !== "I completely understood." &&
      effectiveUnderstandingLevel !== ABSENT_FEEDBACK_OPTION &&
      conceptsNotUnderstood.length === 0 &&
      !somethingElse
    ) {
      alert("Please select at least one difficult concept.");
      return;
    }

    const isAbsent = effectiveUnderstandingLevel === ABSENT_FEEDBACK_OPTION;
    const effectiveCrossQuestionSelectedIndex = crossQuestionSelectedIndex ?? crossQuestionAnswers[log.id] ?? null;
    const effectiveCrossQuestionIsCorrect = crossQuestionIsCorrect ?? (effectiveCrossQuestionSelectedIndex === null ? null : crossQuestionResults[log.id] ?? null);
    const submissionConcepts = isAbsent ? [] : conceptsNotUnderstood;
    let finalAdditionalNote = isAbsent ? null : additionalNote;

    if (!isAbsent && somethingElse && somethingElseText.trim()) {
      finalAdditionalNote = `${additionalNote}${
        additionalNote.trim() ? "\n\n" : ""
      }Additional Learning Gap:\n${somethingElseText}`;
    }

    setFeedbackSubmitError(null);
    setIsSubmittingFeedbackId(log.id);

    try {
      await submitStudentDailyFeedback(
        log.id,
        log.teacher_uuid,
        log.school_uuid,
        log.class_name,
        log.section_name,
        log.subject_name,
        log.topic_name,
        effectiveUnderstandingLevel,
        submissionConcepts,
        finalAdditionalNote && finalAdditionalNote.trim().length > 0
          ? finalAdditionalNote
          : null,
        effectiveCrossQuestionSelectedIndex,
        effectiveCrossQuestionIsCorrect
      );

      // Keep the existing repository return contract (true), but update
      // the UI immediately from the values that were just submitted.
      // This avoids a second database read after a successful INSERT.
      const localSubmittedFeedback = {
        daily_log_uuid: log.id,
        student_uuid: requireIdentity().studentUuid,
        teacher_uuid: log.teacher_uuid,
        school_uuid: log.school_uuid,
        class_name: log.class_name,
        section_name: log.section_name,
        subject_name: log.subject_name,
        topic_name: log.topic_name,
        understanding_level: effectiveUnderstandingLevel,
        cross_question_selected_index: effectiveCrossQuestionSelectedIndex,
        cross_question_is_correct: effectiveCrossQuestionIsCorrect,
        concepts_not_understood: [...submissionConcepts],
        has_doubt: submissionConcepts.length > 0,
        additional_note:
          finalAdditionalNote && finalAdditionalNote.trim().length > 0
            ? finalAdditionalNote
            : null,
        submitted_at: new Date().toISOString(),
      };

      setSubmittedFeedback((previous) => ({
        ...previous,
        [log.id]: localSubmittedFeedback,
      }));

      // Absence is deliberately neutral: it records the lecture as handled
      // for attendance purposes but earns neither +1 nor incurs -10.
      // Do not re-fetch the complete credit history here.
      if (!isAbsent) {
        setDailyFeedbackEarnedCredits((value) => value + 1);
        setDailyFeedbackTotalCredits((value) => value + 1);
      }

      const draftCleared = await clearLoop1FeedbackDraft(log.id);
      if (!draftCleared) {
        // The submitted feedback is already authoritative, but Gate-4 requires
        // the unfinished draft cleanup to complete before acknowledgement or
        // guided-queue continuation. Do not show a success popup or advance
        // the queue while the server draft still cannot be confirmed cleared.
        setFeedbackSubmitError(
          "Feedback was submitted, but unfinished draft cleanup could not be confirmed. Please keep this page open and try again."
        );
        return;
      }
      loop1FeedbackDraftUserTouchedLogIdsRef.current.delete(log.id);

      // Only Multi-Cross Loop-1 feedback gets the acknowledgement. It is
      // shown after the authoritative feedback save and before the existing
      // guided transition; no question/verification flow is changed here.
      if (isMultiCrossQuestionLog) {
        await showLoop1FeedbackSuccessPopup();
      }

      resetFeedbackForm();

      // Continue the guided journey through today's remaining unsubmitted
      // subject feedbacks in the existing lectureLogs order. The current log
      // is excluded explicitly because React state updates are asynchronous.
      const nextUnsubmittedLog = lectureLogs.find(
        (candidate) =>
          candidate.id !== log.id && !submittedFeedback[candidate.id]
      );

      if (nextUnsubmittedLog) {
        openLoop1FeedbackCard(nextUnsubmittedLog.id);
        setGuidedScrollTarget({
          logId: nextUnsubmittedLog.id,
          section: "understanding",
        });
      } else {
        // Every feedback currently listed for today has now been handled.
        setGuidedScrollTarget({ logId: "", section: "credits" });
      }
    } catch (error) {
      console.error("DAILY FEEDBACK SUBMISSION FAILED", error);
      setFeedbackSubmitError(
        "We could not submit your feedback. Please try again."
      );
    } finally {
      setIsSubmittingFeedbackId(null);
    }
  }

  async function continueAfterPendingDoubt(strictQueueRefresh = false) {
    // The legacy auto-submit path needs to distinguish a successful save from
    // a failed queue refresh. Use the throwing loader only for that path so
    // existing Loop 2 response behavior remains unchanged elsewhere.
    let remainingDoubts: any[] | null;
    if (strictQueueRefresh) {
      remainingDoubts = await loadPendingDoubtsData();
      setPendingDoubts(remainingDoubts ?? []);
    } else {
      remainingDoubts = await loadPendingDoubts();
    }
    await loadDailyFeedbackCreditSummary();

    if (remainingDoubts === null) return;

    const nextPendingDoubt = remainingDoubts[0];
    if (nextPendingDoubt) {
      setGuidedDoubtHighlightId(nextPendingDoubt.id);
      setGuidedScrollTarget({ logId: nextPendingDoubt.id, section: "doubt" });
      return;
    }

    setGuidedDoubtHighlightId(null);
    activeLoop2QuestionDoubtRef.current = null;
    setLoop2QuestionDoubtId(null);
    const nextTodayLog = lectureLogs.find(
      (candidate) => !submittedFeedback[candidate.id]
    );

    if (nextTodayLog) {
      if (expandedCard && expandedCard !== nextTodayLog.id) {
        const draftFlushed = await flushLoop1FeedbackDraft(expandedCard);
        if (!draftFlushed) {
          setFeedbackSubmitError(
            "Your unfinished feedback could not be saved to the server yet. Please keep this page open and try again."
          );
          return;
        }
      }
      openLoop1FeedbackCard(nextTodayLog.id);
      setGuidedScrollTarget({ logId: nextTodayLog.id, section: "understanding" });
    } else {
      setGuidedScrollTarget({ logId: "", section: "credits" });
    }
  }

  function isLegacyLoop2Log(doubt: any): boolean {
    const log = historicalLectureLogs.find(
      (item: any) => String(item.id) === String(doubt.daily_log_uuid)
    );
    const rawDate = typeof log?.log_date === "string" ? log.log_date : "";
    const match = rawDate.match(/^(\d{4}-\d{2}-\d{2})(?:$|T|\s)/);
    if (!match) return false;

    // Validate the date itself rather than accepting malformed date prefixes.
    const [year, month, day] = match[1].split("-").map(Number);
    const parsedDate = new Date(Date.UTC(year, month - 1, day));
    if (
      parsedDate.getUTCFullYear() !== year ||
      parsedDate.getUTCMonth() !== month - 1 ||
      parsedDate.getUTCDate() !== day
    ) {
      return false;
    }

    // The mandatory Loop-2 Multi-Cross rollout began with Daily Logs submitted
    // on 23-Nov-2026. Only logs submitted through 22-Nov-2026 may use the
    // historical compatibility path when no Multi-Cross question set exists.
    // Never use the device's current date or the pending-doubt creation date
    // to decide this exception.
    return match[1] < LOOP2_MULTICROSS_ROLLOUT_DATE;
  }

  function getLoop2MultiQuestionsForDoubt(
    doubtId: string,
  ): Loop2MultiCrossQuestion[] {
    return loop2MultiQuestionsByDoubt[doubtId] ?? [];
  }

  function getLoop2MultiAttemptsForDoubt(
    doubtId: string,
  ): Record<string, Loop2MultiCrossQuestionAttempt> {
    return loop2MultiAttemptsByDoubt[doubtId] ?? {};
  }

  async function openLoop2MultiCrossQuestion(doubt: any): Promise<Loop2MultiCrossCapability> {
    const doubtId = String(doubt.id);

    if (loop2MultiLoadingDoubtId === doubtId) return "UNAVAILABLE";

    setFeedbackSubmitError(null);
    setLoop2MultiLoadingDoubtId(doubtId);

    try {
      /*
       * Capability is a server-authoritative enum. An empty question result is
       * never interpreted as legacy fallback because empty can also mean
       * unauthorized, resolved, malformed, or missing. Only the explicit
       * LEGACY_FALLBACK capability is allowed to return false here.
       */
      const capability = await getLoop2MultiCrossCapability(doubtId);

      if (capability === "LEGACY_FALLBACK") {
        return capability;
      }

      if (capability !== "MULTI_CROSS") {
        setFeedbackSubmitError(
          capability === "BLOCKED"
            ? "The Cross Question set cannot be verified safely right now. Your doubt has not been changed. Please ask your teacher to finish the question set and try again."
            : "We could not verify this learning gap safely. Your doubt has not been changed. Please refresh and try again.",
        );
        return capability;
      }

      const questions = await getLoop2MultiCrossQuestions(doubtId);
      if (questions.length < 2) {
        throw new Error(
          "The server reported Multi-Cross capability, but the question set could not be loaded safely.",
        );
      }

      const attempts = await getLoop2MultiCrossQuestionAttempts(doubtId);

      const attemptMap: Record<string, Loop2MultiCrossQuestionAttempt> = {};
      for (const attempt of attempts) {
        attemptMap[String(attempt.question_uuid)] = attempt;
      }

      setLoop2MultiQuestionsByDoubt((previous) => ({
        ...previous,
        [doubtId]: questions,
      }));
      setLoop2MultiAttemptsByDoubt((previous) => ({
        ...previous,
        [doubtId]: attemptMap,
      }));

      activeLoop2QuestionDoubtRef.current = doubtId;
      setLoop2QuestionDoubtId(doubtId);
      setGuidedDoubtHighlightId(doubt.id);
      setGuidedScrollTarget({ logId: doubt.id, section: "loop2question" });
      return capability;
    } catch (error) {
      console.error("LOOP-2 MULTI CROSS CAPABILITY LOAD FAILED", error);
      setFeedbackSubmitError(
        "We could not verify the Cross Question set for this learning gap. Your doubt has not been changed. Please refresh and try again.",
      );
      return "UNAVAILABLE";
    } finally {
      setLoop2MultiLoadingDoubtId((current) =>
        current === doubtId ? null : current,
      );
    }
  }

  function closeLoop2MultiBeforeFirstAttempt(doubt: any) {
    const doubtId = String(doubt.id);
    const attempts = getLoop2MultiAttemptsForDoubt(doubtId);

    /*
     * NOT DISCUSSED is a cancellation only before Q1 is attempted.
     * It deliberately does NOT call the resolver and does NOT write an
     * attempt row. YES can therefore reopen Q1 later.
     */
    if (Object.keys(attempts).length > 0) return;

    activeLoop2QuestionDoubtRef.current = null;
    setLoop2QuestionDoubtId(null);
    setSelectedResponse((previous) => ({
      ...previous,
      [doubtId]: "NOT DISCUSSED",
    }));
    setFeedbackSubmitError(null);
    setGuidedDoubtHighlightId(null);
    pendingDoubtAutoSubmitLockRef.current.delete(doubtId);
    setPendingDoubtAutoSubmittingId(null);
  }

  async function recordLoop2MultiAttempt(
    doubt: any,
    question: MultiCrossQuestion,
    selectedValue: string,
  ): Promise<Loop2MultiCrossQuestionAttempt> {
    const doubtId = String(doubt.id);

    if (
      activeLoop2QuestionDoubtRef.current !== doubtId ||
      loop2QuestionDoubtId !== doubtId
    ) {
      throw new Error("This learning-gap question is no longer active.");
    }

    const attempt = await recordLoop2MultiCrossQuestionAttempt(
      doubtId,
      String(question.id),
      selectedValue,
    );

    setLoop2MultiAttemptsByDoubt((previous) => ({
      ...previous,
      [doubtId]: {
        ...(previous[doubtId] ?? {}),
        [question.id]: attempt,
      },
    }));

    return attempt;
  }

  async function showLoop2ResolutionPopup(
    doubtId: string,
    kind: "DISCUSSED" | "NOT DISCUSSED",
  ) {
    setLoop2ResolutionPopup({
      doubtId,
      kind,
      text:
        kind === "DISCUSSED"
          ? "doubt succesfully discussed and resolved"
          : "doubt not resolved, check progress tracker",
    });

    await new Promise<void>((resolve) => {
      let settled = false;
      const finish = () => {
        if (settled) return;
        settled = true;
        loop2ResolutionPopupCloseRef.current = null;
        window.clearTimeout(timerId);
        setLoop2ResolutionPopup(null);
        resolve();
      };
      loop2ResolutionPopupCloseRef.current = finish;
      const timerId = window.setTimeout(finish, 850);
    });
  }

  function closeLoop2ResolutionPopup() {
    loop2ResolutionPopupCloseRef.current?.();
  }

  async function showLoop1FeedbackSuccessPopup() {
    setLoop1FeedbackSuccessPopup(true);

    await new Promise<void>((resolve) => {
      let settled = false;
      const finish = () => {
        if (settled) return;
        settled = true;
        loop1FeedbackSuccessPopupCloseRef.current = null;
        window.clearTimeout(timerId);
        setLoop1FeedbackSuccessPopup(false);
        resolve();
      };
      loop1FeedbackSuccessPopupCloseRef.current = finish;
      const timerId = window.setTimeout(finish, 850);
    });
  }

  function closeLoop1FeedbackSuccessPopup() {
    loop1FeedbackSuccessPopupCloseRef.current?.();
  }

  async function finishLoop2MultiTerminal(
    doubt: any,
    kind: "DISCUSSED" | "NOT DISCUSSED",
  ) {
    const doubtId = String(doubt.id);


    /*
     * The SQL RPC already performed the authoritative terminal resolution.
     * Keep the active doubt and guided-queue lock in place while the new
     * terminal acknowledgement is visible. The queue is released only after
     * the 850ms popup completes or the student closes it, so no other Loop-2 card can take ownership
     * before the student sees what was recorded.
     */
    setGuidedDoubtHighlightId(doubt.id);
    setFeedbackSubmitError(null);

    try {
      await showLoop2ResolutionPopup(doubtId, kind);

      activeLoop2QuestionDoubtRef.current = null;
      setLoop2QuestionDoubtId(null);
      pendingDoubtAutoSubmitLockRef.current.delete(doubtId);
      setPendingDoubtAutoSubmittingId(null);

      setPendingDoubts((previous) =>
        previous.filter((item: any) => String(item.id) !== doubtId),
      );
      setGuidedDoubtHighlightId(null);

      await loadDailyFeedbackCreditSummary();
      await continueAfterPendingDoubt(true);
    } catch (error) {
      /*
       * Terminal state is already committed. A refresh/read failure must never
       * turn a successful resolution into a false failure message.
       */
      console.error(
        "LOOP-2 MULTI TERMINAL SAVED BUT QUEUE REFRESH FAILED",
        error,
      );
    } finally {
      // The terminal acknowledgement has its own 850ms-or-early-close lifecycle. No delayed
      // guided-queue work is scheduled here.
    }
  }

  async function handlePendingDoubtDiscussed(doubt: any) {
    // Acquire the existing synchronous guided-queue lock BEFORE any await.
    // This prevents two cards from simultaneously entering capability detection
    // and racing to become the active Loop-2 question.
    if (pendingDoubtAutoSubmitLockRef.current.size > 0) return;
    if (
      activeLoop2QuestionDoubtRef.current !== null &&
      activeLoop2QuestionDoubtRef.current !== String(doubt.id)
    ) return;

    const doubtId = String(doubt.id);
    pendingDoubtAutoSubmitLockRef.current.add(doubtId);
    setPendingDoubtAutoSubmittingId(doubtId);

    try {
      /* Capability is determined from the exact pending doubt's Daily Log.
       * Date is never used to decide Multi-Cross capability. */
      const capability = await openLoop2MultiCrossQuestion(doubt);
      if (capability === "MULTI_CROSS") {
        // Keep the lock while the active Multi-Cross UI owns the guided queue.
        return;
      }

      /* LEGACY_FALLBACK is allowed only for the pre-rollout Daily Log boundary.
       * From 23-Nov-2026 onward, a missing/incomplete Multi-Cross set must not
       * silently bypass the mandatory question requirement.
       */
      if (capability === "LEGACY_FALLBACK") {
        if (isLegacyLoop2Log(doubt)) {
          setFeedbackSubmitError(null);
          await submitStudentPendingDoubtResponse(doubt.id, "DISCUSSED");
          await showLoop2ResolutionPopup(doubtId, "DISCUSSED");
          try {
            await continueAfterPendingDoubt(true);
          } catch (error) {
            console.error("LEGACY DOUBT SAVED BUT QUEUE REFRESH FAILED", error);
            setPendingDoubts((previous) =>
              previous.filter((item: any) => String(item.id) !== doubtId),
            );
            setFeedbackSubmitError(
              "Your response was saved, but we could not refresh the next item. This doubt has been removed from the current view to prevent a duplicate submission. Please refresh the page to continue.",
            );
          }
          return;
        }

        setFeedbackSubmitError(
          "Cross Questions are required for Daily Logs submitted on or after 23-Nov-2026. This question set is incomplete, so your doubt has not been changed. Please ask your teacher to finish the Cross Question set and try again.",
        );
        return;
      }

      // BLOCKED/UNAVAILABLE are fail-closed. The capability loader already
      // supplied the user-facing verification error; never enter the legacy
      // Loop-2 question path for these states.
    } catch (error) {
      console.error("LOOP-2 PENDING DOUBT RESPONSE FAILED", error);
      setFeedbackSubmitError(
        "We could not save your response. Your doubt has not been marked resolved. Please try again.",
      );
    } finally {
      // A live Multi-Cross sequence owns the lock until cancel/terminal.
      if (activeLoop2QuestionDoubtRef.current !== doubtId) {
        pendingDoubtAutoSubmitLockRef.current.delete(doubtId);
        setPendingDoubtAutoSubmittingId((current) =>
          current === doubtId ? null : current,
        );
      }
    }
  }

  function openLoop2CrossQuestion(doubt: any) {
    // Always resolve the question through the exact original Daily Log linked
    // to this doubt; never substitute a question from another lecture.
    const log = historicalLectureLogs.find(
      (item: any) => String(item.id) === String(doubt.daily_log_uuid)
    );
    const options = log?.cross_question_options;
    const rawCorrectIndex = log?.cross_question_correct_index;
    const correctIndex = Number(rawCorrectIndex);
    if (
      !log ||
      rawCorrectIndex === null ||
      rawCorrectIndex === undefined ||
      rawCorrectIndex === "" ||
      !(log.cross_question_text || log.cross_question_image_path) ||
      !Array.isArray(options) ||
      options.length !== 4 ||
      options.some((option: unknown) => typeof option !== "string" || !option.trim()) ||
      !Number.isInteger(correctIndex) ||
      correctIndex < 0 ||
      correctIndex > 3
    ) {
      setFeedbackSubmitError(
        "The original Cross Question for this lecture is unavailable. Your doubt has not been marked resolved. Please try again later or contact your teacher."
      );
      return;
    }
    setFeedbackSubmitError(null);
    setLoop2QuestionMessage(null);
    setLoop2QuestionImageFailedIds((previous) => ({ ...previous, [doubt.id]: false }));
    setLoop2QuestionImageLoadedIds((previous) => ({ ...previous, [doubt.id]: false }));
    setLoop2QuestionAnswers((previous) => ({ ...previous, [doubt.id]: -1 }));
    activeLoop2QuestionDoubtRef.current = String(doubt.id);
    setLoop2QuestionDoubtId(String(doubt.id));
    setGuidedDoubtHighlightId(doubt.id);
    setGuidedScrollTarget({ logId: doubt.id, section: "loop2question" });
  }

  async function submitPendingDoubt(doubt: any) {
    // While a response is saving, block submissions from every card. If a
    // Cross Question is open, only that doubt may be acted on until the guided
    // question step completes. Keep the guard here as well as in the UI.
    if (
      (activeLoop2QuestionDoubtRef.current !== null && activeLoop2QuestionDoubtRef.current !== String(doubt.id)) ||
      pendingDoubtAutoSubmitLockRef.current.size > 0 ||
      pendingDoubtAutoSubmittingId === String(doubt.id) ||
      pendingDoubtAutoSubmitLockRef.current.has(String(doubt.id))
    ) return;
    const response = selectedResponse[doubt.id];

    if (!response) {
      alert("Please select your response.");
      return;
    }

    // “Yes, discussed today” opens the original question before any Loop 2
    // response is saved. The same handler is called directly from the Yes radio.
    if (response === "DISCUSSED") {
      await handlePendingDoubtDiscussed(doubt);
      return;
    }

    const responseLockKey = `response:${String(doubt.id)}`;
    if (pendingDoubtAutoSubmitLockRef.current.size > 0) return;
    pendingDoubtAutoSubmitLockRef.current.add(responseLockKey);
    setPendingDoubtAutoSubmittingId(String(doubt.id));
    try {
      setFeedbackSubmitError(null);
      // Keep persistence failure distinct from a queue-refresh failure. A
      // successfully saved NOT DISCUSSED response must not be described as
      // unsaved merely because the follow-up queue read fails.
      await submitStudentPendingDoubtResponse(doubt.id, response);
      await showLoop2ResolutionPopup(String(doubt.id), "NOT DISCUSSED");
      try {
        await continueAfterPendingDoubt(true);
      } catch (refreshError) {
        console.error("NOT-DISCUSSED RESPONSE SAVED BUT QUEUE REFRESH FAILED", refreshError);
        // The response is already persisted and this status is no longer PENDING.
        // Remove it from the stale local queue to prevent a duplicate action.
        const remainingLocalDoubts = pendingDoubts.filter(
          (item: any) => String(item.id) !== String(doubt.id)
        );
        setPendingDoubts(remainingLocalDoubts);
        setGuidedDoubtHighlightId(null);
        setFeedbackSubmitError(
          "Your response was saved, but we could not refresh the next item. This doubt has been removed from the current view to prevent a duplicate submission. Please refresh the page to continue."
        );
        await loadDailyFeedbackCreditSummary();

        // Keep the guided journey usable using only locally known items, while
        // clearly asking for a refresh before trusting the authoritative queue.
        const nextLocalDoubt = remainingLocalDoubts[0];
        if (nextLocalDoubt) {
          setGuidedDoubtHighlightId(nextLocalDoubt.id);
          setGuidedScrollTarget({ logId: nextLocalDoubt.id, section: "doubt" });
        } else {
          const nextTodayLog = lectureLogs.find(
            (candidate) => !submittedFeedback[candidate.id]
          );
          if (nextTodayLog) {
            if (expandedCard && expandedCard !== nextTodayLog.id) {
              const draftFlushed = await flushLoop1FeedbackDraft(expandedCard);
              if (!draftFlushed) {
                setFeedbackSubmitError(
                  "Your unfinished feedback could not be saved to the server yet. Please keep this page open and try again."
                );
                return;
              }
            }
            openLoop1FeedbackCard(nextTodayLog.id);
            setGuidedScrollTarget({ logId: nextTodayLog.id, section: "understanding" });
          } else {
            setGuidedScrollTarget({ logId: "", section: "credits" });
          }
        }
      }
    } catch (error) {
      console.error("PENDING DOUBT RESPONSE SUBMISSION FAILED", error);
      setFeedbackSubmitError("We could not save your response. Your doubt has not been marked resolved. Please try again.");
    } finally {
      pendingDoubtAutoSubmitLockRef.current.delete(responseLockKey);
      setPendingDoubtAutoSubmittingId(null);
    }
  }

  async function submitLoop2CrossQuestion(doubt: any) {
    // All Loop 2 response paths share one synchronous lock. This blocks a
    // legacy Yes save, a Not-discussed save, or another question submission
    // from racing this question's response and guided queue transition.
    // A question answer may only be submitted for the currently open doubt.
    if (
      activeLoop2QuestionDoubtRef.current !== String(doubt.id) ||
      loop2QuestionDoubtId !== String(doubt.id) ||
      pendingDoubtAutoSubmitLockRef.current.size > 0
    ) return;
    const selectedIndex = loop2QuestionAnswers[doubt.id];
    if (selectedIndex === undefined || selectedIndex < 0) {
      setFeedbackSubmitError("Please select an answer before submitting.");
      return;
    }

    const log = historicalLectureLogs.find(
      (item: any) => String(item.id) === String(doubt.daily_log_uuid)
    );
    if (
      log?.cross_question_image_path &&
      (!log?.cross_question_image_url || loop2QuestionImageFailedIds[doubt.id] || !loop2QuestionImageLoadedIds[doubt.id])
    ) {
      setFeedbackSubmitError(
        "The original question image could not be loaded. Your doubt has not been marked resolved. Please refresh the page to reload the image, or contact your teacher."
      );
      return;
    }
    const rawCorrectIndex = log?.cross_question_correct_index;
    const correctIndex = Number(rawCorrectIndex);
    if (!log || rawCorrectIndex === null || rawCorrectIndex === undefined || rawCorrectIndex === "" || !Number.isInteger(correctIndex) || correctIndex < 0 || correctIndex > 3) {
      setFeedbackSubmitError("The original answer key is unavailable. Your doubt has not been marked resolved.");
      return;
    }

    const isCorrect = selectedIndex === correctIndex;
    const questionLockKey = `question:${String(doubt.id)}`;
    if (pendingDoubtAutoSubmitLockRef.current.size > 0) return;
    pendingDoubtAutoSubmitLockRef.current.add(questionLockKey);
    setLoop2QuestionBusyId(doubt.id);
    setFeedbackSubmitError(null);
    let responseSaved = false;
    try {
      // Reuse the existing Loop 2 response mechanism. Correct answer maps to
      // DISCUSSED; wrong answer maps to NOT DISCUSSED. The original Loop 1
      // attempt is never overwritten and no migration/RPC is introduced.
      await submitStudentPendingDoubtResponse(
        doubt.id,
        isCorrect ? "DISCUSSED" : "NOT DISCUSSED"
      );
      responseSaved = true;
      setLoop2QuestionMessage({
        doubtId: doubt.id,
        correct: isCorrect,
        text: isCorrect
          ? "Your doubt has been resolved."
          : "Your answer is incorrect. This doubt is not yet resolved.",
      });
      await new Promise((resolve) => window.setTimeout(resolve, 1000));
      setLoop2QuestionMessage(null);
      // Both correct and incorrect answers have now been recorded. Release
      // question ownership only after the feedback message finishes, so the
      // next doubt can proceed without leaving the queue locked to this one.
      activeLoop2QuestionDoubtRef.current = null;
      setLoop2QuestionDoubtId(null);

      // Unlike the ordinary loader, the strict loader throws on a queue
      // refresh failure. Keep that failure separate from the already-successful
      // response save so it cannot be reported as if answer verification failed.
      try {
        await continueAfterPendingDoubt(true);
      } catch (refreshError) {
        console.error("CROSS QUESTION SAVED BUT QUEUE REFRESH FAILED", refreshError);
        // The response has already been persisted. Remove this doubt from the
        // stale local queue immediately to prevent a duplicate answer/save.
        const remainingLocalDoubts = pendingDoubts.filter(
          (item: any) => String(item.id) !== String(doubt.id)
        );
        setPendingDoubts(remainingLocalDoubts);
        setGuidedDoubtHighlightId(null);
        setFeedbackSubmitError(
          "Your answer was saved, but we could not refresh the next item. This doubt has been removed from the current view to prevent a duplicate submission. Please refresh the page to continue."
        );
        await loadDailyFeedbackCreditSummary();

        // Continue to the next locally known item, if any, while clearly
        // telling the student that a refresh is required for authoritative state.
        const nextLocalDoubt = remainingLocalDoubts[0];
        if (nextLocalDoubt) {
          setGuidedDoubtHighlightId(nextLocalDoubt.id);
          setGuidedScrollTarget({ logId: nextLocalDoubt.id, section: "doubt" });
        } else {
          const nextTodayLog = lectureLogs.find(
            (candidate) => !submittedFeedback[candidate.id]
          );
          if (nextTodayLog) {
            if (expandedCard && expandedCard !== nextTodayLog.id) {
              const draftFlushed = await flushLoop1FeedbackDraft(expandedCard);
              if (!draftFlushed) {
                setFeedbackSubmitError(
                  "Your unfinished feedback could not be saved to the server yet. Please keep this page open and try again."
                );
                return;
              }
            }
            openLoop1FeedbackCard(nextTodayLog.id);
            setGuidedScrollTarget({ logId: nextTodayLog.id, section: "understanding" });
          } else {
            setGuidedScrollTarget({ logId: "", section: "credits" });
          }
        }
      }
    } catch (error) {
      console.error("LOOP-2 CROSS QUESTION RECHECK FAILED", error);
      setFeedbackSubmitError(
        responseSaved
          ? "Your answer was saved, but the next step could not be completed. Please refresh the page before continuing."
          : "We could not verify this answer. Your doubt has not been marked resolved. Please try again."
      );
    } finally {
      pendingDoubtAutoSubmitLockRef.current.delete(questionLockKey);
      setLoop2QuestionBusyId(null);
    }
  }

  async function fetchFeedbackStatement() {
    setStatementError(null);

    if (!statementSubject) {
      setStatementError("Please choose a subject.");
      return;
    }

    if (!statementStartDate || !statementEndDate) {
      setStatementError("Please choose a start date and end date.");
      return;
    }

    if (statementStartDate > statementEndDate) {
      setStatementError("Start date cannot be after end date.");
      return;
    }

    setIsFetchingStatement(true);
    setHasFetchedStatement(true);

    try {
      const isAllSubjects = statementSubject === ALL_SUBJECTS_VALUE;

      // Keep the existing dedicated statement query for normal subject
      // selection. All Subjects is intentionally assembled from the same
      // student-scoped sources already used by the credit ledger so no new
      // database path or teacher-side functionality is introduced.
      const statementSource = isAllSubjects
        ? Promise.all([
            getStudentDailyLectureLogs(true),
            getStudentFeedbackHistory(),
          ]).then(([logs, feedback]) => ({ logs, feedback }))
        : getStudentFeedbackStatementData(
            statementStartDate,
            statementEndDate,
            statementSubject
          );

      const [statementResult, loop2Result, creditStartResult] =
        await Promise.allSettled([
          statementSource,
          getStudentLoop2FeedbackHistory(),
          getStudentFeedbackCreditStartDate(),
        ]);

      if (statementResult.status === "rejected") {
        throw statementResult.reason;
      }

      const { logs, feedback } = statementResult.value;
      const loop2History =
        loop2Result.status === "fulfilled" ? loop2Result.value ?? [] : [];
      const creditStartDate =
        creditStartResult.status === "fulfilled"
          ? creditStartResult.value
          : "";

      if (loop2Result.status === "rejected") {
        console.error(
          "LOOP-2 STATEMENT FETCH FAILED — LOOP-1 RECORDS PRESERVED",
          loop2Result.reason
        );
      }

      if (creditStartResult.status === "rejected") {
        throw creditStartResult.reason;
      }

      const feedbackMap = new Map<string, any>();

      for (const item of feedback ?? []) {
        if (item?.daily_log_uuid) {
          feedbackMap.set(String(item.daily_log_uuid), item);
        }
      }

      const studentCreatedDate = toDateKey(creditStartDate);
      const today = getIndiaTodayKey();

      const loop1Rows = (logs ?? [])
        .filter((log: any) => {
          const dateKey = toDateKey(log.log_date || log.created_at);
          const inSelectedRange =
            dateKey >= statementStartDate && dateKey <= statementEndDate;
          const fromStudentAccountDate =
            !studentCreatedDate || dateKey >= studentCreatedDate;
          const matchesSubject =
            isAllSubjects ||
            String(log.subject_name ?? "").trim() ===
              String(statementSubject).trim();

          return inSelectedRange && fromStudentAccountDate && matchesSubject;
        })
        .map((log: any) => {
          const logId = String(log.id);
          const feedbackRecord = feedbackMap.get(logId);
          const dateKey = toDateKey(log.log_date || log.created_at);
          const isCompletedDay = dateKey < today;

          let creditChange = 0;
          let creditLabel = "Pending — not submitted";

          if (feedbackRecord?.understanding_level === ABSENT_FEEDBACK_OPTION) {
            creditChange = 0;
            creditLabel = "0 — absent";
          } else if (feedbackRecord) {
            creditChange = 1;
            creditLabel = "+1 credit";
          } else if (isCompletedDay) {
            creditChange = -10;
            creditLabel = "−10 debit";
          } else {
            creditLabel = "Pending — no debit yet";
          }

          return {
            id: logId,
            loop: "Loop 1",
            subjectName:
              String(log.subject_name ?? "Subject not available").trim() ||
              "Subject not available",
            date: dateKey,
            topic: log.topic_name ?? "Topic not available",
            chapter: log.chapter_name
              ? String(log.chapter_name).replace(/^__TP_MANUAL_CHAPTER__:/, "").trim() || null
              : null,
            subtopics: Array.isArray(log.concepts_covered)
              ? log.concepts_covered
              : [],
            response: feedbackRecord?.understanding_level ?? null,
            difficultConcepts: Array.isArray(
              feedbackRecord?.concepts_not_understood
            )
              ? feedbackRecord.concepts_not_understood
              : [],
            creditChange,
            creditLabel,
            balance: 0,
          } satisfies FeedbackStatementRow;
        });

      const loop2Rows = (loop2History ?? [])
        .filter((row: any) => {
          const subject = String(row.subject_name ?? "").trim();
          const eventDate = toDateKey(
            row.revision_checked_at || row.created_at || row.log_date
          );
          const matchesSubject =
            isAllSubjects || subject === String(statementSubject).trim();

          return (
            matchesSubject &&
            eventDate >= statementStartDate &&
            eventDate <= statementEndDate &&
            (!studentCreatedDate || eventDate >= studentCreatedDate)
          );
        })
        .map((row: any) => {
          const response = String(row.student_response ?? "").trim();
          const isSubmitted = isStudentLoop2Response(row);
          const dueDate = toDateKey(
            row.created_at || row.revision_checked_at || row.log_date
          );
          const isCompletedDueDate = dueDate < today;

          const status = String(row.status ?? "").trim().toUpperCase();
          const isTeacherResolved =
            status === "RESOLVED" &&
            response === "DISCUSSED" &&
            !isSubmitted;

          let creditChange = 0;
          let creditLabel = "Pending — not submitted";

          if (isSubmitted) {
            creditChange = 1;
            creditLabel = "+1 credit — Loop 2 response";
          } else if (isTeacherResolved) {
            creditLabel = "0 — resolved by teacher";
          } else if (
            status === "PENDING" &&
            isCompletedDueDate
          ) {
            creditChange = -10;
            creditLabel = "−10 debit — Loop 2 response missed";
          } else {
            creditLabel = "Pending — no debit yet";
          }

          const responseLabel = isSubmitted
            ? response === "DISCUSSED"
              ? "Yes, discussed today"
              : "Not discussed yet"
            : isTeacherResolved
              ? "Resolved by teacher"
              : null;

          return {
            id: `loop2-${String(row.id)}`,
            loop: "Loop 2",
            subjectName:
              String(row.subject_name ?? "Subject not available").trim() ||
              "Subject not available",
            date: toDateKey(
              row.revision_checked_at || row.created_at || row.log_date
            ),
            chapter: null,
            topic: row.previous_topic_name
              ? `Student-raised: ${row.previous_topic_name}`
              : "Student-raised topic not available",
            subtopics: row.previous_difficult_concept
              ? [String(row.previous_difficult_concept)]
              : [],
            response: responseLabel,
            difficultConcepts: row.previous_difficult_concept
              ? [String(row.previous_difficult_concept)]
              : [],
            creditChange,
            creditLabel,
            balance: 0,
          } satisfies FeedbackStatementRow;
        });

      const rows = [...loop1Rows, ...loop2Rows].sort((a, b) => {
        if (a.date !== b.date) return a.date.localeCompare(b.date);
        if (a.loop !== b.loop) return a.loop.localeCompare(b.loop);
        if (a.subjectName !== b.subjectName) {
          return a.subjectName.localeCompare(b.subjectName);
        }
        return a.topic.localeCompare(b.topic);
      });

      let balance = 0;
      const chronologicalRows = rows.map((row) => {
        balance += row.creditChange;
        return { ...row, balance };
      });

      setStatementRows(chronologicalRows);
    } catch (error) {
      console.error("FEEDBACK STATEMENT LOAD FAILED", error);
      setStatementRows([]);
      setStatementError(
        "We could not fetch the feedback records. Please try again."
      );
    } finally {
      setIsFetchingStatement(false);
    }
  }

  async function generateStatementPdf() {
    if (!statementRows.length) return;

    setIsGeneratingStatementPdf(true);

    try {
      const doc = new jsPDF({
        orientation: "landscape",
        unit: "mm",
        format: "a4",
      });

      const pageWidth = doc.internal.pageSize.getWidth();
      const pageHeight = doc.internal.pageSize.getHeight();
      const margin = 8;
      const usableWidth = pageWidth - margin * 2;

      const isAllSubjects = statementSubject === ALL_SUBJECTS_VALUE;
      const columnWidths = isAllSubjects
        ? [
            17, // Date
            30, // Subject
            27, // Feedback type
            31, // Topic
            46, // Subtopics
            38, // Response
            43, // Not understood
            24, // Credit
            24, // Balance
          ]
        : [
            17, // Date
            27, // Feedback type
            32, // Topic
            52, // Subtopics
            42, // Response
            48, // Not understood
            25, // Credit
            25, // Balance
          ];

      const headers = isAllSubjects
        ? [
            "Date",
            "Subject",
            "Feedback Type",
            "Topic",
            "Teacher / difficult concepts",
            "Response",
            "Not understood",
            "Credits",
            "Balance",
          ]
        : [
            "Date",
            "Feedback Type",
            "Topic",
            "Teacher / difficult concepts",
            "Response",
            "Not understood",
            "Credits",
            "Balance",
          ];

      const wrap = (text: string, width: number, fontSize = 6.5) => {
        doc.setFontSize(fontSize);
        return doc.splitTextToSize(text || "—", width - 3);
      };

      let y = 10;

      const drawHeader = () => {
        doc.setFillColor(255, 247, 237);
        doc.rect(margin, y, usableWidth, 13, "F");
        doc.setDrawColor(226, 232, 240);
        doc.rect(margin, y, usableWidth, 13);

        doc.setFont("helvetica", "bold");
        doc.setFontSize(6.5);
        doc.setTextColor(71, 85, 105);

        let x = margin;
        headers.forEach((header, index) => {
          doc.text(header, x + 1.5, y + 8);
          x += columnWidths[index];
          doc.line(x, y, x, y + 13);
        });

        y += 13;
      };

      doc.setFont("helvetica", "bold");
      doc.setFontSize(15);
      doc.setTextColor(15, 23, 42);
      doc.text("Daily Lecture Feedback Statement", margin, y + 4);

      y += 9;

      doc.setFont("helvetica", "normal");
      doc.setFontSize(7.5);
      doc.setTextColor(100, 116, 139);
      doc.text(
        `Subject: ${isAllSubjects ? ALL_SUBJECTS_LABEL : statementSubject}   |   Period: ${formatStatementDate(
          statementStartDate
        )} to ${formatStatementDate(statementEndDate)}`,
        margin,
        y + 2
      );

      y += 7;
      drawHeader();

      statementRows.forEach((row) => {
        const cells = isAllSubjects
          ? [
              formatStatementDate(row.date),
              row.subjectName,
              row.loop === "Loop 1"
                ? "Daily lecture feedback"
                : "Doubt discussion feedback",
              row.topic,
              row.subtopics.join(", "),
              getResponseLabel(row.response),
              row.difficultConcepts.length
                ? row.difficultConcepts.join(", ")
                : "—",
              row.creditChange > 0
                ? "+1"
                : row.creditChange < 0
                  ? "−10"
                  : "0",
              String(row.balance),
            ]
          : [
              formatStatementDate(row.date),
              row.loop === "Loop 1"
                ? "Daily lecture feedback"
                : "Doubt discussion feedback",
              row.topic,
              row.subtopics.join(", "),
              getResponseLabel(row.response),
              row.difficultConcepts.length
                ? row.difficultConcepts.join(", ")
                : "—",
              row.creditChange > 0
                ? "+1"
                : row.creditChange < 0
                  ? "−10"
                  : "0",
              String(row.balance),
            ];

        const wrapped = cells.map((cell, index) =>
          wrap(String(cell), columnWidths[index])
        );

        const maxLines = Math.max(...wrapped.map((lines) => lines.length));
        const rowHeight = Math.max(9, maxLines * 3.2 + 3);

        if (y + rowHeight > pageHeight - 10) {
          doc.addPage();
          y = 10;
          drawHeader();
        }

        let x = margin;
        doc.setDrawColor(226, 232, 240);
        doc.setFont("helvetica", "normal");
        doc.setFontSize(6.5);
        doc.setTextColor(51, 65, 85);

        wrapped.forEach((lines, index) => {
          const color =
            index === 5 && row.creditChange > 0
              ? [22, 163, 74]
              : index === 5 && row.creditChange < 0
                ? [220, 38, 38]
                : [51, 65, 85];

          doc.setTextColor(color[0], color[1], color[2]);
          doc.text(lines, x + 1.5, y + 4.5, {
            baseline: "top",
          });
          x += columnWidths[index];
          doc.line(x, y, x, y + rowHeight);
        });

        doc.setDrawColor(226, 232, 240);
        doc.line(margin, y + rowHeight, margin + usableWidth, y + rowHeight);
        y += rowHeight;
      });

      doc.setFont("helvetica", "bold");
      doc.setFontSize(7);
      doc.setTextColor(100, 116, 139);
      doc.text(
        "Credit rule: +1 for successful feedback; −10 for a missed completed-day teacher log; today's pending feedback is not debited yet.",
        margin,
        pageHeight - 5
      );

      const pdfBlob = doc.output("blob");
      if (!(pdfBlob instanceof Blob) || pdfBlob.size <= 0) {
        throw new Error("Generated PDF blob was empty.");
      }

      const fileName =
        `Daily-Lecture-Feedback-${statementStartDate}-to-${statementEndDate}.pdf`;

      if (Capacitor.isNativePlatform()) {
        await downloadOrSharePdfBlob(
          pdfBlob,
          fileName,
          "Talent Passport — Daily Lecture Feedback"
        );
      } else {
        await downloadPdfBlobOnWeb(pdfBlob, fileName);
      }
    } catch (error) {
      console.error("DAILY FEEDBACK PDF GENERATION FAILED", error);
      alert("The PDF could not be generated. Please try again.");
    } finally {
      setIsGeneratingStatementPdf(false);
    }
  }

return (
  <>
    <style>{`
      /* =========================================================
         DAILY LECTURE FEEDBACK
         COMPACT RESPONSIVE UI
         FUNCTIONAL LOGIC UNCHANGED
      ========================================================= */

      .dlf-page,
      .dlf-page * {
        box-sizing: border-box;
      }

      .dlf-page {
        width: 100%;
        min-width: 0;
        color: #0f172a;
      }

      .dlf-surface {
        width: 100%;
        min-width: 0;
        background: #ffffff;
        border: 1px solid #dbe4ef;
        border-radius: 22px;
        box-shadow: 0 5px 18px rgba(15, 23, 42, 0.035);
      }

      .dlf-eyebrow {
        color: #f97316;
        font-size: 12px;
        line-height: 1.2;
        font-weight: 900;
        letter-spacing: 1.5px;
        text-transform: uppercase;
      }

      .dlf-title {
        margin: 7px 0 0;
        color: #0f172a;
        font-size: 26px;
        line-height: 1.12;
        font-weight: 900;
        letter-spacing: -0.55px;
      }

      .dlf-copy {
        margin: 7px 0 0;
        max-width: 720px;
        color: #64748b;
        font-size: 15px;
        line-height: 1.48;
      }


      /* =========================================================
         LEARNING GAP STATUS
      ========================================================= */

      .dlf-gap-section {
        position: relative;
        overflow: hidden;
        padding: 22px 24px;
        margin-bottom: 18px;
      }

      .dlf-section-head {
        position: relative;
        z-index: 1;
        display: flex;
        align-items: flex-start;
        justify-content: space-between;
        gap: 18px;
      }

      .dlf-status-pill {
        flex-shrink: 0;
        padding: 8px 12px;
        border-radius: 999px;
        font-size: 11px;
        line-height: 1;
        font-weight: 900;
        letter-spacing: 0.45px;
        text-transform: uppercase;
      }

      .dlf-status-orange {
        color: #c2410c;
        background: #fff7ed;
        border: 1px solid #fed7aa;
      }

      .dlf-gap-grid {
        position: relative;
        z-index: 1;
        display: grid;
        grid-template-columns: repeat(2, minmax(0, 1fr));
        gap: 12px;
        margin-top: 17px;
      }

      .dlf-gap-card {
        padding: 16px;
        border: 1px solid #fed7aa;
        border-radius: 16px;
        background: #fffaf5;
        transition: border-color 180ms ease, box-shadow 180ms ease;
      }

      .dlf-gap-card-guided {
        border: 2px solid #f97316;
        box-shadow: 0 0 0 4px rgba(249, 115, 22, 0.16);
      }

      .dlf-gap-meta-grid {
        display: grid;
        grid-template-columns: repeat(2, minmax(0, 1fr));
        gap: 8px;
      }

      .dlf-gap-meta {
        min-width: 0;
        padding: 10px 11px;
        border: 1px solid #edf2f7;
        border-radius: 10px;
        background: #ffffff;
      }

      .dlf-label {
        display: block;
        margin-bottom: 4px;
        color: #94a3b8;
        font-size: 10px;
        line-height: 1.2;
        font-weight: 900;
        letter-spacing: 0.75px;
        text-transform: uppercase;
      }

      .dlf-value {
        color: #25324a;
        font-size: 13px;
        line-height: 1.35;
        font-weight: 800;
        overflow-wrap: anywhere;
      }

      .dlf-value-orange {
        color: #c2410c;
      }

      .dlf-gap-question {
        margin: 12px 0 0;
        color: #475569;
        font-size: 13px;
        line-height: 1.45;
        font-weight: 600;
      }

      .dlf-response-options {
        display: grid;
        grid-template-columns: repeat(2, minmax(0, 1fr));
        gap: 8px;
        margin-top: 11px;
      }

      .dlf-choice {
        display: flex;
        align-items: center;
        gap: 8px;
        min-width: 0;
        padding: 10px 11px;
        border: 1px solid #dbe4ef;
        border-radius: 10px;
        background: #ffffff;
        color: #334155;
        font-size: 12px;
        line-height: 1.3;
        font-weight: 750;
        cursor: pointer;
      }

      .dlf-choice input {
        flex: 0 0 auto;
        width: 15px;
        height: 15px;
        accent-color: #f97316;
      }

      .dlf-submit-gap {
        min-height: 36px;
        margin-top: 11px;
        padding: 0 15px;
        border: 0;
        border-radius: 9px;
        background: #0f2f63;
        color: #ffffff;
        font-size: 11px;
        font-weight: 900;
        letter-spacing: 0.3px;
        cursor: pointer;
      }


      /* =========================================================
         NO LEARNING GAPS
      ========================================================= */

      .dlf-clear-card {
        position: relative;
        overflow: hidden;
        margin-bottom: 18px;
        padding: 17px 22px;
        border-color: #86efac;
        background: linear-gradient(135deg, #f4fff8 0%, #ffffff 100%);
      }

      .dlf-clear-row {
        position: relative;
        z-index: 1;
        display: flex;
        align-items: center;
        gap: 14px;
      }

      .dlf-clear-icon {
        width: 44px;
        height: 44px;
        flex: 0 0 44px;
        display: flex;
        align-items: center;
        justify-content: center;
        border: 1px solid #86efac;
        border-radius: 13px;
        background: #dcfce7;
        color: #16a34a;
        font-size: 22px;
        font-weight: 900;
      }

      .dlf-clear-eyebrow {
        color: #16a34a;
        font-size: 11px;
        line-height: 1.2;
        font-weight: 900;
        letter-spacing: 1.4px;
        text-transform: uppercase;
      }

      .dlf-clear-title {
        margin: 3px 0 0;
        color: #166534;
        font-size: 20px;
        line-height: 1.2;
        font-weight: 900;
      }

      .dlf-clear-copy {
        margin: 4px 0 0;
        color: #64748b;
        font-size: 13px;
        line-height: 1.42;
      }


      .dlf-loading {
        min-height: 220px; display: flex; align-items: center;
        justify-content: center; padding: 28px 18px; text-align: center;
      }
      .dlf-loading-card {
        width: min(470px, 100%); padding: 26px 22px;
        border: 1px solid #dbe4ef; border-radius: 18px; background: #f8fafc;
      }
      .dlf-loading-spinner {
        width: 40px; height: 40px; margin: 0 auto;
        border: 4px solid #ffedd5; border-top-color: #f97316;
        border-radius: 50%; animation: dlf-spin .8s linear infinite;
      }
      .dlf-loading-title { margin: 15px 0 0; color: #0f172a; font-size: 17px; font-weight: 900; }
      .dlf-loading-copy { margin: 7px auto 0; max-width: 390px; color: #64748b; font-size: 13px; line-height: 1.5; }
      @keyframes dlf-spin { to { transform: rotate(360deg); } }

      /* =========================================================
         DAILY FEEDBACK LEDGER
      ========================================================= */

      .dlf-ledger {
        position: relative;
        overflow: hidden;
        padding: 22px 24px 24px;
      }

      .dlf-ledger-count {
        flex-shrink: 0;
        display: flex;
        align-items: center;
        gap: 7px;
        padding: 8px 11px;
        border: 1px solid #dbe4ef;
        border-radius: 11px;
        background: #f8fafc;
        color: #64748b;
        font-size: 10px;
        line-height: 1;
        font-weight: 900;
        letter-spacing: 0.5px;
        text-transform: uppercase;
      }

      .dlf-ledger-count strong {
        color: #f97316;
        font-size: 20px;
        line-height: 1;
      }

      .dlf-feed {
        display: flex;
        flex-direction: column;
        gap: 13px;
        margin-top: 18px;
      }


      /* =========================================================
         LECTURE CARD
      ========================================================= */

      .dlf-lecture-card {
        position: relative;
        overflow: hidden;
        border: 1px solid #dbe4ef;
        border-radius: 17px;
        background: #ffffff;
      }

      .dlf-lecture-card::before {
        content: "";
        position: absolute;
        left: 0;
        top: 0;
        bottom: 0;
        width: 4px;
        background: #f97316;
      }

      /* NEW:
         clear green/orange card edge depending on feedback state */

      .dlf-lecture-card-submitted {
        border-color: #bbf7d0;
      }

      .dlf-lecture-card-submitted::before {
        background: #16a34a;
      }

      .dlf-lecture-card-pending {
        border-color: #fed7aa;
      }

      .dlf-lecture-card-pending::before {
        background: #f97316;
      }

      .dlf-lecture-row {
        display: grid;
        grid-template-columns: minmax(0, 1fr) 320px;
        gap: 18px;
        padding: 18px 18px 18px 21px;
      }

      .dlf-lecture-main {
        min-width: 0;
      }


      /* =========================================================
         NEW — TOP LECTURE HEADER + STATUS
      ========================================================= */

      .dlf-lecture-top {
        display: flex;
        align-items: flex-start;
        justify-content: space-between;
        gap: 14px;
        min-width: 0;
      }

      .dlf-lecture-heading {
        flex: 1 1 auto;
        min-width: 0;
      }

      .dlf-card-status {
        flex: 0 0 auto;
        display: inline-flex;
        align-items: center;
        gap: 7px;
        min-height: 34px;
        padding: 5px 10px 5px 6px;
        border-radius: 999px;
        white-space: nowrap;
        font-size: 10px;
        line-height: 1;
        font-weight: 900;
        letter-spacing: 0.45px;
        text-transform: uppercase;
      }

      .dlf-card-status-icon {
        width: 22px;
        height: 22px;
        flex: 0 0 22px;
        display: flex;
        align-items: center;
        justify-content: center;
        border-radius: 50%;
        font-size: 13px;
        line-height: 1;
        font-weight: 900;
      }

      .dlf-card-status-submitted {
        color: #15803d;
        border: 1px solid #86efac;
        background: #f0fdf4;
      }

      .dlf-card-status-submitted .dlf-card-status-icon {
        color: #ffffff;
        background: #16a34a;
      }

      .dlf-card-status-pending {
        color: #c2410c;
        border: 1px solid #fdba74;
        background: #fff7ed;
      }

      .dlf-card-status-pending .dlf-card-status-icon {
        color: #ffffff;
        background: #f97316;
      }


      .dlf-subject-row {
        display: flex;
        flex-wrap: wrap;
        align-items: center;
        gap: 9px;
      }

      .dlf-subject {
        display: inline-flex;
        align-items: center;
        min-height: 27px;
        padding: 0 10px;
        border: 1px solid #bfdbfe;
        border-radius: 8px;
        background: #eff6ff;
        color: #1d4ed8;
        font-size: 10px;
        line-height: 1;
        font-weight: 900;
        letter-spacing: 0.55px;
        text-transform: uppercase;
      }

      .dlf-date {
        color: #94a3b8;
        font-size: 11px;
        line-height: 1.2;
        font-weight: 800;
      }

      .dlf-topic {
        margin: 10px 0 0;
        color: #0f172a;
        font-size: 21px;
        line-height: 1.2;
        font-weight: 900;
        letter-spacing: -0.3px;
      }


      /* =========================================================
         CONCEPTS
      ========================================================= */

      .dlf-covered {
        margin-top: 12px;
        padding: 12px 13px;
        border: 1px solid #bfdbfe;
        border-radius: 12px;
        background: #f8fbff;
      }

      .dlf-covered-title {
        color: #1e3a8a;
        font-size: 10px;
        line-height: 1.2;
        font-weight: 900;
        letter-spacing: 0.75px;
        text-transform: uppercase;
      }

      .dlf-concepts {
        display: flex;
        flex-wrap: wrap;
        gap: 6px;
        margin-top: 8px;
      }

      .dlf-concept-chip {
        padding: 6px 9px;
        border: 1px solid #cfe1ff;
        border-radius: 8px;
        background: #ffffff;
        color: #334155;
        font-size: 12px;
        line-height: 1.2;
        font-weight: 750;
      }


      /* =========================================================
         LECTURE META
      ========================================================= */

      .dlf-meta {
        display: grid;
        grid-template-columns: repeat(4, minmax(0, 1fr));
        gap: 7px;
        margin-top: 10px;
      }

      .dlf-meta-item {
        min-width: 0;
        padding: 9px 10px;
        border: 1px solid #e5ebf3;
        border-radius: 10px;
        background: #f8fafc;
      }

      .dlf-meta-item-wide {
        grid-column: span 2;
      }

      .dlf-meta-value {
        color: #334155;
        font-size: 12px;
        line-height: 1.35;
        font-weight: 800;
        overflow-wrap: anywhere;
      }


      /* =========================================================
         FEEDBACK PANEL
      ========================================================= */

      .dlf-feedback-panel {
        min-width: 0;
        align-self: stretch;
        padding-left: 17px;
        border-left: 1px solid #e8edf4;
      }

      .dlf-feedback-empty {
        height: 100%;
        min-height: 132px;
        display: flex;
        flex-direction: column;
        align-items: flex-start;
        justify-content: center;
        padding: 15px;
        border: 1px dashed #fdba74;
        border-radius: 13px;
        background: #fffaf5;
      }

      .dlf-feedback-empty-label {
        color: #ea580c;
        font-size: 10px;
        line-height: 1.2;
        font-weight: 900;
        letter-spacing: 0.8px;
        text-transform: uppercase;
      }

      .dlf-feedback-empty-title {
        margin-top: 5px;
        color: #0f172a;
        font-size: 15px;
        line-height: 1.3;
        font-weight: 900;
      }

      .dlf-feedback-empty-copy {
        margin-top: 4px;
        color: #64748b;
        font-size: 12px;
        line-height: 1.4;
      }

      .dlf-feedback-button {
        min-height: 36px;
        margin-top: 10px;
        padding: 0 14px;
        border: 0;
        border-radius: 9px;
        background: #ff6b00;
        color: #ffffff;
        font-size: 11px;
        line-height: 1;
        font-weight: 900;
        letter-spacing: 0.2px;
        cursor: pointer;
      }


      /* =========================================================
         SUBMITTED FEEDBACK
      ========================================================= */

      .dlf-submitted {
        display: flex;
        flex-direction: column;
        gap: 8px;
      }

      .dlf-submitted-head {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 8px;
        padding: 10px 11px;
        border: 1px solid #86efac;
        border-radius: 10px;
        background: #f0fdf4;
      }

      .dlf-submitted-head span:first-child {
        color: #15803d;
        font-size: 12px;
        line-height: 1.25;
        font-weight: 900;
      }

      .dlf-submitted-head span:last-child {
        color: #16a34a;
        font-size: 10px;
        line-height: 1;
        font-weight: 900;
        letter-spacing: 0.45px;
        text-transform: uppercase;
      }

      .dlf-feedback-info {
        padding: 10px 11px;
        border: 1px solid #dbe4ef;
        border-radius: 10px;
        background: #f8fafc;
      }

      .dlf-feedback-info-red {
        border-color: #fca5a5;
        background: #fff7f7;
      }

      .dlf-feedback-info-orange {
        border-color: #fdba74;
        background: #fffaf5;
      }

      .dlf-feedback-info-title {
        margin-bottom: 5px;
        color: #94a3b8;
        font-size: 10px;
        line-height: 1.2;
        font-weight: 900;
        letter-spacing: 0.7px;
        text-transform: uppercase;
      }

      .dlf-feedback-info-value {
        color: #334155;
        font-size: 13px;
        line-height: 1.4;
        font-weight: 750;
      }

      .dlf-feedback-info-red .dlf-feedback-info-title {
        color: #dc2626;
      }

      .dlf-feedback-info-orange .dlf-feedback-info-title {
        color: #ea580c;
      }

      .dlf-difficult-list {
        display: flex;
        flex-wrap: wrap;
        gap: 6px;
      }

      .dlf-difficult-chip {
        padding: 6px 8px;
        border: 1px solid #fca5a5;
        border-radius: 7px;
        background: #ffffff;
        color: #b91c1c;
        font-size: 11px;
        line-height: 1.2;
        font-weight: 800;
      }


      /* =========================================================
         FEEDBACK FORM
      ========================================================= */

      .dlf-form {
        margin: 0 18px 18px 21px;
        padding: 16px;
        border: 1px solid #fdba74;
        border-radius: 14px;
        background: #fffaf5;
      }

      .dlf-form-head {
        display: flex;
        align-items: center;
        gap: 10px;
        padding-bottom: 11px;
        border-bottom: 1px solid #ffedd5;
      }

      .dlf-form-icon {
        width: 35px;
        height: 35px;
        flex: 0 0 35px;
        display: flex;
        align-items: center;
        justify-content: center;
        border: 1px solid #fed7aa;
        border-radius: 10px;
        background: #fff7ed;
        color: #ea580c;
        font-size: 16px;
        font-weight: 900;
      }

      .dlf-form-eyebrow {
        color: #ea580c;
        font-size: 10px;
        line-height: 1.2;
        font-weight: 900;
        letter-spacing: 0.8px;
        text-transform: uppercase;
      }

      .dlf-form-title {
        margin-top: 3px;
        color: #0f172a;
        font-size: 14px;
        line-height: 1.3;
        font-weight: 900;
      }

      .dlf-option-grid {
        display: grid;
        grid-template-columns: repeat(2, minmax(0, 1fr));
        gap: 7px;
        margin-top: 12px;
      }

      .dlf-form-choice {
        display: flex;
        align-items: center;
        gap: 8px;
        min-width: 0;
        padding: 9px 10px;
        border: 1px solid #dbe4ef;
        border-radius: 9px;
        background: #ffffff;
        color: #334155;
        font-size: 12px;
        line-height: 1.35;
        font-weight: 750;
        cursor: pointer;
      }

      .dlf-form-choice input {
        width: 15px;
        height: 15px;
        flex: 0 0 auto;
        accent-color: #f97316;
      }

      .dlf-form-section {
        margin-top: 14px;
        padding-top: 13px;
        border-top: 1px solid #ffedd5;
      }

      .dlf-form-label {
        color: #0f172a;
        font-size: 13px;
        line-height: 1.4;
        font-weight: 850;
      }

      .dlf-textarea {
        width: 100%;
        min-height: 66px;
        margin-top: 8px;
        padding: 10px 11px;
        resize: vertical;
        outline: none;
        border: 1px solid #cbd5e1;
        border-radius: 9px;
        background: #ffffff;
        color: #0f172a;
        font: inherit;
        font-size: 13px;
        line-height: 1.45;
      }

      .dlf-textarea:focus {
        border-color: #fb923c;
        box-shadow: 0 0 0 3px rgba(249,115,22,0.08);
      }

      .dlf-form-actions {
        display: flex;
        align-items: center;
        justify-content: flex-end;
        gap: 8px;
        margin-top: 14px;
      }

      .dlf-cancel-button,
      .dlf-submit-button {
        min-height: 36px;
        padding: 0 14px;
        border-radius: 9px;
        font-size: 11px;
        line-height: 1;
        font-weight: 900;
        cursor: pointer;
      }

      .dlf-cancel-button {
        border: 1px solid #cbd5e1;
        background: #ffffff;
        color: #475569;
      }

      .dlf-submit-button {
        border: 1px solid #ff6b00;
        background: #ff6b00;
        color: #ffffff;
      }


      /* =========================================================
         EMPTY STATE
      ========================================================= */

      .dlf-empty {
        margin-top: 17px;
        padding: 30px 20px;
        border: 1px dashed #cbd5e1;
        border-radius: 16px;
        background: #fafcff;
        text-align: center;
      }

      .dlf-empty-icon {
        width: 42px;
        height: 42px;
        margin: 0 auto;
        display: flex;
        align-items: center;
        justify-content: center;
        border: 1px solid #fed7aa;
        border-radius: 12px;
        background: #fff7ed;
        color: #ea580c;
        font-size: 18px;
      }

      .dlf-empty h2 {
        margin: 10px 0 0;
        color: #0f172a;
        font-size: 18px;
        line-height: 1.25;
        font-weight: 900;
      }

      .dlf-empty p {
        max-width: 580px;
        margin: 6px auto 0;
        color: #64748b;
        font-size: 13px;
        line-height: 1.5;
      }


      /* =========================================================
         DAILY FEEDBACK CREDIT LEDGER
         Same responsive credit language as CreditDashboard
      ========================================================= */

      .dlf-credit-section {
        position: relative;
        overflow: hidden;
        margin-bottom: 18px;
        padding: 22px 24px 24px;
      }

      .dlf-credit-grid {
        display: grid;
        grid-template-columns: repeat(3, minmax(0, 1fr));
        gap: 14px;
        margin-top: 14px;
      }

      .dlf-credit-card {
        position: relative;
        overflow: hidden;
        min-height: 102px;
        border-radius: 18px;
        padding: 17px 20px;
      }

      .dlf-credit-card::after {
        content: "";
        position: absolute;
        width: 82px;
        height: 82px;
        border-radius: 50%;
        right: -26px;
        top: -34px;
        pointer-events: none;
      }

      .dlf-credit-card-inner {
        position: relative;
        z-index: 1;
      }

      .dlf-credit-label {
        font-size: 10px;
        line-height: 1.2;
        font-weight: 800;
        letter-spacing: .7px;
      }

      .dlf-credit-value {
        margin-top: 11px;
        font-size: 27px;
        line-height: 1;
        font-weight: 900;
      }

      .dlf-credit-copy {
        margin-top: 9px;
        color: #64748B;
        font-size: 11px;
        line-height: 1.4;
        font-weight: 600;
      }

      .dlf-credit-earned {
        background: linear-gradient(135deg, #F0FDF4 0%, #FBFFFC 100%);
        border: 1px solid #BBF7D0;
      }

      .dlf-credit-earned::after { background: rgba(22,163,74,.07); }
      .dlf-credit-earned .dlf-credit-label { color: #166534; }
      .dlf-credit-earned .dlf-credit-value { color: #16A34A; }

      .dlf-credit-lost {
        background: linear-gradient(135deg, #FFF7F7 0%, #FFFCFC 100%);
        border: 1px solid #FCA5A5;
      }

      .dlf-credit-lost::after { background: rgba(220,38,38,.06); }
      .dlf-credit-lost .dlf-credit-label { color: #B91C1C; }
      .dlf-credit-lost .dlf-credit-value { color: #DC2626; }

      .dlf-credit-total {
        background: linear-gradient(135deg, #FFF8EF 0%, #FFFCF7 100%);
        border: 1px solid #FED7AA;
      }

      .dlf-credit-total::after { background: rgba(249,115,22,.08); }
      .dlf-credit-total .dlf-credit-label { color: #9A3412; }
      .dlf-credit-total .dlf-credit-value { color: #F97316; }

      .dlf-credit-formula {
        margin-top: 12px;
        padding: 9px 11px;
        border: 1px solid #E2E8F0;
        border-radius: 10px;
        background: #F8FAFC;
        color: #64748B;
        font-size: 11px;
        line-height: 1.4;
        font-weight: 700;
      }

      @media (max-width: 1024px) {
        .dlf-credit-section { padding: 19px 20px 20px; margin-bottom: 15px; }
        .dlf-credit-grid { gap: 8px; }
        .dlf-credit-card { min-height: 64px; padding: 9px 9px; }
        .dlf-credit-card::after { width: 58px; height: 58px; }
        .dlf-credit-label { font-size: 7.5px; }
        .dlf-credit-value { margin-top: 5px; font-size: 20px; }
        .dlf-credit-copy { margin-top: 5px; font-size: 8.5px; }
        .dlf-credit-formula { font-size: 10px; }
      }

      @media (max-width: 767px) {
        .dlf-credit-section { padding: 15px; margin-bottom: 12px; }
        .dlf-credit-grid { grid-template-columns: repeat(3, minmax(0, 1fr)); gap: 5px; margin-top: 10px; }
        .dlf-credit-card { min-height: 68px; border-radius: 18px; padding: 8px 7px; }
        .dlf-credit-card::after { width: 66px; height: 66px; right: -34px; top: -42px; }
        .dlf-credit-label { font-size: 6.5px; letter-spacing: .7px; }
        .dlf-credit-value { margin-top: 5px; font-size: 18px; }
        .dlf-credit-copy { margin-top: 5px; font-size: 7px; line-height: 1.4; }
        .dlf-credit-formula { margin-top: 9px; padding: 8px 9px; font-size: 9px; }
      }

      /* =========================================================
         TABLET
      ========================================================= */

      @media (max-width: 1024px) {

        .dlf-gap-section {
          padding: 18px 20px;
          margin-bottom: 15px;
        }

        .dlf-clear-card {
          padding: 15px 18px;
          margin-bottom: 15px;
        }

        .dlf-ledger {
          padding: 19px 20px 20px;
        }

        .dlf-title {
          font-size: 24px;
        }

        .dlf-copy {
          font-size: 14px;
        }

        /* CREDIT + TODAY'S FEEDBACK COPY — COMPACT ON TABLET */
        .dlf-credit-section .dlf-copy,
        .dlf-ledger > .dlf-section-head .dlf-copy {
          font-size: 11.5px;
          line-height: 1.32;
          max-width: 560px;
        }

        /* COMPACT LECTURE CARDS — TABLET */
        .dlf-lecture-card {
          border-radius: 11px;
        }

        .dlf-lecture-row {
          gap: 8px;
          padding: 9px 9px 9px 12px;
        }

        .dlf-lecture-top {
          gap: 6px;
        }

        .dlf-subject-row {
          gap: 6px;
        }

        .dlf-subject {
          min-height: 22px;
          padding: 0 7px;
          font-size: 8px;
          border-radius: 7px;
        }

        .dlf-date {
          font-size: 9px;
        }

        .dlf-topic {
          margin-top: 6px;
          font-size: 16px;
          line-height: 1.14;
        }

        .dlf-covered {
          margin-top: 7px;
          padding: 7px 8px;
          border-radius: 9px;
        }

        .dlf-covered-title {
          font-size: 8px;
        }

        .dlf-concepts {
          gap: 4px;
          margin-top: 5px;
        }

        .dlf-concept-chip {
          padding: 4px 6px;
          border-radius: 7px;
          font-size: 9px;
        }

        .dlf-meta {
          gap: 4px;
          margin-top: 6px;
        }

        .dlf-meta-item {
          padding: 6px 7px;
          border-radius: 8px;
        }

        .dlf-label {
          margin-bottom: 2px;
          font-size: 7px;
          letter-spacing: .55px;
        }

        .dlf-meta-value {
          font-size: 9px;
          line-height: 1.25;
        }

        .dlf-feedback-panel {
          margin-top: 7px;
          padding: 7px 0 0;
        }

        .dlf-submitted {
          gap: 4px;
        }

        .dlf-submitted-head {
          padding: 6px 7px;
          border-radius: 8px;
        }

        .dlf-submitted-head span:first-child {
          font-size: 9px;
        }

        .dlf-submitted-head span:last-child {
          font-size: 8px;
        }

        .dlf-feedback-info {
          padding: 6px 7px;
          border-radius: 8px;
        }

        .dlf-feedback-info-title {
          margin-bottom: 3px;
          font-size: 7px;
        }

        .dlf-feedback-info-value {
          font-size: 9.5px;
          line-height: 1.28;
        }

        .dlf-difficult-list {
          gap: 4px;
        }

        .dlf-difficult-chip {
          padding: 4px 5px;
          border-radius: 6px;
          font-size: 9px;
        }

        /* COMPACT GREEN LEARNING-GAP STATUS — TABLET */
        .dlf-clear-card {
          padding: 10px 12px;
        }

        .dlf-clear-row {
          gap: 8px;
        }

        .dlf-clear-icon {
          width: 32px;
          height: 32px;
          flex-basis: 32px;
          border-radius: 9px;
          font-size: 17px;
        }

        .dlf-clear-eyebrow {
          font-size: 8px;
          letter-spacing: .9px;
        }

        .dlf-clear-title {
          margin-top: 2px;
          font-size: 15px;
          line-height: 1.15;
        }

        .dlf-clear-copy {
          margin-top: 2px;
          font-size: 10.5px;
          line-height: 1.28;
        }

        .dlf-gap-grid {
          grid-template-columns: 1fr;
        }

        .dlf-lecture-row {
          grid-template-columns: 1fr;
          gap: 13px;
          padding: 16px 16px 16px 19px;
        }

        .dlf-feedback-panel {
          padding: 13px 0 0;
          border-left: 0;
          border-top: 1px solid #e8edf4;
        }

        .dlf-feedback-empty {
          min-height: 0;
        }

        .dlf-meta {
          grid-template-columns: repeat(2, minmax(0, 1fr));
        }

        .dlf-meta-item-wide {
          grid-column: span 1;
        }

        .dlf-form {
          margin: 0 16px 16px 19px;
        }

        .dlf-option-grid {
          grid-template-columns: repeat(2, minmax(0, 1fr));
        }

        .dlf-card-status {
          min-height: 32px;
        }
      }


      /* =========================================================
         MOBILE
      ========================================================= */

      @media (max-width: 767px) {

        .dlf-surface {
          border-radius: 16px;
        }

        .dlf-gap-section {
          padding: 15px;
          margin-bottom: 12px;
        }

        .dlf-section-head {
          align-items: flex-start;
          gap: 8px;
        }

        .dlf-eyebrow {
          font-size: 9px;
          letter-spacing: 1.1px;
        }

        .dlf-title {
          margin-top: 5px;
          font-size: 20px;
          line-height: 1.15;
        }

        .dlf-copy {
          margin-top: 5px;
          font-size: 13px;
          line-height: 1.4;
        }

        /* ONLY THE TWO REQUESTED HEADER PARAGRAPHS */
        .dlf-credit-section .dlf-copy,
        .dlf-ledger > .dlf-section-head .dlf-copy {
          font-size: 10.5px;
          line-height: 1.3;
          max-width: 300px;
        }

        .dlf-status-pill {
          padding: 6px 8px;
          font-size: 9px;
        }

        .dlf-gap-grid {
          gap: 9px;
          margin-top: 12px;
        }

        .dlf-gap-card {
          padding: 12px;
          border-radius: 12px;
        }

        .dlf-gap-meta-grid {
          gap: 6px;
        }

        .dlf-gap-meta {
          padding: 8px;
          border-radius: 8px;
        }

        .dlf-label {
          margin-bottom: 3px;
          font-size: 9px;
        }

        .dlf-value {
          font-size: 12px;
        }

        .dlf-gap-question {
          margin-top: 9px;
          font-size: 12px;
        }

        .dlf-response-options {
          grid-template-columns: 1fr;
          gap: 6px;
          margin-top: 9px;
        }

        .dlf-choice {
          padding: 9px;
          font-size: 12px;
        }

        .dlf-submit-gap {
          width: 100%;
          min-height: 38px;
          margin-top: 9px;
          font-size: 11px;
        }


        /* CLEAR STATUS */

        .dlf-clear-card {
          padding: 9px 10px;
          margin-bottom: 12px;
        }

        .dlf-clear-row {
          gap: 7px;
        }

        .dlf-clear-icon {
          width: 30px;
          height: 30px;
          flex-basis: 30px;
          border-radius: 8px;
          font-size: 16px;
        }

        .dlf-clear-eyebrow {
          font-size: 7.5px;
          letter-spacing: .8px;
        }

        .dlf-clear-title {
          margin-top: 1px;
          font-size: 14px;
          line-height: 1.12;
        }

        .dlf-clear-copy {
          margin-top: 2px;
          font-size: 9.5px;
          line-height: 1.25;
        }


        /* LEDGER */

        .dlf-ledger {
          padding: 15px;
        }

        .dlf-ledger .dlf-section-head {
          align-items: flex-start;
        }

        .dlf-ledger-count {
          padding: 6px 8px;
          gap: 5px;
          border-radius: 8px;
          font-size: 8px;
        }

        .dlf-ledger-count strong {
          font-size: 17px;
        }

        .dlf-feed {
          gap: 10px;
          margin-top: 13px;
        }


        /* LECTURE */

        .dlf-lecture-card {
          border-radius: 11px;
        }

        .dlf-lecture-card::before {
          width: 3px;
        }

        .dlf-lecture-row {
          display: block;
          padding: 8px 8px 8px 11px;
        }

        .dlf-lecture-top {
          gap: 6px;
        }

        .dlf-subject-row {
          gap: 5px;
        }

        .dlf-subject {
          min-height: 21px;
          padding: 0 6px;
          font-size: 7.5px;
          border-radius: 6px;
        }

        .dlf-date {
          font-size: 8.5px;
        }

        .dlf-topic {
          margin-top: 5px;
          font-size: 15px;
          line-height: 1.12;
        }


        /* NEW MOBILE STATUS */

        .dlf-card-status {
          min-height: 29px;
          gap: 5px;
          padding: 4px 8px 4px 4px;
          font-size: 9px;
          letter-spacing: 0.3px;
        }

        .dlf-card-status-icon {
          width: 20px;
          height: 20px;
          flex-basis: 20px;
          font-size: 12px;
        }


        /* CONCEPTS */

        .dlf-covered {
          margin-top: 6px;
          padding: 7px;
          border-radius: 8px;
        }

        .dlf-covered-title {
          font-size: 7.5px;
        }

        .dlf-concepts {
          gap: 4px;
          margin-top: 5px;
        }

        .dlf-concept-chip {
          padding: 4px 6px;
          border-radius: 6px;
          font-size: 9px;
        }


        /* META */

        .dlf-meta {
          grid-template-columns: repeat(2, minmax(0, 1fr));
          gap: 4px;
          margin-top: 6px;
        }

        .dlf-meta-item {
          padding: 6px 7px;
          border-radius: 7px;
        }

        .dlf-meta-item-wide {
          grid-column: span 2;
        }

        .dlf-meta-value {
          font-size: 9px;
          line-height: 1.22;
        }

        .dlf-meta-item .dlf-label {
          margin-bottom: 2px;
          font-size: 7px;
          letter-spacing: .5px;
        }


        /* FEEDBACK */

        .dlf-feedback-panel {
          margin-top: 6px;
          padding: 6px 0 0;
          border-top: 1px solid #e5ebf3;
        }

        .dlf-feedback-empty {
          padding: 8px;
          border-radius: 8px;
        }

        .dlf-feedback-empty-label {
          font-size: 7.5px;
        }

        .dlf-feedback-empty-title {
          font-size: 11px;
        }

        .dlf-feedback-empty-copy {
          font-size: 9px;
        }

        .dlf-feedback-button {
          width: 100%;
          min-height: 32px;
          margin-top: 6px;
          font-size: 9px;
        }

        .dlf-submitted {
          gap: 4px;
        }

        .dlf-submitted-head {
          padding: 6px 7px;
          border-radius: 7px;
        }

        .dlf-submitted-head span:first-child {
          font-size: 8.5px;
        }

        .dlf-submitted-head span:last-child {
          font-size: 7.5px;
        }

        .dlf-feedback-info {
          padding: 6px 7px;
          border-radius: 7px;
        }

        .dlf-feedback-info-title {
          margin-bottom: 3px;
          font-size: 7px;
        }

        .dlf-feedback-info-value {
          font-size: 9px;
          line-height: 1.25;
        }

        .dlf-difficult-list {
          gap: 3px;
        }

        .dlf-difficult-chip {
          padding: 3px 5px;
          border-radius: 6px;
          font-size: 8.5px;
        }


        /* FORM */

        .dlf-form {
          margin: 0 12px 12px 15px;
          padding: 12px;
          border-radius: 11px;
        }

        .dlf-form-head {
          gap: 8px;
          padding-bottom: 9px;
        }

        .dlf-form-icon {
          width: 32px;
          height: 32px;
          flex-basis: 32px;
          font-size: 14px;
        }

        .dlf-form-eyebrow {
          font-size: 9px;
        }

        .dlf-form-title {
          font-size: 13px;
        }

        .dlf-option-grid {
          grid-template-columns: 1fr;
          gap: 6px;
          margin-top: 9px;
        }

        .dlf-form-choice {
          min-height: 38px;
          padding: 8px 9px;
          font-size: 12px;
        }

        .dlf-form-section {
          margin-top: 11px;
          padding-top: 10px;
        }

        .dlf-form-label {
          font-size: 12px;
        }

        .dlf-textarea {
          min-height: 58px;
          margin-top: 7px;
          padding: 9px;
          font-size: 12px;
        }

        .dlf-form-actions {
          gap: 6px;
          margin-top: 11px;
        }

        .dlf-cancel-button,
        .dlf-submit-button {
          min-height: 37px;
          padding: 0 11px;
          font-size: 10px;
        }

        .dlf-submit-button {
          flex: 1;
        }


        /* EMPTY */

        .dlf-empty {
          margin-top: 13px;
          padding: 22px 13px;
          border-radius: 12px;
        }

        .dlf-empty h2 {
          font-size: 16px;
        }

        .dlf-empty p {
          font-size: 12px;
        }
      }


      /* =========================================================
         VERY SMALL MOBILE
      ========================================================= */

      @media (max-width: 420px) {

        .dlf-section-head {
          flex-direction: column;
        }

        .dlf-ledger .dlf-section-head {
          flex-direction: row;
        }

        .dlf-gap-meta-grid {
          grid-template-columns: 1fr;
        }

        .dlf-clear-row {
          align-items: flex-start;
        }

        .dlf-meta {
          grid-template-columns: 1fr 1fr;
        }

        .dlf-meta-item-wide {
          grid-column: span 2;
        }

        .dlf-form-actions {
          align-items: stretch;
        }

        /* Keep status beside the lecture heading,
           but make it compact enough for small phones */

        .dlf-lecture-top {
          align-items: flex-start;
        }

        .dlf-card-status {
          padding-right: 6px;
          font-size: 8px;
        }
      }


      /* =========================================================
         FEEDBACK SUBMISSION STATE
      ========================================================= */

      .dlf-card-status-submitting {
        color: #c2410c;
        background: #fff7ed;
        border-color: #fdba74;
      }

      .dlf-inline-spinner {
        width: 13px;
        height: 13px;
        flex: 0 0 13px;
        display: inline-block;
        border: 2px solid rgba(249, 115, 22, 0.22);
        border-top-color: #f97316;
        border-radius: 50%;
        animation: dlf-spin 0.75s linear infinite;
        vertical-align: -2px;
      }

      .dlf-inline-spinner-light {
        border-color: rgba(255, 255, 255, 0.35);
        border-top-color: #ffffff;
      }

      .dlf-submitting-feedback {
        display: flex;
        align-items: center;
        gap: 8px;
        margin-top: 11px;
        padding: 9px 11px;
        border: 1px solid #fed7aa;
        border-radius: 9px;
        background: #fff7ed;
        color: #c2410c;
        font-size: 11px;
        line-height: 1.3;
        font-weight: 850;
      }

      .dlf-feedback-submit-error {
        margin-top: 11px;
        padding: 9px 11px;
        border: 1px solid #fecaca;
        border-radius: 9px;
        background: #fef2f2;
        color: #b91c1c;
        font-size: 11px;
        line-height: 1.4;
        font-weight: 750;
      }

      .dlf-submit-button:disabled,
      .dlf-cancel-button:disabled,
      .dlf-statement-fetch:disabled,
      .dlf-statement-pdf:disabled {
        opacity: 0.65;
        cursor: not-allowed;
      }

      @keyframes dlf-spin {
        to { transform: rotate(360deg); }
      }

      /* =========================================================
         FEEDBACK STATEMENT
      ========================================================= */

      .dlf-statement-section {
        margin-top: 18px;
        margin-bottom: 18px;
        padding: 22px 24px 24px;
      }

      .dlf-statement-filters {
        display: grid;
        grid-template-columns: minmax(180px, 1.1fr) minmax(150px, .8fr) minmax(150px, .8fr) auto;
        gap: 9px;
        align-items: end;
        margin-top: 17px;
      }

      .dlf-statement-field {
        min-width: 0;
      }

      .dlf-statement-field > span {
        display: block;
        margin-bottom: 5px;
        color: #64748b;
        font-size: 9px;
        line-height: 1.2;
        font-weight: 900;
        letter-spacing: .75px;
        text-transform: uppercase;
      }

      .dlf-statement-control {
        width: 100%;
        min-height: 38px;
        padding: 0 10px;
        border: 1px solid #cbd5e1;
        border-radius: 9px;
        outline: none;
        background: #ffffff;
        color: #334155;
        font: inherit;
        font-size: 12px;
        font-weight: 700;
      }

      .dlf-statement-control:focus {
        border-color: #fb923c;
        box-shadow: 0 0 0 3px rgba(249,115,22,.08);
      }

      .dlf-statement-fetch,
      .dlf-statement-pdf {
        min-height: 38px;
        padding: 0 13px;
        border: 1px solid #ea580c;
        border-radius: 9px;
        background: #f97316;
        color: #ffffff;
        font-size: 10px;
        line-height: 1;
        font-weight: 900;
        letter-spacing: .2px;
        cursor: pointer;
        white-space: nowrap;
      }

      .dlf-statement-pdf {
        border-color: #cbd5e1;
        background: #ffffff;
        color: #c2410c;
      }

      .dlf-statement-error {
        margin-top: 11px;
        padding: 9px 11px;
        border: 1px solid #fecaca;
        border-radius: 9px;
        background: #fef2f2;
        color: #b91c1c;
        font-size: 11px;
        line-height: 1.4;
        font-weight: 750;
      }

      .dlf-statement-result-head {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 10px;
        margin-top: 16px;
        padding: 10px 11px;
        border: 1px solid #e2e8f0;
        border-radius: 10px;
        background: #f8fafc;
      }

      .dlf-statement-result-title {
        color: #0f172a;
        font-size: 12px;
        line-height: 1.2;
        font-weight: 900;
      }

      .dlf-statement-result-copy {
        margin-top: 3px;
        color: #64748b;
        font-size: 9px;
        line-height: 1.35;
        font-weight: 650;
      }

      .dlf-statement-empty {
        margin-top: 12px;
        padding: 20px 12px;
        border: 1px dashed #cbd5e1;
        border-radius: 11px;
        background: #fafcff;
        color: #64748b;
        text-align: center;
        font-size: 11px;
        line-height: 1.45;
        font-weight: 700;
      }

      .dlf-statement-mobile-hint {
        display: none;
        margin-top: 10px;
        padding: 7px 9px;
        border: 1px solid #fed7aa;
        border-radius: 8px;
        background: #fff7ed;
        color: #c2410c;
        font-size: 9px;
        line-height: 1.35;
        font-weight: 800;
        text-align: center;
      }

      .dlf-statement-scroll {
        width: 100%;
        margin-top: 10px;
        overflow-x: visible;
      }

      .dlf-statement-table {
        width: 100%;
        border-collapse: separate;
        border-spacing: 0;
        table-layout: fixed;
        font-size: 10px;
      }

      .dlf-statement-scroll-all-subjects {
        overflow-x: auto;
      }

      .dlf-statement-table-all-subjects {
        min-width: 1080px;
      }

      .dlf-statement-table th,
      .dlf-statement-table td {
        padding: 7px 6px;
        border-right: 1px solid #e2e8f0;
        border-bottom: 1px solid #e2e8f0;
        vertical-align: top;
        text-align: left;
      }

      .dlf-statement-table th:first-child,
      .dlf-statement-table td:first-child {
        border-left: 1px solid #e2e8f0;
      }

      .dlf-statement-table th {
        color: #475569;
        background: #fff7ed;
        font-size: 8px;
        line-height: 1.2;
        font-weight: 900;
        letter-spacing: .25px;
        text-transform: uppercase;
      }

      .dlf-statement-table th:first-child {
        border-top-left-radius: 9px;
      }

      .dlf-statement-table th:last-child {
        border-top-right-radius: 9px;
      }

      .dlf-statement-table td {
        color: #475569;
        background: #ffffff;
        font-size: 9px;
        line-height: 1.35;
        font-weight: 650;
        overflow-wrap: anywhere;
      }

      .dlf-statement-date,
      .dlf-statement-balance {
        white-space: nowrap;
        font-weight: 900 !important;
        color: #334155 !important;
      }

      .dlf-statement-topic {
        color: #0f172a !important;
        font-weight: 850 !important;
      }

      .dlf-statement-subtopics,
      .dlf-statement-difficult {
        display: flex;
        flex-direction: column;
        gap: 3px;
      }

      .dlf-statement-subtopics span,
      .dlf-statement-difficult span {
        display: block;
      }

      .dlf-statement-response {
        display: inline-block;
        padding: 4px 5px;
        border-radius: 6px;
        font-size: 8px;
        line-height: 1.25;
        font-weight: 850;
      }

      .dlf-statement-response-selected {
        color: #166534;
        background: #f0fdf4;
        border: 1px solid #bbf7d0;
      }

      .dlf-statement-response-pending {
        color: #c2410c;
        background: #fff7ed;
        border: 1px solid #fed7aa;
      }

      .dlf-statement-credit-positive {
        color: #15803d !important;
        font-weight: 900 !important;
        white-space: nowrap;
      }

      .dlf-statement-credit-negative {
        color: #dc2626 !important;
        font-weight: 900 !important;
        white-space: nowrap;
      }

      .dlf-statement-credit-neutral {
        color: #c2410c !important;
        font-weight: 900 !important;
        white-space: nowrap;
      }

      .dlf-statement-credit-label {
        display: block;
        margin-top: 2px;
        color: #94a3b8;
        font-size: 7px;
        line-height: 1.2;
        font-weight: 700;
        white-space: normal;
      }

      @media (max-width: 1099px) {
        .dlf-statement-section {
          padding: 15px;
          margin-top: 12px;
          margin-bottom: 12px;
        }

        .dlf-statement-filters {
          grid-template-columns: repeat(2, minmax(0, 1fr));
          gap: 7px;
          margin-top: 11px;
        }

        .dlf-statement-fetch {
          width: 100%;
          grid-column: 1 / -1;
        }

        .dlf-statement-mobile-hint {
          display: block;
        }

        .dlf-statement-scroll {
          overflow-x: auto;
          overflow-y: hidden;
          -webkit-overflow-scrolling: touch;
          overscroll-behavior-x: contain;
          border-radius: 9px;
        }

        .dlf-statement-table {
          min-width: 980px;
          table-layout: fixed;
        }

        .dlf-statement-table th,
        .dlf-statement-table td {
          padding: 6px 5px;
        }

        .dlf-statement-result-head {
          align-items: flex-start;
        }
      }

      @media (max-width: 767px) {
        .dlf-statement-filters {
          grid-template-columns: 1fr;
        }

        .dlf-statement-fetch {
          grid-column: auto;
        }

        .dlf-statement-result-head {
          flex-direction: column;
          align-items: stretch;
        }

        .dlf-statement-pdf {
          width: 100%;
        }

        .dlf-statement-mobile-hint {
          font-size: 8.5px;
        }
      }

    `}</style>


    <div className="dlf-page">

      {loop1FeedbackSuccessPopup && (
        <div
          role="status"
          aria-live="polite"
          aria-atomic="true"
          style={{
            position: "fixed",
            inset: 0,
            zIndex: 10000,
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            padding: "20px 16px",
            background: "rgba(15, 23, 42, 0.18)",
            backdropFilter: "blur(3px)",
          }}
        >
          <div
            style={{
              position: "relative",
              width: "min(92vw, 500px)",
              boxSizing: "border-box",
              padding: "28px 52px 28px 28px",
              borderRadius: 22,
              background: "linear-gradient(145deg, #FFFFFF 0%, #F8FAFC 100%)",
              border: "1px solid rgba(22, 163, 74, 0.28)",
              boxShadow: "0 24px 70px rgba(15, 23, 42, 0.28), 0 8px 24px rgba(15, 23, 42, 0.12)",
              textAlign: "center",
              lineHeight: 1.5,
              color: "#0F172A",
            }}
          >
            <button
              type="button"
              aria-label="Close acknowledgement"
              onClick={closeLoop1FeedbackSuccessPopup}
              style={{
                position: "absolute",
                top: 10,
                right: 10,
                width: 36,
                height: 36,
                border: "none",
                borderRadius: "50%",
                background: "rgba(15, 23, 42, 0.06)",
                color: "#475569",
                fontSize: 25,
                lineHeight: 1,
                cursor: "pointer",
                display: "inline-flex",
                alignItems: "center",
                justifyContent: "center",
              }}
            >
              ×
            </button>

            <div
              aria-hidden="true"
              style={{
                width: 54,
                height: 54,
                margin: "0 auto 14px",
                borderRadius: "50%",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                background: "rgba(22, 163, 74, 0.12)",
                color: "#16A34A",
                fontSize: 30,
                fontWeight: 900,
              }}
            >
              ✓
            </div>

            <div
              style={{
                marginBottom: 8,
                fontSize: 12,
                fontWeight: 800,
                letterSpacing: "0.08em",
                textTransform: "uppercase",
                color: "#16A34A",
              }}
            >
              Feedback submitted
            </div>

            <div
              style={{
                fontSize: "clamp(15px, 3.8vw, 19px)",
                fontWeight: 800,
                color: "#0F172A",
              }}
            >
              Feedback successfully submitted
            </div>
          </div>
        </div>
      )}

      {loop2ResolutionPopup && (
        <div
          role="status"
          aria-live="polite"
          aria-atomic="true"
          style={{
            position: "fixed",
            inset: 0,
            zIndex: 10000,
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            padding: "20px 16px",
            background: "rgba(15, 23, 42, 0.18)",
            backdropFilter: "blur(3px)",
          }}
        >
          <div
            style={{
              position: "relative",
              width: "min(92vw, 500px)",
              boxSizing: "border-box",
              padding: "28px 52px 28px 28px",
              borderRadius: 22,
              background: "linear-gradient(145deg, #FFFFFF 0%, #F8FAFC 100%)",
              border: `1px solid ${loop2ResolutionPopup.kind === "DISCUSSED" ? "rgba(22, 163, 74, 0.28)" : "rgba(220, 38, 38, 0.24)"}`,
              boxShadow: "0 24px 70px rgba(15, 23, 42, 0.28), 0 8px 24px rgba(15, 23, 42, 0.12)",
              textAlign: "center",
              lineHeight: 1.5,
              color: "#0F172A",
            }}
          >
            <button
              type="button"
              aria-label="Close acknowledgement"
              onClick={closeLoop2ResolutionPopup}
              style={{
                position: "absolute",
                top: 10,
                right: 10,
                width: 36,
                height: 36,
                border: "none",
                borderRadius: "50%",
                background: "rgba(15, 23, 42, 0.06)",
                color: "#475569",
                fontSize: 25,
                lineHeight: 1,
                cursor: "pointer",
                display: "inline-flex",
                alignItems: "center",
                justifyContent: "center",
              }}
            >
              ×
            </button>

            <div
              aria-hidden="true"
              style={{
                width: 54,
                height: 54,
                margin: "0 auto 14px",
                borderRadius: "50%",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                background: loop2ResolutionPopup.kind === "DISCUSSED" ? "rgba(22, 163, 74, 0.12)" : "rgba(220, 38, 38, 0.10)",
                color: loop2ResolutionPopup.kind === "DISCUSSED" ? "#16A34A" : "#DC2626",
                fontSize: 30,
                fontWeight: 900,
              }}
            >
              {loop2ResolutionPopup.kind === "DISCUSSED" ? "✓" : "!"}
            </div>

            <div
              style={{
                marginBottom: 8,
                fontSize: 12,
                fontWeight: 800,
                letterSpacing: "0.08em",
                textTransform: "uppercase",
                color: loop2ResolutionPopup.kind === "DISCUSSED" ? "#16A34A" : "#DC2626",
              }}
            >
              {loop2ResolutionPopup.kind === "DISCUSSED" ? "Doubt resolved" : "Progress update"}
            </div>

            <div
              style={{
                fontSize: "clamp(15px, 3.8vw, 19px)",
                fontWeight: 800,
                color: "#0F172A",
              }}
            >
              {loop2ResolutionPopup.text}
            </div>
          </div>
        </div>
      )}

      {/* =====================================================
          DAY BEFORE YESTERDAY'S DOUBT FEEDBACK
      ===================================================== */}

      {pendingDoubts.length > 0 ? (

        <section className="dlf-surface dlf-gap-section">

          <div className="dlf-section-head">

            <div>

              <div className="dlf-eyebrow"></div>

              <h2 className="dlf-title">
                Last Lecture's Doubt Feedback
              </h2>

              <p className="dlf-copy">
                Confirm whether your teacher revisited concepts
                that were difficult in an earlier lecture.
              </p>

            </div>


            <div className="dlf-status-pill dlf-status-orange">
              {pendingDoubts.length} Pending
            </div>

          </div>


          {feedbackSubmitError && (
            <p role="alert" style={{ margin: "10px 0 0", color: "#b91c1c", fontWeight: 700 }}>
              {feedbackSubmitError}
            </p>
          )}

          <div className="dlf-gap-grid">

            {pendingDoubts.map((doubt: any) => {
              const originalLog = historicalLectureLogs.find(
                (item: any) => String(item.id) === String(doubt.daily_log_uuid)
              );
              // Only the original Daily Log's date is authoritative here.
              // Do not substitute the pending-doubt creation date.
              const originalDate = originalLog?.log_date;
              const originalSubtopics = Array.isArray(originalLog?.concepts_covered)
                ? originalLog.concepts_covered.filter(Boolean)
                : [];
              const questionOpen = loop2QuestionDoubtId === String(doubt.id);
              const anotherQuestionActive =
                loop2QuestionDoubtId !== null && !questionOpen;
              return (

              <div
                key={doubt.id}
                id={`dlf-pending-doubt-${doubt.id}`}
                className={`dlf-gap-card${guidedDoubtHighlightId === doubt.id ? " dlf-gap-card-guided" : ""}`}
              >

                <div className="dlf-gap-meta-grid">

                  <div className="dlf-gap-meta">

                    <span className="dlf-label">
                      Subject
                    </span>

                    <div className="dlf-value">
                      {doubt.subject_name}
                    </div>

                  </div>


                  <div className="dlf-gap-meta">

                    <span className="dlf-label">
                      Teacher
                    </span>

                    <div className="dlf-value">
                      {originalLog?.teacher_name || doubt.teacher_name || "Teacher name unavailable"}
                    </div>

                  </div>


                  <div className="dlf-gap-meta">
                    <span className="dlf-label">Original Lecture Date</span>
                    <div className="dlf-value">
                      {originalDate ? formatStatementDate(toDateKey(originalDate)) : "Date unavailable"}
                    </div>
                  </div>

                  <div className="dlf-gap-meta">
                    <span className="dlf-label">Previous Topic</span>
                    <div className="dlf-value">
                      {originalLog?.topic_name || doubt.previous_topic_name || "Topic unavailable"}
                    </div>
                    {originalSubtopics.length > 0 && (
                      <div className="dlf-value" style={{ marginTop: 7, fontWeight: 600 }}>
                        <span className="dlf-label">Subtopics taught</span>
                        {originalSubtopics.join(" · ")}
                      </div>
                    )}
                  </div>


                  <div className="dlf-gap-meta">

                    <span className="dlf-label">
                      Difficult Concept
                    </span>

                    <div className="dlf-value dlf-value-orange">
                      {doubt.previous_difficult_concept}
                    </div>

                  </div>

                </div>


                <p className="dlf-gap-question">
                  You previously marked this concept as difficult.
                  Was it discussed again today?
                </p>


                {questionOpen &&
                  getLoop2MultiQuestionsForDoubt(String(doubt.id)).length >= 2 && (
                    <Loop2MultiCrossQuestionFlow
                      doubtId={String(doubt.id)}
                      questions={getLoop2MultiQuestionsForDoubt(String(doubt.id))}
                      attempts={getLoop2MultiAttemptsForDoubt(String(doubt.id))}
                      disabled={
                        loop2MultiLoadingDoubtId === String(doubt.id)
                      }
                      onAttempt={(question, selectedValue) =>
                        recordLoop2MultiAttempt(doubt, question, selectedValue)
                      }
                      onBeforeFirstAttemptCancel={() =>
                        closeLoop2MultiBeforeFirstAttempt(doubt)
                      }
                      onTerminalWrong={() => {
                        void finishLoop2MultiTerminal(doubt, "NOT DISCUSSED");
                      }}
                      onAllCorrect={(_question, _attempt) => {
                        void finishLoop2MultiTerminal(doubt, "DISCUSSED");
                      }}
                      onError={(error) => {
                        console.error("LOOP-2 MULTI CROSS ANSWER FAILED", error);
                        setFeedbackSubmitError(
                          String(
                            (error as any)?.message ??
                              "The Cross Question answer could not be recorded. Please refresh and try again.",
                          ),
                        );
                      }}
                    />
                  )}

                {questionOpen && getLoop2MultiQuestionsForDoubt(String(doubt.id)).length < 2 && originalLog && (
                  <div
                    id={`dlf-loop2-question-${doubt.id}`}
                    className="dlf-gap-meta"
                    style={{ marginTop: 12, border: "2px solid #2563eb", boxShadow: "0 0 0 3px rgba(37,99,235,.12)" }}
                  >
                    <div className="dlf-label">Recheck the original Cross Question</div>
                    {originalLog.cross_question_image_path ? (
                      originalLog.cross_question_image_url ? (
                        <button type="button" onClick={() => setCrossQuestionImageViewerUrl(originalLog.cross_question_image_url)} aria-label="Enlarge original cross-question image" style={{ display: "block", maxWidth: "100%", margin: "8px auto", padding: 0, border: 0, background: "transparent", cursor: "zoom-in" }}>
                          <img
                            src={originalLog.cross_question_image_url}
                            alt="Original Cross Question"
                            onError={() => {
                              setLoop2QuestionImageFailedIds((previous) => ({ ...previous, [doubt.id]: true }));
                              setLoop2QuestionImageLoadedIds((previous) => ({ ...previous, [doubt.id]: false }));
                            }}
                            onLoad={() => {
                              setLoop2QuestionImageFailedIds((previous) => ({ ...previous, [doubt.id]: false }));
                              setLoop2QuestionImageLoadedIds((previous) => ({ ...previous, [doubt.id]: true }));
                            }}
                            style={{ display: "block", maxWidth: "100%", maxHeight: 260, objectFit: "contain" }}
                          />
                        </button>
                      ) : <div role="alert">Question image unavailable. Your doubt has not been resolved.</div>
                    ) : <div style={{ whiteSpace: "pre-wrap", margin: "8px 0", fontWeight: 700 }}>{originalLog.cross_question_text}</div>}
                    {originalLog.cross_question_image_path && loop2QuestionImageFailedIds[doubt.id] && (
                      <p role="alert" style={{ color: "#b91c1c", fontWeight: 700 }}>
                        The question image has not loaded successfully. Your answer cannot be submitted until the image is visible.
                      </p>
                    )}
                    {originalLog.cross_question_image_path && originalLog.cross_question_image_url && !loop2QuestionImageFailedIds[doubt.id] && !loop2QuestionImageLoadedIds[doubt.id] && (
                      <p role="status" style={{ color: "#475569", fontWeight: 600 }}>
                        Loading the original question image… Answer options will be enabled when it is visible.
                      </p>
                    )}
                    {(originalLog.cross_question_options ?? []).map((option: string, index: number) => (
                      <label key={`${doubt.id}-loop2-option-${index}`} className="dlf-choice" style={{ marginTop: 7, cursor: loop2QuestionBusyId === doubt.id ? "wait" : "pointer" }}>
                        <input
                          type="radio"
                          name={`loop2-question-${doubt.id}`}
                          disabled={pendingDoubtAutoSubmitLockRef.current.size > 0 || loop2QuestionBusyId === doubt.id || Boolean(originalLog.cross_question_image_path && (!originalLog.cross_question_image_url || loop2QuestionImageFailedIds[doubt.id] || !loop2QuestionImageLoadedIds[doubt.id]))}
                          checked={loop2QuestionAnswers[doubt.id] === index}
                          onChange={() => setLoop2QuestionAnswers((previous) => ({ ...previous, [doubt.id]: index }))}
                        />
                        <span>{String.fromCharCode(65 + index)}. {option}</span>
                      </label>
                    ))}
                    <button
                      type="button"
                      className="dlf-submit-gap"
                      disabled={pendingDoubtAutoSubmitLockRef.current.size > 0 || loop2QuestionBusyId === doubt.id || Boolean(originalLog.cross_question_image_path && (!originalLog.cross_question_image_url || loop2QuestionImageFailedIds[doubt.id] || !loop2QuestionImageLoadedIds[doubt.id]))}
                      onClick={() => void submitLoop2CrossQuestion(doubt)}
                      style={{ opacity: pendingDoubtAutoSubmitLockRef.current.size > 0 || loop2QuestionBusyId === doubt.id || Boolean(originalLog.cross_question_image_path && (!originalLog.cross_question_image_url || loop2QuestionImageFailedIds[doubt.id] || !loop2QuestionImageLoadedIds[doubt.id])) ? 0.65 : 1 }}
                    >
                      {loop2QuestionBusyId === doubt.id ? "CHECKING ANSWER…" : "SUBMIT ANSWER"}
                    </button>
                    {loop2QuestionMessage?.doubtId === doubt.id && (
                      <p role="status" style={{ margin: "10px 0 0", fontWeight: 800, color: loop2QuestionMessage.correct ? "#166534" : "#b91c1c" }}>
                        {loop2QuestionMessage.text}
                      </p>
                    )}
                  </div>
                )}

                {!questionOpen && <div className="dlf-response-options">

                  <label className="dlf-choice">

                    <input
                      type="radio"
                      name={doubt.id}
                      disabled={anotherQuestionActive || pendingDoubtAutoSubmittingId !== null || pendingDoubtAutoSubmitLockRef.current.size > 0}
                      checked={
                        selectedResponse[doubt.id] ===
                        "DISCUSSED"
                      }
                      onChange={() => {
                        if (anotherQuestionActive || pendingDoubtAutoSubmitLockRef.current.size > 0) return;
                        setSelectedResponse((previous) => ({
                          ...previous,
                          [doubt.id]: "DISCUSSED",
                        }));
                        // The requested guided flow starts immediately on Yes;
                        // no extra SUBMIT RESPONSE click is required.
                        void handlePendingDoubtDiscussed(doubt);
                      }}
                    />

                    <span>
                      Yes, discussed today
                    </span>

                  </label>


                  <label className="dlf-choice">

                    <input
                      type="radio"
                      name={doubt.id}
                      disabled={anotherQuestionActive || pendingDoubtAutoSubmittingId !== null || pendingDoubtAutoSubmitLockRef.current.size > 0}
                      checked={
                        selectedResponse[doubt.id] ===
                        "NOT DISCUSSED"
                      }
                      onChange={() => {
                        if (anotherQuestionActive || pendingDoubtAutoSubmitLockRef.current.size > 0) return;
                        setFeedbackSubmitError(null);
                        setSelectedResponse(
                          (previous) => ({
                            ...previous,
                            [doubt.id]: "NOT DISCUSSED",
                          })
                        );
                      }}
                    />

                    <span>
                      Not discussed yet
                    </span>

                  </label>

                </div>}

                {!questionOpen && (
                  <button
                    type="button"
                    disabled={anotherQuestionActive || pendingDoubtAutoSubmittingId !== null || pendingDoubtAutoSubmitLockRef.current.size > 0}
                    onClick={() => { void submitPendingDoubt(doubt); }}
                    className="dlf-submit-gap"
                    style={anotherQuestionActive || pendingDoubtAutoSubmittingId !== null || pendingDoubtAutoSubmitLockRef.current.size > 0 ? { opacity: 0.65, cursor: "wait" } : undefined}
                  >
                    {pendingDoubtAutoSubmittingId === String(doubt.id) ? "SAVING RESPONSE…" : "SUBMIT RESPONSE"}
                  </button>
                )}

              </div>

            ); })}

          </div>

        </section>

      ) : (

        <section className="dlf-surface dlf-clear-card">

          <div className="dlf-clear-row">

            <div className="dlf-clear-icon">
              ✓
            </div>


            <div>

              <div className="dlf-clear-eyebrow">
                LEARNING GAP STATUS
              </div>

              <h2 className="dlf-clear-title">
                No Pending Learning Gaps
              </h2>

              <p className="dlf-clear-copy">
                All previously identified difficult concepts have
                either been revised by your teacher or already
                resolved.
              </p>

            </div>

          </div>

        </section>

      )}


      {/* =====================================================
          DAILY FEEDBACK CREDIT LEDGER
      ===================================================== */}

      <section id="dlf-credit-section" className="dlf-surface dlf-credit-section">
        <div className="dlf-section-head">
          <div>
            <div className="dlf-eyebrow">DAILY FEEDBACK CREDITS</div>
            <h2 className="dlf-title">Academic Feedback Credit Ledger</h2>
            <p className="dlf-copy">
              Earn 1 credit for every submitted Loop 1 or Loop 2 feedback.
              Lose 10 credits for every missed eligible feedback.
            </p>
          </div>
          <div className="dlf-ledger-count">
            {isLoadingCreditSummary ? "CALCULATING" : "LIVE"}
          </div>
        </div>

        <div className="dlf-credit-grid">
          <div className="dlf-credit-card dlf-credit-earned">
            <div className="dlf-credit-card-inner">
              <div className="dlf-credit-label">CREDITS EARNED</div>
              <div className="dlf-credit-value">
                {isLoadingCreditSummary ? "—" : dailyFeedbackEarnedCredits}
              </div>
              <div className="dlf-credit-copy">
                +1 for every submitted Loop 1 or Loop 2 feedback
              </div>
            </div>
          </div>

          <div className="dlf-credit-card dlf-credit-lost">
            <div className="dlf-credit-card-inner">
              <div className="dlf-credit-label">CREDITS LOST</div>
              <div className="dlf-credit-value">
                {isLoadingCreditSummary ? "—" : dailyFeedbackLostCredits}
              </div>
              <div className="dlf-credit-copy">
                -10 for every eligible Loop 1 or Loop 2 feedback that was missed
              </div>
            </div>
          </div>

          <div className="dlf-credit-card dlf-credit-total">
            <div className="dlf-credit-card-inner">
              <div className="dlf-credit-label">TOTAL CREDITS</div>
              <div className="dlf-credit-value">
                {isLoadingCreditSummary ? "—" : dailyFeedbackTotalCredits}
              </div>
              <div className="dlf-credit-copy">
                Earned credits minus lost credits
              </div>
            </div>
          </div>
        </div>

        <div className="dlf-credit-formula">
          Total Credits = Credits Earned − Credits Lost
        </div>
      </section>


      {/* =====================================================
          TODAY'S CLASS FEEDBACK
      ===================================================== */}

      <section className="dlf-surface dlf-ledger">

        <div className="dlf-section-head">

          <div>

            <div className="dlf-eyebrow"></div>

            <h2 className="dlf-title">
              Submit Your Today's Topic Feedback
            </h2>

            <p className="dlf-copy">
              Review today's classroom activity and complete
              your learning feedback for each lecture.
            </p>

          </div>


          <div className="dlf-ledger-count">

            <strong>
              {lectureLogs.length}
            </strong>

            {lectureLogs.length === 1
              ? "Lecture"
              : "Lectures"}

          </div>

        </div>


        {isLoadingLogs ? (

          <div className="dlf-loading">
            <div className="dlf-loading-card">
              <div className="dlf-loading-spinner" />
              <h2 className="dlf-loading-title">Loading your recent topic logs</h2>
              <p className="dlf-loading-copy">
                We are loading your recent classroom topics. Kindly give feedback
                on your understanding level to help your teacher understand your learning progress.
              </p>
            </div>
          </div>

        ) : lectureLogs.length === 0 ? (

          <div className="dlf-empty">

            <div className="dlf-empty-icon">
              ◇
            </div>

            <h2>
              No Daily Lecture Logs Available
            </h2>

            <p>
              Your teachers have not submitted classroom
              lecture logs for today. Once today's classroom
              activities are recorded, they will automatically
              appear here.
            </p>

          </div>

        ) : (

          <div className="dlf-feed">

            {lectureLogs.map((log) => (

              <article
                key={log.id}
                className={`dlf-lecture-card ${
                  submittedFeedback[log.id]
                    ? "dlf-lecture-card-submitted"
                    : "dlf-lecture-card-pending"
                }`}
              >

                <div className="dlf-lecture-row">


                  {/* =========================================
                      LECTURE INFORMATION
                  ========================================= */}

                  <div className="dlf-lecture-main">


                    {/* =======================================
                        NEW:
                        SUBJECT/DATE LEFT
                        STATUS RIGHT
                    ======================================= */}

                    <div className="dlf-lecture-top">

                      <div className="dlf-lecture-heading">

                        <div className="dlf-subject-row">

                          <span className="dlf-subject">
                            {log.subject_name ??
                              "Subject Pending"}
                          </span>

                          <span className="dlf-date">
                            {log.log_date ??
                              "Date Pending"}
                          </span>

                        </div>


                        {log.chapter_name && (
                          <div
                            className="dlf-chapter-name"
                            style={{
                              display: "inline-flex",
                              alignItems: "center",
                              marginTop: 8,
                              padding: "3px 8px",
                              border: "1px solid #BFDBFE",
                              borderRadius: 7,
                              background: "#EFF6FF",
                              color: "#1D4ED8",
                              fontSize: 10,
                              fontWeight: 800,
                              lineHeight: 1.35,
                              maxWidth: "100%",
                              overflowWrap: "anywhere",
                            }}
                          >
                            Chapter: {String(log.chapter_name).replace(/^__TP_MANUAL_CHAPTER__:/, "")}
                          </div>
                        )}
                        <h3 className="dlf-topic">
                          Topic: {log.topic_name ?? "Topic Not Available"}
                        </h3>

                      </div>


                      {/* =====================================
                          NEW CARD STATUS
                      ===================================== */}

                      {isSubmittingFeedbackId === log.id ? (

                        <div className="dlf-card-status dlf-card-status-submitting">
                          <span className="dlf-inline-spinner" />
                          <span>Submitting...</span>
                        </div>

                      ) : submittedFeedback[log.id] ? (

                        <div className="dlf-card-status dlf-card-status-submitted">

                          <span className="dlf-card-status-icon">
                            ✓
                          </span>

                          <span>
                            Submitted
                          </span>

                        </div>

                      ) : (

                        <div className="dlf-card-status dlf-card-status-pending">

                          <span className="dlf-card-status-icon">
                            !
                          </span>

                          <span>
                            Pending
                          </span>

                        </div>

                      )}

                    </div>


                    {/* =====================================
                        CONCEPTS
                    ===================================== */}

                    <div className="dlf-covered">

                      <div className="dlf-covered-title">
                        Concepts Covered Today
                      </div>


                      <div className="dlf-concepts">

                        {(log.concepts_covered ?? [])
                          .length > 0 ? (

                          (log.concepts_covered ?? [])
                            .map(
                              (concept: string) => (

                                <span
                                  key={concept}
                                  className="dlf-concept-chip"
                                >
                                  {concept}
                                </span>

                              )
                            )

                        ) : (

                          <span className="dlf-concept-chip">
                            No concepts recorded
                          </span>

                        )}

                      </div>

                    </div>


                    {/* =====================================
                        LECTURE DETAILS
                    ===================================== */}

                    <div className="dlf-meta">


                      <div className="dlf-meta-item">

                        <span className="dlf-label">
                          Teacher
                        </span>

                        <div className="dlf-meta-value">
                          {log.teacher_name ??
                            "Teacher Name Pending"}
                        </div>

                      </div>


                      <div className="dlf-meta-item">

                        <span className="dlf-label">
                          Book Coverage
                        </span>

                        <div className="dlf-meta-value">
                          Page {log.page_from ?? "-"} –{" "}
                          {log.page_to ?? "-"}
                        </div>

                      </div>


                      <div className="dlf-meta-item">

                        <span className="dlf-label">
                          Homework
                        </span>

                        <div className="dlf-meta-value">
                          {log.homework_given
                            ? "Given"
                            : "Not Given"}
                        </div>

                      </div>


                      <div className="dlf-meta-item">

                        <span className="dlf-label">
                          Feedback
                        </span>

                        <div
                          className="dlf-meta-value"
                          style={{
                            color:
                              submittedFeedback[log.id]
                                ? "#15803D"
                                : "#EA580C",
                          }}
                        >
                          {submittedFeedback[log.id]
                            ? "Submitted"
                            : "Pending"}
                        </div>

                      </div>


                      <div className="dlf-meta-item dlf-meta-item-wide">

                        <span className="dlf-label">
                          Teacher Notes
                        </span>

                        <div className="dlf-meta-value">
                          {log.teacher_notes ??
                            "No notes provided."}
                        </div>

                      </div>


                      <div className="dlf-meta-item dlf-meta-item-wide">

                        <span className="dlf-label">
                          Lecture Date
                        </span>

                        <div className="dlf-meta-value">
                          {log.log_date ?? "Pending"}
                        </div>

                      </div>

                    </div>

                  </div>


                  {/* =========================================
                      STUDENT FEEDBACK
                  ========================================= */}

                  <div className="dlf-feedback-panel">


                    {submittedFeedback[log.id] ? (

                      <div className="dlf-submitted">


                        <div className="dlf-submitted-head">

                          <span>
                            ✓ Feedback Submitted
                          </span>

                          <span>
                            Recorded
                          </span>

                        </div>


                        {(log.cross_question_text || log.cross_question_image_path) && (
                          <div className="dlf-feedback-info">
                            <div className="dlf-feedback-info-title">Cross Question</div>
                            {log.cross_question_image_path
                              ? (log.cross_question_image_url ? <button type="button" onClick={() => setCrossQuestionImageViewerUrl(log.cross_question_image_url)} aria-label="Enlarge cross-question image" style={{ display: "block", maxWidth: "100%", margin: 0, padding: 0, border: 0, background: "transparent", cursor: "zoom-in" }}><img src={log.cross_question_image_url} alt="Cross question (select to enlarge)" style={{ display: "block", maxWidth: "100%", maxHeight: 260, objectFit: "contain" }} /></button> : <div>Question image unavailable.</div>)
                              : <div className="dlf-feedback-info-value">{log.cross_question_text}</div>}
                          </div>
                        )}
                        {submittedFeedback[log.id]?.cross_question_selected_index != null && (
                          <div className="dlf-feedback-info">
                            <div className="dlf-feedback-info-title">Cross Question Result</div>
                            <div className="dlf-feedback-info-value">
                              Option {String.fromCharCode(65 + Number(submittedFeedback[log.id].cross_question_selected_index))} · {submittedFeedback[log.id].cross_question_is_correct ? "Correct" : "Incorrect"}
                            </div>
                          </div>
                        )}

                        <div className="dlf-feedback-info">

                          <div className="dlf-feedback-info-title">
                            Understanding Level
                          </div>

                          <div className="dlf-feedback-info-value">
                            {
                              submittedFeedback[log.id]
                                ?.understanding_level
                            }
                          </div>

                        </div>


                        {submittedFeedback[log.id]
                          ?.concepts_not_understood
                          ?.length > 0 && (

                          <div className="dlf-feedback-info dlf-feedback-info-red">

                            <div className="dlf-feedback-info-title">
                              Difficult Concepts
                            </div>


                            <div className="dlf-difficult-list">

                              {submittedFeedback[log.id]
                                ?.concepts_not_understood
                                ?.map(
                                  (concept: string) => (

                                    <span
                                      key={concept}
                                      className="dlf-difficult-chip"
                                    >
                                      {concept}
                                    </span>

                                  )
                                )}

                            </div>

                          </div>

                        )}


                        {submittedFeedback[log.id]
                          ?.additional_note && (

                          <div className="dlf-feedback-info dlf-feedback-info-orange">

                            <div className="dlf-feedback-info-title">
                              Additional Note
                            </div>

                            <div className="dlf-feedback-info-value">
                              {
                                submittedFeedback[log.id]
                                  ?.additional_note
                              }
                            </div>

                          </div>

                        )}

                      </div>

                    ) : (

                      <div className="dlf-feedback-empty">

                        <div className="dlf-feedback-empty-label">
                          Student Check-In
                        </div>

                        <div className="dlf-feedback-empty-title">
                          How well did you understand this lecture?
                        </div>

                        <div className="dlf-feedback-empty-copy">
                          Record your understanding and identify
                          concepts that need more attention.
                        </div>


                        <button
                          onClick={async () => {
                            // The daily-feedback launcher is idempotent while a feedback
                            // flow is already open. A repeated click must never reset the
                            // current step back to the understanding choices.
                            if (expandedCard === log.id) return;
                            if (loop1VerificationLogId === log.id && loop1VerificationStage !== "idle") return;

                            // Before switching away from an open feedback card, wait for
                            // its newest server-draft write to finish. The event-boundary
                            // snapshot is already in localStorage synchronously; this
                            // awaited flush closes the remaining immediate-leave window
                            // for in-app navigation and prevents the old card from being
                            // unmounted while its authoritative server draft is still
                            // unresolved.
                            if (expandedCard && expandedCard !== log.id) {
                              // V76: claim the old card's closing boundary BEFORE
                              // awaiting the server flush. Any late effect/event
                              // from the old card is now forbidden from writing
                              // transient reset state over the durable draft.
                              loop1FeedbackDraftClosingLogIdRef.current = expandedCard;
                              const draftFlushed = await flushLoop1FeedbackDraft(expandedCard);
                              if (!draftFlushed) {
                                loop1FeedbackDraftClosingLogIdRef.current = null;
                                setFeedbackSubmitError(
                                  "Your unfinished feedback could not be saved to the server yet. Please keep this page open and try again."
                                );
                                return;
                              }
                              loop1FeedbackDraftUserTouchedLogIdsRef.current.delete(expandedCard);
                            }
                            loop1FeedbackDraftUserTouchedLogIdsRef.current.delete(log.id);
                            openLoop1FeedbackCard(log.id);

                            // First guided step: after opening the feedback form,
                            // take the student directly to the understanding choices.
                            setGuidedScrollTarget({ logId: log.id, section: "understanding" });

                          }}
                          className="dlf-feedback-button"
                        >
                          SUBMIT DAILY FEEDBACK
                        </button>

                      </div>

                    )}

                  </div>

                </div>


                {/* =============================================
                    FEEDBACK FORM
                ============================================= */}

                {expandedCard === log.id && (

                  <div
                    className="dlf-form"
                    onChangeCapture={(event) => {
                      loop1FeedbackDraftUserTouchedLogIdsRef.current.add(log.id);
                      const target = event.target as HTMLInputElement | HTMLTextAreaElement | null;
                      if (!target) return;

                      if (target instanceof HTMLInputElement && target.type === "radio") {
                        const isCorrectedSecondSelection =
                          loop1VerificationLogId === log.id &&
                          loop1VerificationStage === "corrected";
                        persistLoop1FeedbackDraftSnapshot(log.id, {
                          understandingLevel: target.value,
                          verificationSecondSelection: isCorrectedSecondSelection ? target.value : loop1VerificationSecondSelection,
                        });
                        return;
                      }

                      if (target instanceof HTMLInputElement && target.type === "checkbox") {
                        const labelText = target.parentElement?.textContent?.trim() ?? "";
                        if (labelText === "Something Else") {
                          persistLoop1FeedbackDraftSnapshot(log.id, {
                            somethingElse: target.checked,
                            somethingElseText: target.checked ? somethingElseText : "",
                          });
                          return;
                        }
                        const concept = labelText;
                        if (concept) {
                          const nextConcepts = target.checked
                            ? Array.from(new Set([...conceptsNotUnderstood, concept]))
                            : conceptsNotUnderstood.filter((item) => item !== concept);
                          persistLoop1FeedbackDraftSnapshot(log.id, { conceptsNotUnderstood: nextConcepts });
                        }
                        return;
                      }

                      if (target instanceof HTMLTextAreaElement) {
                        const isSomethingElseText = target.placeholder === "Describe the concept or learning gap...";
                        persistLoop1FeedbackDraftSnapshot(log.id, isSomethingElseText
                          ? { somethingElseText: target.value }
                          : { additionalNote: target.value });
                      }
                    }}
                    onInputCapture={(event) => {
                      loop1FeedbackDraftUserTouchedLogIdsRef.current.add(log.id);
                      const target = event.target as HTMLTextAreaElement | null;
                      if (!target || target.tagName !== "TEXTAREA") return;
                      const isSomethingElseText = target.placeholder === "Describe the concept or learning gap...";
                      persistLoop1FeedbackDraftSnapshot(log.id, isSomethingElseText
                        ? { somethingElseText: target.value }
                        : { additionalNote: target.value });
                    }}
                  >


                    <div className="dlf-form-head">

                      <div className="dlf-form-icon">
                        ✓
                      </div>


                      <div>

                        <div className="dlf-form-eyebrow">
                          DAILY LEARNING CHECK-IN
                        </div>

                        <div className="dlf-form-title">
                          How well did you understand today's class?
                        </div>

                      </div>

                    </div>


                    {/* UNDERSTANDING OPTIONS */}

                    {log.id in crossQuestionAnswers &&
                      crossQuestionResults[log.id] === false &&
                      !submittedFeedback[log.id] && (
                        <div
                          role="status"
                          style={{
                            margin: "10px 0",
                            padding: 12,
                            borderRadius: 10,
                            background: "#EFF6FF",
                            color: "#1D4ED8",
                            border: "1px solid #BFDBFE",
                          }}
                        >
                          That answer is incorrect. choose your understanding again.
                        </div>
                      )}

                    {!(
                      loop1VerificationLogId === log.id &&
                      loop1VerificationStage === "wrong" &&
                      !multiWrongStartedFromCompleteRef.current.has(log.id)
                    ) && (
                    <div
                      id={`dlf-understanding-${log.id}`}
                      className="dlf-option-grid"
                      onChangeCapture={(event) => handleLoop1UnderstandingCapture(log, event)}
                    >

                      {(loop1VerificationLogId === log.id && loop1VerificationStage === "corrected"
                        ? UNDERSTANDING_OPTIONS.filter((option) => option !== ABSENT_FEEDBACK_OPTION)
                        : UNDERSTANDING_OPTIONS
                      ).map(
                        (option) => (

                          <label
                            key={option}
                            className="dlf-form-choice"
                          >

                            <input
                              type="radio"
                              name={`understanding-${log.id}`}
                              value={option}
                              disabled={
                                loop1VerificationNoLockLogIdRef.current === log.id ||
                                (loop1VerificationLogId === log.id && loop1VerificationStage === "no") ||
                                (
                                  hasMultiQuestions(log.id) &&
                                  isMultiFirstQuestionAnsweredCorrectly(log.id) &&
                                  loop1VerificationStage !== "wrong" &&
                                  loop1VerificationStage !== "corrected"
                                ) ||
                                (
                                  !(loop1VerificationLogId === log.id && loop1VerificationStage === "corrected") &&
                                  (option === "I completely understood." || option === ABSENT_FEEDBACK_OPTION) &&
                                  (
                                    (log.id in crossQuestionAnswers && crossQuestionResults[log.id] === false) ||
                                    (hasMultiQuestions(log.id) &&
                                      loop1VerificationLogId === log.id &&
                                      loop1VerificationStage === "wrong")
                                  )
                                )
                              }
                              checked={
                                loop1VerificationLogId === log.id && loop1VerificationStage === "corrected"
                                  ? loop1VerificationSecondSelection === option
                                  : getEffectiveLoop1UnderstandingLevel(log.id) === option
                              }
                              onChange={() => {
                                // After verification YES, the second understanding selection is
                                // authoritative. Never let the original radio handler reopen the
                                // Cross Question or override the top-up state machine.
                                if (loop1VerificationLogId === log.id && loop1VerificationStage === "corrected") return;
                                // During the same event that activates the top-up question,
                                // the legacy radio handler must not overwrite the question
                                // guided-scroll target with its normal Partial/Didn't concepts
                                // target. The synchronous activation ref closes that race.
                                if (
                                  loop1VerificationActivationLogIdRef.current === log.id &&
                                  (option === "I partially understood." || option === "I didn't understand.")
                                ) {
                                  loop1VerificationActivationLogIdRef.current = null;
                                  return;
                                }
                                if (option === "I completely understood." && log.id in crossQuestionAnswers && crossQuestionResults[log.id] === false) return;
                                if (
                                  hasMultiQuestions(log.id) &&
                                  isMultiFirstQuestionAnsweredCorrectly(log.id) &&
                                  loop1VerificationStage !== "wrong" &&
                                  loop1VerificationStage !== "corrected"
                                ) return;
                                setLoop1UnderstandingLevelForLog(log.id, option);

                                if (option === "I completely understood.") {
                                  setGuidedScrollTarget({ logId: log.id, section: "question" });
                                } else if (
                                  option === "I partially understood." ||
                                  option === "I didn't understand."
                                ) {
                                  setGuidedScrollTarget({ logId: log.id, section: "concepts" });
                                }

                                if (option === ABSENT_FEEDBACK_OPTION) {
                                  setConceptsNotUnderstood([]);
                                  setSomethingElse(false);
                                  setSomethingElseText("");
                                  setAdditionalNote("");
                                }
                              }}
                            />

                            <span>
                              {option}
                            </span>

                          </label>

                        )
                      )}

                    </div>
                    )}


                    {loop1VerificationLogId === log.id && loop1VerificationStage === "question" && (
                      hasMultiQuestions(log.id) ? (
                        <MultiCrossQuestionFlow
                          logId={log.id}
                          questions={getMultiQuestionsForLog(log.id)}
                          attempts={getMultiAttemptsForLog(log.id)}
                          disabled={isSubmittingFeedbackId === log.id}
                          onAttempt={(question, selectedValue) => recordMultiCrossQuestionAttempt(log, question, selectedValue)}
                          onAllCorrect={(question, attempt) => handleMultiVerificationAllCorrect(log, attempt)}
                          onWrong={() => handleMultiWrong(log)}
                          wrongMessage={
                            getEffectiveLoop1UnderstandingLevel(log.id) === "I completely understood."
                              ? "That answer is incorrect. choose your understanding again."
                              : "That answer is incorrect. Please select the difficult concepts."
                          }
                          onError={(error) => {
                            const message = String((error as any)?.message ?? "The Cross Question answer could not be recorded. Please refresh and try again.");
                            setFeedbackSubmitError(message);
                          }}
                          onScrollNext={(question) => {
                            window.requestAnimationFrame(() => {
                              document.getElementById(`dlf-multi-question-${log.id}-${question.id}`)?.scrollIntoView({ behavior: "smooth", block: "center" });
                            });
                          }}
                        />
                      ) : (
                        <Loop1FeedbackVerificationQuestion
                          log={log}
                          disabled={loop1VerificationAnswerLockRef.current.has(log.id)}
                          onAnswer={(selected) => handleLoop1VerificationAnswer(log, selected)}
                          onImageClick={setCrossQuestionImageViewerUrl}
                        />
                      )
                    )}

                    {!(loop1VerificationLogId === log.id && loop1VerificationStage === "corrected") && (
                      <>
                    {(() => {
                      const multiQuestions = getMultiQuestionsForLog(log.id);
                      if (multiQuestions.length >= 2) {
                        const attempts = getMultiAttemptsForLog(log.id);
                        const hasStarted = Object.keys(attempts).length > 0;
                        const effectiveUnderstandingLevel = getEffectiveLoop1UnderstandingLevel(log.id);
                        const shouldShow =
                          !(loop1VerificationLogId === log.id && (loop1VerificationStage === "corrected" || loop1VerificationStage === "no" || loop1VerificationStage === "question")) &&
                          (effectiveUnderstandingLevel === "I completely understood." || hasStarted);
                        if (!shouldShow) return null;
                        return (
                          <MultiCrossQuestionFlow
                            logId={log.id}
                            questions={multiQuestions}
                            attempts={attempts}
                            disabled={isSubmittingFeedbackId === log.id || loop1VerificationStage === "wrong"}
                            onAttempt={(question, selectedValue) => recordMultiCrossQuestionAttempt(log, question, selectedValue)}
                            onAllCorrect={(question, attempt) => handleMultiAllCorrect(log, attempt)}
                            onWrong={() => handleMultiWrong(log)}
                            wrongMessage={
                              effectiveUnderstandingLevel === "I completely understood."
                                ? "That answer is incorrect. choose your understanding again."
                                : "That answer is incorrect. Please select the difficult concepts."
                            }
                            onError={(error) => {
                              const message = String((error as any)?.message ?? "The Cross Question answer could not be recorded. Please refresh and try again.");
                              setFeedbackSubmitError(message);
                            }}
                            onScrollNext={(question) => {
                              window.requestAnimationFrame(() => {
                                document.getElementById(`dlf-multi-question-${log.id}-${question.id}`)?.scrollIntoView({ behavior: "smooth", block: "center" });
                              });
                            }}
                          />
                        );
                      }
                      if (!((understandingLevel === "I completely understood." || (log.id in crossQuestionAnswers && !submittedFeedback[log.id])) && Array.isArray(log.cross_question_options) && log.cross_question_options.length === 4 && (log.cross_question_text || log.cross_question_image_path))) return null;
                      return (
                        <div id={`dlf-question-${log.id}`} className="dlf-form-section" style={{ marginTop: 16, padding: 14, border: "1px solid #CBD5E1", borderRadius: 12 }}>
                          <div className="dlf-form-label">Cross Question{log.chapter_name ? ` · ${String(log.chapter_name).replace(/^__TP_MANUAL_CHAPTER__:/, "")}` : ""}</div>
                          {log.cross_question_image_path ? (
                            log.cross_question_image_url ? <button type="button" onClick={() => setCrossQuestionImageViewerUrl(log.cross_question_image_url)} aria-label="Enlarge cross-question image" style={{ display: "block", maxWidth: "100%", margin: "10px auto", padding: 0, border: 0, background: "transparent", cursor: "zoom-in" }}><img src={log.cross_question_image_url} alt="Cross question (select to enlarge)" style={{ display: "block", maxWidth: "100%", maxHeight: 320, objectFit: "contain" }} /></button> : <div>Question image is unavailable. Please contact your teacher.</div>
                          ) : <div style={{ whiteSpace: "pre-wrap", margin: "10px 0", fontWeight: 600 }}>{log.cross_question_text}</div>}
                          {log.cross_question_options.map((option: string, index: number) => (
                            <button key={`${log.id}-cross-${index}`} type="button"
                              disabled={log.id in crossQuestionAnswers || isSubmittingFeedbackId === log.id}
                              onClick={async () => {
                                if (log.id in crossQuestionAnswers) return;
                                const selected = Number(index);
                                const supabase = getSupabaseClient();
                                if (!supabase) { setFeedbackSubmitError("Your session is unavailable. Please sign in again."); return; }
                                try {
                                  const { data, error } = await (supabase as any).rpc("tp_record_daily_cross_question_attempt", { p_daily_log_uuid: log.id, p_selected_index: selected });
                                  if (error) throw error;
                                  const attempt = Array.isArray(data) ? data[0] : data;
                                  const correct = attempt?.is_correct === true;
                                  setCrossQuestionAnswers((previous) => ({ ...previous, [log.id]: selected }));
                                  setCrossQuestionResults((previous) => ({ ...previous, [log.id]: correct }));
                                  if (correct) void submitFeedback(log, "I completely understood.", selected, true);
                                  else { setLoop1UnderstandingLevelForLog(log.id, ""); setGuidedScrollTarget({ logId: log.id, section: "understanding" }); }
                                } catch (error: any) {
                                  console.error("CROSS QUESTION ATTEMPT FAILED", error);
                                  setFeedbackSubmitError(String(error?.message ?? "Your answer could not be recorded. Refresh the page to check whether it was already attempted."));
                                }
                              }}
                              style={{ display: "block", width: "100%", textAlign: "left", padding: "11px 12px", marginTop: 8, borderRadius: 9, border: "1px solid #CBD5E1", background: (log.id in crossQuestionAnswers && crossQuestionAnswers[log.id] === index) ? "#FEE2E2" : "#FFFFFF", cursor: log.id in crossQuestionAnswers ? "default" : "pointer" }}>
                              {String.fromCharCode(65 + index)}. {option}
                            </button>
                          ))}
                        </div>
                      );
                    })()}
                      </>
                    )}
                    {log.id in crossQuestionAnswers && crossQuestionResults[log.id] === false && !submittedFeedback[log.id] && (
                      <div role="status" style={{ margin: "10px 0", padding: 12, borderRadius: 10, background: "#FFF7ED", color: "#9A3412" }}>
                        That answer is incorrect. You cannot try again.
                      </div>
                    )}

                    {/* =====================================
                        DIFFICULT CONCEPTS
                    ===================================== */}

                    {loop1VerificationLogId === log.id &&
                      loop1VerificationStage === "wrong" &&
                      !multiWrongStartedFromCompleteRef.current.has(log.id) && (
                        <div
                          role="status"
                          style={{
                            margin: "10px 0",
                            color: "#DC2626",
                            fontSize: 14,
                            fontWeight: 600,
                          }}
                        >
                          wrong answer given, choose your problematic subtopics
                        </div>
                      )}

                    {getEffectiveLoop1UnderstandingLevel(log.id) !== "" &&
                      getEffectiveLoop1UnderstandingLevel(log.id) !==
                        "I completely understood." &&
                      getEffectiveLoop1UnderstandingLevel(log.id) !== ABSENT_FEEDBACK_OPTION &&
                      (
                        loop1VerificationLogId !== log.id ||
                        loop1VerificationStage === "idle" ||
                        loop1VerificationStage === "wrong" ||
                        loop1VerificationStage === "corrected" ||
                        loop1VerificationStage === "no"
                      ) && (

                      <>

                        <div
                          id={`dlf-concepts-${log.id}`}
                          className="dlf-form-section"
                        >

                          <div className="dlf-form-label">
                            Which concepts were difficult today?
                          </div>


                          <div className="dlf-option-grid">

                            {(log.concepts_covered ?? [])
                              .map(
                                (concept: string) => (

                                  <label
                                    key={concept}
                                    className="dlf-form-choice"
                                  >

                                    <input
                                      type="checkbox"
                                      checked={
                                        conceptsNotUnderstood.includes(
                                          concept
                                        )
                                      }
                                      onChange={(event) => {

                                        if (
                                          event.target.checked
                                        ) {

                                          setConceptsNotUnderstood(
                                            [
                                              ...conceptsNotUnderstood,
                                              concept,
                                            ]
                                          );

                                        } else {

                                          setConceptsNotUnderstood(
                                            conceptsNotUnderstood.filter(
                                              (item) =>
                                                item !== concept
                                            )
                                          );

                                        }

                                      }}
                                    />

                                    <span>
                                      {concept}
                                    </span>

                                  </label>

                                )
                              )}


                            <label className="dlf-form-choice">

                              <input
                                type="checkbox"
                                checked={somethingElse}
                                onChange={(event) =>
                                  setSomethingElse(
                                    event.target.checked
                                  )
                                }
                              />

                              <span>
                                Something Else
                              </span>

                            </label>

                          </div>

                        </div>


                        {somethingElse && (

                          <div className="dlf-form-section">

                            <div className="dlf-form-label">
                              What else was difficult?
                            </div>

                            <textarea
                              rows={3}
                              value={somethingElseText}
                              onChange={(e) =>
                                setSomethingElseText(
                                  e.target.value
                                )
                              }
                              className="dlf-textarea"
                              placeholder="Describe the concept or learning gap..."
                            />

                          </div>

                        )}


                        <div className="dlf-form-section">

                          <div className="dlf-form-label">
                            Additional Notes (Optional)
                          </div>

                          <textarea
                            rows={3}
                            value={additionalNote}
                            onChange={(e) =>
                              setAdditionalNote(
                                e.target.value
                              )
                            }
                            className="dlf-textarea"
                            placeholder="Add anything else you want to remember about this lecture..."
                          />

                        </div>

                      </>

                    )}


                    {/* =====================================
                        ACTIONS
                    ===================================== */}

                    {feedbackSubmitError && (
                      <div className="dlf-feedback-submit-error">
                        {feedbackSubmitError}
                      </div>
                    )}

                    {isSubmittingFeedbackId === log.id && (
                      <div className="dlf-submitting-feedback">
                        <span className="dlf-inline-spinner" />
                        <span>Submitting your feedback...</span>
                      </div>
                    )}

                    <div className="dlf-form-actions">

                      <button
                        disabled={isSubmittingFeedbackId === log.id}
                        onClick={async () => {

                          if (isSubmittingFeedbackId === log.id) return;

                          // V71: CANCEL closes the current feedback UI but does NOT
                          // delete the unfinished Loop-1 Multi-Cross draft. The question
                          // attempt ledger and the durable feedback draft are both resume
                          // state. Deleting the draft here was the V70-only failure boundary:
                          // after Q1 wrong/correct or Q2 resume, CANCEL erased the parent
                          // state needed to restore verification/subtopic context on reopen.
                          //
                          // First wait for the newest server draft write to finish. This
                          // preserves V70's server-backed persistence/retry guarantee before
                          // the card is closed. On reopen, openLoop1FeedbackCard() performs
                          // the V70 transient reset and hydration restores this log only.
                          // V76: claim the closing boundary BEFORE flushing.
                          // The flush persists the latest good draft; the guard
                          // then prevents any background/event writer from saving
                          // the transient reset state that follows CANCEL.
                          loop1FeedbackDraftClosingLogIdRef.current = log.id;
                          const draftFlushed = await flushLoop1FeedbackDraft(log.id);
                          if (!draftFlushed) {
                            loop1FeedbackDraftClosingLogIdRef.current = null;
                            setFeedbackSubmitError(
                              "Your unfinished feedback could not be saved to the server yet. Please keep this page open and try again."
                            );
                            return;
                          }
                          loop1FeedbackDraftUserTouchedLogIdsRef.current.delete(log.id);
                          setFeedbackSubmitError(null);
                          resetLoop1TransientFeedbackState();
                          setLoop1FeedbackDraftHydratedLogId(null);
                          clearLoop1UnderstandingResume(log.id);
                          setExpandedCard(null);

                        }}
                        className="dlf-cancel-button"
                      >
                        CANCEL
                      </button>


                      <button
                        disabled={
                          isSubmittingFeedbackId === log.id ||
                          (loop1VerificationLogId === log.id &&
                            loop1VerificationStage === "corrected" &&
                            loop1VerificationSecondSelection == null)
                        }
                        onClick={() =>
                          submitFeedback(log)
                        }
                        className="dlf-submit-button"
                      >
                        {isSubmittingFeedbackId === log.id ? (
                          <>
                            <span className="dlf-inline-spinner dlf-inline-spinner-light" />
                            SUBMITTING...
                          </>
                        ) : (
                          "SUBMIT FEEDBACK"
                        )}
                      </button>

                    </div>

                  </div>

                )}

              </article>

            ))}

          </div>

        )}

      </section>

      {loop1VerificationLogId && loop1VerificationStage === "corrected" && understandingLevel === "I completely understood." && feedbackSubmitError && (
        <div
          style={{
            position: "fixed",
            left: 16,
            right: 16,
            bottom: 16,
            zIndex: 3099,
            display: "flex",
            justifyContent: "center",
            pointerEvents: "none",
          }}
        >
          <button
            type="button"
            onClick={() => {
              const verificationLog = lectureLogs.find((item: any) => String(item.id) === String(loop1VerificationLogId));
              if (!verificationLog) return;
              void submitFeedback(verificationLog, "I completely understood.", loop1VerificationAnswer, true);
            }}
            disabled={isSubmittingFeedbackId === loop1VerificationLogId || loop1VerificationAnswer == null}
            style={{
              pointerEvents: "auto",
              minHeight: 42,
              padding: "9px 18px",
              borderRadius: 9,
              border: "1px solid #1D4ED8",
              background: "#1D4ED8",
              color: "#FFFFFF",
              fontWeight: 700,
              cursor: isSubmittingFeedbackId === loop1VerificationLogId ? "default" : "pointer",
            }}
          >
            RETRY SUBMISSION
          </button>
        </div>
      )}

      {loop1VerificationLogId && loop1VerificationStage === "verification" && (() => {
        const verificationLog = lectureLogs.find((item: any) => String(item.id) === String(loop1VerificationLogId));
        if (!verificationLog) return null;
        return (
          <Loop1FeedbackVerificationDialog
            open
            onDecision={(wantsToCorrect) => handleLoop1VerificationDecision(verificationLog, wantsToCorrect)}
          />
        );
      })()}



      {/* =====================================================
          FEEDBACK STATEMENT / CREDIT HISTORY
      ===================================================== */}

      <section className="dlf-surface dlf-statement-section">
        <div className="dlf-section-head">
          <div>
            <div className="dlf-eyebrow">FEEDBACK STATEMENT</div>
            <h2 className="dlf-title">Daily Feedback Records</h2>
            <p className="dlf-copy">
              Choose a subject and date range to view daily lecture feedback,
              doubt discussion responses, credit calculation, and running balance like a bank statement.
            </p>
          </div>
        </div>

        <div className="dlf-statement-filters">
          <label className="dlf-statement-field">
            <span>Subject</span>
            <select
              value={statementSubject}
              onChange={(event) => {
                setStatementSubject(event.target.value);
                setHasFetchedStatement(false);
                setStatementRows([]);
                setStatementError(null);
              }}
              className="dlf-statement-control"
            >
              <option value="">Choose subject</option>
              <option value={ALL_SUBJECTS_VALUE}>{ALL_SUBJECTS_LABEL}</option>
              {subjectOptions.length === 0 ? (
                <option value="" disabled>
                  No teacher subjects available
                </option>
              ) : (
                subjectOptions
                  .filter((subject) => subject)
                  .map((subject) => (
                    <option key={subject} value={subject}>
                      {subject}
                    </option>
                  ))
              )}
            </select>
          </label>

          <label className="dlf-statement-field">
            <span>Start date</span>
            <input
              type="date"
              value={statementStartDate}
              max={statementEndDate || undefined}
              onChange={(event) => {
                setStatementStartDate(event.target.value);
                setHasFetchedStatement(false);
                setStatementRows([]);
                setStatementError(null);
              }}
              className="dlf-statement-control"
            />
          </label>

          <label className="dlf-statement-field">
            <span>End date</span>
            <input
              type="date"
              value={statementEndDate}
              min={statementStartDate || undefined}
              onChange={(event) => {
                setStatementEndDate(event.target.value);
                setHasFetchedStatement(false);
                setStatementRows([]);
                setStatementError(null);
              }}
              className="dlf-statement-control"
            />
          </label>

          <button
            type="button"
            onClick={fetchFeedbackStatement}
            disabled={isFetchingStatement}
            className="dlf-statement-fetch"
          >
            {isFetchingStatement ? (
              <>
                <span className="dlf-inline-spinner dlf-inline-spinner-light" />
                FETCHING...
              </>
            ) : (
              "FETCH FEEDBACK RECORDS"
            )}
          </button>
        </div>

        {statementError && (
          <div className="dlf-statement-error">
            {statementError}
          </div>
        )}

        {hasFetchedStatement && !isFetchingStatement && !statementError && (
          <>
            <div className="dlf-statement-result-head">
              <div>
                <div className="dlf-statement-result-title">
                  {statementRows.length} record{statementRows.length === 1 ? "" : "s"}
                </div>
                <div className="dlf-statement-result-copy">
                  Running balance is calculated from the first row of the selected period.
                </div>
              </div>

              <button
                type="button"
                onClick={generateStatementPdf}
                disabled={!statementRows.length || isGeneratingStatementPdf}
                className="dlf-statement-pdf"
              >
                {isGeneratingStatementPdf ? "GENERATING..." : "GENERATE PDF"}
              </button>
            </div>

            {statementRows.length === 0 ? (
              <div className="dlf-statement-empty">
                No teacher feedback records were found for the selected subject and date range.
              </div>
            ) : (
              <>
                <div className="dlf-statement-mobile-hint">
                  Scroll left and right to see the full records.
                </div>

                <div
                  className={
                    statementSubject === ALL_SUBJECTS_VALUE
                      ? "dlf-statement-scroll dlf-statement-scroll-all-subjects"
                      : "dlf-statement-scroll"
                  }
                >
                  <table
                    className={
                      statementSubject === ALL_SUBJECTS_VALUE
                        ? "dlf-statement-table dlf-statement-table-all-subjects"
                        : "dlf-statement-table"
                    }
                  >
                    <thead>
                      <tr>
                        <th>Date</th>
                        {statementSubject === ALL_SUBJECTS_VALUE && <th>Subject</th>}
                        <th>Feedback Type</th>
                        <th>Topic</th>
                        <th>Teacher / difficult concepts</th>
                        <th>Response</th>
                        <th>Not understood</th>
                        <th>Talent Credits</th>
                        <th>Credits Balance</th>
                      </tr>
                    </thead>
                    <tbody>
                      {statementRows.map((row) => (
                        <tr key={row.id}>
                          <td className="dlf-statement-date">
                            {formatStatementDate(row.date)}
                          </td>
                          {statementSubject === ALL_SUBJECTS_VALUE && (
                            <td className="dlf-statement-topic">
                              {row.subjectName}
                            </td>
                          )}
                          <td>
                            <span className="dlf-statement-response dlf-statement-response-selected">
                              {row.loop === "Loop 1"
                                ? "Daily lecture feedback"
                                : "Doubt discussion feedback"}
                            </span>
                          </td>
                          <td className="dlf-statement-topic">
                            {row.chapter && (
                              <div style={{
                                marginBottom: 4,
                                color: "#1D4ED8",
                                fontSize: 10,
                                lineHeight: 1.35,
                                fontWeight: 800,
                                overflowWrap: "anywhere",
                              }}>
                                Chapter: {row.chapter}
                              </div>
                            )}
                            <div>Topic: {row.topic}</div>
                          </td>
                          <td>
                            {row.subtopics.length > 0 ? (
                              <div className="dlf-statement-subtopics">
                                {row.subtopics.map((subtopic) => (
                                  <span key={subtopic}>{subtopic}</span>
                                ))}
                              </div>
                            ) : (
                              "—"
                            )}
                          </td>
                          <td>
                            <span
                              className={
                                row.response
                                  ? "dlf-statement-response dlf-statement-response-selected"
                                  : "dlf-statement-response dlf-statement-response-pending"
                              }
                            >
                              {getResponseLabel(row.response)}
                            </span>
                          </td>
                          <td>
                            {row.difficultConcepts.length > 0 ? (
                              <div className="dlf-statement-difficult">
                                {row.difficultConcepts.map((concept) => (
                                  <span key={concept}>{concept}</span>
                                ))}
                              </div>
                            ) : (
                              "—"
                            )}
                          </td>
                          <td
                            className={
                              row.creditChange > 0
                                ? "dlf-statement-credit-positive"
                                : row.creditChange < 0
                                  ? "dlf-statement-credit-negative"
                                  : "dlf-statement-credit-neutral"
                            }
                          >
                            {row.creditChange > 0
                              ? "+1"
                              : row.creditChange < 0
                                ? "−10"
                                : "0"}
                            <span className="dlf-statement-credit-label">
                              {row.creditLabel}
                            </span>
                          </td>
                          <td className="dlf-statement-balance">
                            {row.balance}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </>
            )}
          </>
        )}
      </section>

      {crossQuestionImageViewerUrl && (
        <div role="dialog" aria-modal="true" aria-label="Cross-question image preview" onClick={(event) => { if (event.target === event.currentTarget) setCrossQuestionImageViewerUrl(null); }} style={{ position: "fixed", inset: 0, zIndex: 3000, display: "flex", alignItems: "center", justifyContent: "center", padding: 16, background: "rgba(2, 6, 23, 0.88)" }}>
          <button type="button" onClick={() => setCrossQuestionImageViewerUrl(null)} aria-label="Close enlarged image" style={{ position: "absolute", top: 16, right: 16, zIndex: 1, border: "1px solid rgba(255,255,255,.65)", borderRadius: 999, width: 42, height: 42, background: "#fff", color: "#0f172a", fontSize: 26, lineHeight: 1, cursor: "pointer" }}>×</button>
          <img src={crossQuestionImageViewerUrl} alt="Enlarged cross question" onClick={(event) => event.stopPropagation()} style={{ display: "block", maxWidth: "100%", maxHeight: "90vh", objectFit: "contain", borderRadius: 8 }} />
        </div>
      )}
    </div>
  </>
);

}