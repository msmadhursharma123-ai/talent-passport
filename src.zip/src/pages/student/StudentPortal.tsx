import {useEffect,useRef,useState} from "react";
import {registerAndroidBackHandler} from "../../mobile/androidBackNavigation";
import StudentLayout,{StudentTab} from "./StudentLayout";
import LiveDoubtReconciliationGate from "../../domains/liveDoubtIntelligence/components/LiveDoubtReconciliationGate";
import TalentPassport from "../TalentPassport";import Homeboard from "./Homeboard";import Timeline from "./TimelineV3";import Portfolio from "./Portfolio";import Competitions from "./Competitions";import MyAnalysis from "./MyAnalysis";import Opportunities from "./Opportunities.tsx";import GrowthPlan from "./GrowthPlan";import MaukePeChauka from "./MaukePeChauka";
import {getCurrentStudent} from "../../services/identityService";import {getSchoolFeatureKeys,STUDENT_FEATURES} from "../../data/schoolFeatureAccessRepository";
interface Props{onLogout:()=>void;onStartDNA:()=>void;}
export default function StudentPortal({onLogout,onStartDNA}:Props){const[activeTab,rawSetActiveTab]=useState<StudentTab>("dna-radar");const[enabled,setEnabled]=useState<string[]|null>(null);
const activeTabRef=useRef<StudentTab>(activeTab);
const historyRef=useRef<StudentTab[]>([]);
const pendingRef=useRef(false);
const restoringRef=useRef(false);
const setActiveTab=(next:StudentTab)=>{const current=activeTabRef.current;if(next===current)return;if(!restoringRef.current&&!pendingRef.current){historyRef.current.push(current);pendingRef.current=true;queueMicrotask(()=>{pendingRef.current=false;});}activeTabRef.current=next;rawSetActiveTab(next);};
useEffect(()=>registerAndroidBackHandler(()=>{const previous=historyRef.current.pop();if(previous===undefined)return false;restoringRef.current=true;activeTabRef.current=previous;rawSetActiveTab(previous);restoringRef.current=false;return true;},10),[]);
useEffect(()=>{void(async()=>{const identity=getCurrentStudent();if(!identity?.schoolUuid){setEnabled(STUDENT_FEATURES.map(x=>x.key));return;}const keys=await getSchoolFeatureKeys(identity.schoolUuid,"student");setEnabled(keys);if(keys.length&&!keys.includes(activeTab)){activeTabRef.current=keys[0] as StudentTab;rawSetActiveTab(keys[0] as StudentTab);}})();},[]);
if(enabled===null)return <LiveDoubtReconciliationGate onSubmitted={()=>{window.dispatchEvent(new CustomEvent("student-live-doubt-reconciliation-submitted"));}} />;if(enabled.length===0)return <><LiveDoubtReconciliationGate onSubmitted={()=>{window.dispatchEvent(new CustomEvent("student-live-doubt-reconciliation-submitted"));}} /><StudentLayout activeTab={activeTab} setActiveTab={setActiveTab} onLogout={onLogout} enabledTabs={[]}><div style={{padding:32}}>No Student Portal modules are enabled for this school.</div></StudentLayout></>;
const page=enabled.includes(activeTab)?(()=>{switch(activeTab){case"dna-radar":return <TalentPassport onStartDNA={onStartDNA} liveGateManagedByStudentPortal />;case"homeboard":return <Homeboard/>;case"timeline":return <Timeline/>;case"portfolio":return <Portfolio/>;case"competitions":return <Competitions/>;case"opportunities":return <Opportunities/>;case"mauke-pe-chauka":return <MaukePeChauka/>;case"my-analysis":return <MyAnalysis/>;case"growth-plan":return <GrowthPlan/>;default:return <Homeboard/>;}})():null;
return <><LiveDoubtReconciliationGate onSubmitted={()=>{window.dispatchEvent(new CustomEvent("student-live-doubt-reconciliation-submitted"));}} /><StudentLayout activeTab={activeTab} setActiveTab={setActiveTab} onLogout={onLogout} enabledTabs={enabled}>{page}</StudentLayout></>;}
